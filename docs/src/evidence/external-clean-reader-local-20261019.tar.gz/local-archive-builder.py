"""One-use full local combined-retention evidence; own native/platform gates remain separate."""
from pathlib import Path
import json,hashlib,tarfile,io,subprocess,re
root=Path('/home/marshall/src/worktrees/s3drive-external-clean-reader');out=root/'docs/src/evidence/external-clean-reader-local-20261019.tar.gz';assert not out.exists()
m=json.loads(Path('/tmp/s3drive-external-clean-reader-candidate1-frozen.json').read_text());assert len(m)==342
r=json.loads(Path('/tmp/s3drive-external-clean-reader-gate1-result.json').read_text());assert r['exit_code']==0 and r['all_inputs_unchanged'] and r['runtime_inputs']==342 and r['rust_test_threads']==4
assert r['command']==['bash','scripts/gate.sh']
raw=Path(r['log']).read_bytes();assert hashlib.sha256(raw).hexdigest()==r['sha256']
counts={}
for label,passed,ignored in [('publication',24,0),('state',496,1),('reader',26,1),('core',37,0),('s3',62,0)]:
 match=re.search(fr'test result: ok\. {passed} passed; 0 failed; {ignored} ignored; 0 measured; 0 filtered out; finished in ([0-9.]+)s'.encode(),raw);assert match,label
 counts[label]={'passed':passed,'ignored':ignored,'seconds':float(match.group(1))}
files={}
for name,sha in m.items():
 body=(root/name).read_bytes();assert hashlib.sha256(body).hexdigest()==sha,name
 assert hashlib.sha256(subprocess.check_output(['git','-C',str(root),'show','12a2f2a:'+name])).hexdigest()==sha,name
 files['final-source/'+name]=body
for suffix in ['candidate1-frozen.json','gate1.log','gate1-running.json','gate1-result.json','gate1-runner.py']:
 p=Path('/tmp/s3drive-external-clean-reader-'+suffix);files[p.name]=p.read_bytes()
parents=[('local-intent-local',Path('/home/marshall/src/s3drive/docs/src/evidence/external-clean-local-local-20261019.tar.gz'),Path('/tmp/s3drive-external-clean-local-local-archive-proof.json')),('local-intent-hosted',Path('/home/marshall/src/worktrees/s3drive-external-clean-local/docs/src/evidence/external-clean-local-hosted-20261019.tar.gz'),Path('/tmp/s3drive-external-clean-local-hosted-archive-proof.json'))]
for label,path,proof_path in parents:
 proof=json.loads(proof_path.read_text());assert hashlib.sha256(path.read_bytes()).hexdigest()==proof['sha256']
 with tarfile.open(path) as t:
  index=json.loads(t.extractfile('sha256-index.json').read());assert set(t.getnames())==set(index)|{'sha256-index.json'}
  for name,sha in index.items():assert hashlib.sha256(t.extractfile(name).read()).hexdigest()==sha,(label,name)
 files['parent-evidence/'+label+'/'+path.name]=path.read_bytes();files['parent-evidence/'+label+'/'+proof_path.name]=proof_path.read_bytes()
for attempt in [1,2,3]:
 for suffix in ['frozen.json','runner.py','running.json','result.json','source.tar.gz','state.log','sdk.log','clippy.log']:
  if attempt==3 and suffix in ['state.log','source.tar.gz']:continue
  p=Path(f'/tmp/s3drive-external-clean-reader-sdk{attempt}-'+suffix)
  files[p.name]=p.read_bytes()
files['local-archive-builder.py']=Path(__file__).read_bytes()
files['executed-contract.md']=(root/'docs/src/external-clean-reader.md').read_bytes()
index={name:hashlib.sha256(body).hexdigest() for name,body in files.items()}
with tarfile.open(out,'x:gz') as t:
 for name,body in sorted(files.items()):
  info=tarfile.TarInfo(name);info.mode=0o644;info.mtime=0;info.size=len(body);t.addfile(info,io.BytesIO(body))
 body=(json.dumps(index,indent=2)+'\n').encode();info=tarfile.TarInfo('sha256-index.json');info.mode=0o644;info.mtime=0;info.size=len(body);t.addfile(info,io.BytesIO(body))
with tarfile.open(out) as t:
 assert set(t.getnames())==set(index)|{'sha256-index.json'}
 for name,sha in index.items():assert hashlib.sha256(t.extractfile(name).read()).hexdigest()==sha,name
proof={'scope':'complete local gate only; parent and own hosted/platform/source/native acceptance required','path':str(out.relative_to(root/'docs/src')),'sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'bytes':out.stat().st_size,'members':len(index)+1,'all_indexed_members_verified':True,'runtime_inputs':342,'source_checkpoint':'12a2f2a','schema':38,'gate_exit_code':0,'gate_log_sha256':r['sha256'],'rust_test_threads':4,'reduced_sdk_admission':False,'counts':counts,'parent_archives_independently_verified':2}
Path('/tmp/s3drive-external-clean-reader-local-archive-proof.json').write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps(proof,indent=2))
