"""Owned long gate runner; records actual exit and input identity, never hides failure."""
from pathlib import Path
import os,sys,subprocess,json,hashlib,datetime,signal
root=Path('/home/marshall/src/worktrees/s3drive-external-clean-reader')
base=Path('/tmp/s3drive-external-clean-reader-gate1')
frozen=Path('/tmp/s3drive-external-clean-reader-candidate1-frozen.json')
f=json.loads(frozen.read_text());assert len(f)==342
for p,h in f.items():assert hashlib.sha256((root/p).read_bytes()).hexdigest()==h,p
result=Path(str(base)+'-result.json');running=Path(str(base)+'-running.json');log=Path(str(base)+'.log')
assert not result.exists() and not running.exists() and not log.exists()
def save(p,value):
 temporary=Path(str(p)+'.tmp');temporary.write_text(json.dumps(value,indent=2)+'\n');os.chmod(temporary,0o600);temporary.replace(p)
def start_ticks(pid):return Path(f'/proc/{pid}/stat').read_text().rsplit(')',1)[1].split()[19]
started=datetime.datetime.now(datetime.timezone.utc).isoformat()
env=os.environ.copy();env['CARGO_TARGET_DIR']='/home/marshall/src/s3drive/target';env['RUST_TEST_THREADS']='4'
with log.open('xb') as out:
 os.chmod(log,0o600)
 child=subprocess.Popen(['bash','scripts/gate.sh'],cwd=root,env=env,stdin=subprocess.DEVNULL,stdout=out,stderr=subprocess.STDOUT,start_new_session=True)
 def stop(signum,_frame):
  try:os.killpg(child.pid,signum)
  except ProcessLookupError:pass
 signal.signal(signal.SIGTERM,stop);signal.signal(signal.SIGINT,stop)
 record={'runner_pid':os.getpid(),'runner_start_ticks':start_ticks(os.getpid()),'child_pid':child.pid,'child_start_ticks':start_ticks(child.pid),'started':started,'command':['bash','scripts/gate.sh'],'cwd':str(root),'runtime_inputs':342,'frozen_map':str(frozen),'tty':False,'rust_test_threads':4,'log':str(log)}
 save(running,record)
 code=child.wait()
changed=[p for p,h in f.items() if hashlib.sha256((root/p).read_bytes()).hexdigest()!=h]
record.update({'exit_code':code,'finished':datetime.datetime.now(datetime.timezone.utc).isoformat(),'all_inputs_unchanged':not changed,'changed_inputs':changed,'sha256':hashlib.sha256(log.read_bytes()).hexdigest()})
save(result,record)
sys.exit(code if code>=0 else 128-code)
