"""Owned sequential verifier. Wait for the exact parent gate; never restart it."""
from pathlib import Path
import os,subprocess,json,hashlib,datetime,time,sys,signal
root=Path('/home/marshall/src/worktrees/s3drive-external-clean-reader')
base=Path('/tmp/s3drive-external-clean-reader-sdk1')
frozen=Path(str(base)+'-frozen.json');f=json.loads(frozen.read_text());assert len(f)==342
running=Path(str(base)+'-running.json');result=Path(str(base)+'-result.json');assert not running.exists() and not result.exists()
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def ticks(pid):return Path(f'/proc/{pid}/stat').read_text().rsplit(')',1)[1].split()[19]
def save(p,v):
 q=Path(str(p)+'.tmp');q.write_text(json.dumps(v,indent=2)+'\n');os.chmod(q,0o600);q.replace(p)
v={'pid':os.getpid(),'start_ticks':ticks(os.getpid()),'source':'a8cc73e','runtime_inputs':342,'started':now(),'cwd':str(root),'stage':'waiting_exact_parent_gate','parent_runner':1114325,'parent_start_ticks':'143781754','legs':[]};save(running,v)
parent=Path('/tmp/s3drive-external-clean-local-gate1-result.json')
while not parent.exists():
 try:assert ticks(1114325)=='143781754'
 except (FileNotFoundError,AssertionError):
  v.update(stage='parent_missing_without_result',exit_code=70,finished=now());save(result,v);sys.exit(70)
 time.sleep(10)
p=json.loads(parent.read_text());assert p['runner_pid']==1114325 and p['runner_start_ticks']=='143781754'
if p['exit_code']!=0 or not p['all_inputs_unchanged']:
 v.update(stage='parent_failed',exit_code=70,parent_result=p,finished=now());save(result,v);sys.exit(70)
env=os.environ.copy();env['CARGO_TARGET_DIR']='/home/marshall/src/s3drive/target';env['RUST_TEST_THREADS']='4'
legs=[('state',['cargo','test','-p','s3drive-state','observation_preflight','--locked']),('sdk',['cargo','test','-p','s3drive-cli','--test','chunk_reader','clean_observation','--locked']),('clippy',['cargo','clippy','--workspace','--all-targets','--locked','--','-D','warnings'])]
for label,command in legs:
 assert all(hashlib.sha256((root/p).read_bytes()).hexdigest()==h for p,h in f.items())
 log=Path(str(base)+'-'+label+'.log');assert not log.exists()
 with log.open('xb') as out:
  child=subprocess.Popen(command,cwd=root,env=env,stdin=subprocess.DEVNULL,stdout=out,stderr=subprocess.STDOUT,start_new_session=True)
  def stop(sig,frame):
   try:os.killpg(child.pid,sig)
   except ProcessLookupError:pass
  signal.signal(signal.SIGTERM,stop);signal.signal(signal.SIGINT,stop)
  entry={'label':label,'command':command,'pid':child.pid,'start_ticks':ticks(child.pid),'log':str(log),'started':now()};v['stage']=label;v['active_child']=entry;save(running,v)
  code=child.wait()
 changed=[p for p,h in f.items() if hashlib.sha256((root/p).read_bytes()).hexdigest()!=h]
 entry.update(exit_code=code,finished=now(),all_inputs_unchanged=not changed,changed_inputs=changed,sha256=hashlib.sha256(log.read_bytes()).hexdigest());v['legs'].append(entry);v.pop('active_child',None)
 if code or changed:
  v.update(stage=label+'_failed',exit_code=code or 71,finished=now());save(result,v);sys.exit(code or 71)
v.update(stage='complete',exit_code=0,all_inputs_unchanged=True,finished=now());save(result,v)
