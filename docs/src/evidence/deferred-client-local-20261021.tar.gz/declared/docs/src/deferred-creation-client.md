# Deferred canonical creation client

Declared2026-10-21 from accepted main8601973/schema42/runtime372. This is an
implementation candidate, not native lifecycle activation. The accepted
[authority transaction](atomic-deferred-manifest-create.md) records a combined
canonical payload and original removal fence; the client must now persist its
intent and independently verified physical proof before requesting that effect.

Add explicit `Creator::create_deferred(draft, owner)` alongside ordinary creation.
The original operation/owner/name/parent/store/source must be admitted durably
before staging or sending. Validate the owner as a nonzero32-hex-digit identity;
never derive it from a path or another node. Ordinary Draft/create behavior and
existing format1 JSON/hash/staging keys stay unchanged. An optional owner field
is omitted when absent. Owner-bearing intents use format2 and a distinct,
owner-bound staging-key domain; the immutable canonical root identity and bytes
still derive from the original operation and store.

Use schema43 only as a compatibility marker, without new tables or old BLOB/hash
rewrites. Refuse format2 under earlier markers, including restricted recovery.
A format/owner mismatch is corruption. New request preparation must select
CreateDeferredEmptyManifest, require atomic-deferred-empty-manifest-v1 plus the
existing manifest/history support, and accept only the exact combined receipt
whose fence intent/owner and canonical payload match the original input.

Keep the executor's create-only send/observe discipline. Unknown physical sends
are observed before fresh admission; saved metadata requests and outcomes replay
before fresh policy/features, without a new operation ID or owner. Restricted
recovery keeps its existing no-credentials/no-source-body/no-staging/no-new-intent
capability. A self-consistent owner/request/receipt rewrite must fail against the
independent original staged-operation/upload metadata. Return historical creation
metadata and the original fence only; no active open/removal right is minted.

Done criteria:

- Local format2 intent, staging link, verified proof, prepared exact request,
  combined acknowledgment/rejection and restart work through public journal APIs.
  Preserve format1 bytes/hashes/staging identities through42→43 migration and
  ordinary SDK behavior; reject old markers, wrong owner/fence/format, forged
  receipts and independent-proof disagreement without repair.
- Owned SDK loopback fixtures cover binary canonical root upload, Unicode names,
  empty logical reads, collisions, feature/policy rejection before fresh PUT,
  unknown PUT observation without resend, lost metadata reply and killed-owner
  restricted recovery with damaged body/absent credentials. Exact original owner
  survives historical replay and a successor removal epoch.
- Retain quotas, SQL_FULL rollback, bounded cancellation/queue/owner behavior and
  same-storage chunk capability composition. Complete own unchanged-source local
  and Linux/Windows/book/native regression gates before promotion.

Expected footprint: manifest creation input/format/validation, Creator API and
feature selection, focused state/SDK fixtures, schema marker/native assertions,
book/handoff. No new dependency, native callback, provenance import, sparse
owned-unlinked publisher, GC or service provisioning. The next phase must import
this exact verified creator provenance into the same-owner open journal and bind
publication to the original fence/current event. Real provider and physical
startup acceptance remain separate. Keep both hosting choices/Turso open and
repository visibility public; only read-only visibility checks are authorized.

## Candidate verification status —2026-10-21

Seven state tests pass, including real SQLITE_FULL rollback, all eight killed
owner boundaries, format1 byte/staging preservation, downgraded-marker refusal,
receipt/owner/format corruption and independent original staging-witness checks.
The first six SDK cases passed. The extended controls case also passes with two separate journals contending
for the same Unicode filename and missing-history feature refusal. Full local
and hosted verification remain pending.

The additional async creation branch exposed a compiler Send-proof recursion
limit in the existing native dispatcher. Creation uses a boxed mode future;
the private dispatcher constructs its owned Tokio task before returning the
join future, so the join type contains the handle and abort guard. Admission
still happens first, within the public async callback body, with the existing
four-slot limit. No recursion limit, driver stack threshold, deadline or quota
was raised. Cancellation of both a polled and an unpolled join must release the
owned job and permit. This dispatcher change is part of this candidate's native
regression footprint; no new native lifecycle operation is enabled.
