use rusqlite::{Connection, TransactionBehavior};
fn main() -> rusqlite::Result<()> {
    for mode in 0..3 {
        let mut db=Connection::open_in_memory()?;
        db.pragma_update(None,"foreign_keys",true)?;
        db.execute_batch(include_str!("../migrations/029.sql"))?;
        {
            let tx=db.transaction_with_behavior(TransactionBehavior::Immediate)?;
            tx.execute_batch("INSERT INTO sparse_view_files VALUES(zeroblob(32),x'7b',zeroblob(32),zeroblob(32)); INSERT INTO sparse_views VALUES(zeroblob(32),zeroblob(32),x'7b',zeroblob(32)); INSERT INTO sparse_view_operations VALUES(zeroblob(32),zeroblob(32),x'7b',zeroblob(32));")?;
            tx.commit()?;
        }
        let tx=db.transaction_with_behavior(TransactionBehavior::Immediate)?;
        tx.pragma_update(None,"defer_foreign_keys",true)?;
        let sql=match mode {
            0=>"CREATE TABLE views_new(view_id BLOB PRIMARY KEY,target BLOB REFERENCES sparse_view_files(target),record BLOB,state_hash BLOB); INSERT INTO views_new SELECT * FROM sparse_views; DROP TABLE sparse_views; ALTER TABLE views_new RENAME TO sparse_views;",
            1=>"CREATE TEMP TABLE views_copy AS SELECT * FROM sparse_views; CREATE TEMP TABLE files_copy AS SELECT * FROM sparse_view_files; CREATE TEMP TABLE ops_copy AS SELECT * FROM sparse_view_operations; DELETE FROM sparse_view_operations; DELETE FROM sparse_view_files; DELETE FROM sparse_views; DROP TABLE sparse_views; CREATE TABLE sparse_views(view_id BLOB PRIMARY KEY,target BLOB REFERENCES sparse_view_files(target),record BLOB,state_hash BLOB); INSERT INTO sparse_view_files SELECT * FROM files_copy; INSERT INTO sparse_views SELECT * FROM views_copy; INSERT INTO sparse_view_operations SELECT * FROM ops_copy;",
            _=>"CREATE TEMP TABLE views_copy AS SELECT * FROM sparse_views; CREATE TEMP TABLE files_copy AS SELECT * FROM sparse_view_files; CREATE TEMP TABLE ops_copy AS SELECT * FROM sparse_view_operations; DELETE FROM sparse_view_operations; DELETE FROM sparse_views; DELETE FROM sparse_view_files; DROP TABLE sparse_views; CREATE TABLE sparse_views(view_id BLOB PRIMARY KEY,target BLOB REFERENCES sparse_view_files(target),record BLOB,state_hash BLOB); INSERT INTO sparse_view_files SELECT * FROM files_copy; INSERT INTO sparse_views SELECT * FROM views_copy; INSERT INTO sparse_view_operations SELECT * FROM ops_copy;"
        };
        let result=tx.execute_batch(sql).and_then(|_| tx.commit());
        println!("mode {mode}: {result:?}");
        let bad:u32=db.query_row("SELECT count(*) FROM pragma_foreign_key_check",[],|r|r.get(0))?;
        let fk:bool=db.pragma_query_value(None,"foreign_keys",|r|r.get(0))?;
        println!("bad={bad} fk={fk}");
    }
    Ok(())
}
