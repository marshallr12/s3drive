from pathlib import Path
import subprocess,json,time,os
base=Path('/tmp/s3drive-creator-import-old-binary1')
result=Path('/tmp/s3drive-creator-import-gate1-result.json')
for _ in range(180):
 if result.exists():
  gate=json.loads(result.read_text())
  assert gate['exit_code']==0 and gate['unchanged'], 'full gate did not pass; no compatibility build launched'
  proc=subprocess.run(['python3',str(base)+'.py'])
  Path(str(base)+'-exit.json').write_text(json.dumps({'exit_code':proc.returncode})+'\n')
  raise SystemExit(proc.returncode)
 time.sleep(20)
raise SystemExit('gate wait limit reached; no compatibility build launched')
