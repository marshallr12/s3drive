# Creator provenance import candidate

Source review2026-10-21 against deferred client9381456/schema43. This is a
proposal; no import or native lifecycle flag is implemented by this chapter.
The [creation client](deferred-creation-client.md) persists the original owner,
canonical root proof and combined authority receipt. Its receipt is historical,
not an active open admission.

## Observed integration boundary

`namespace_client::opens::OpenInput.admission` currently contains a namespace
`Input`. Activation loads the exact acknowledged namespace journal row and
reduces its retained removal history. The creation client's separate journal
cannot supply that row today. `namespace_client::Input::validate`, removal-history
reduction, open targeting/activation and session recovery currently recognize
metadata-empty deferred creation. Merely adding a mutation to their matches
would allow a generic namespace submission path to claim a canonical creation
without checking the independent local upload/staging evidence.

The chunk mount already binds a stable client owner and exact volume/store/
source/fingerprint controls to one SQLite worker. That is the proposed import
boundary. Import must read the creation record from that same database; a caller
must not supply a receipt, inferred pathname, replacement owner or another
storage connection as proof.

## Proposed independently testable phase

1. Expose a dedicated chunk-capability import operation, taking the original
   creation operation ID. Check the chunk key and retained identity, exact source
   controls, acknowledged format2 creation request/outcome and the independent
   staging/upload witness. Refuse ordinary creation, an unknown/rejected creation,
   damaged proof or a foreign owner/store/source/volume.
2. Atomically retain the exact original request and combined successful receipt
   as a complete namespace journal record. Never insert a pending surrogate or
   synthesize a metadata-empty create. Preserve existing quotas and validate the
   inserted row through the normal loader before committing. Exact repeat import
   returns the same record; a changed operation binding remains a conflict.
3. Keep fresh generic namespace `begin` from admitting this canonical mutation.
   Validate imported records against their original creation journal on load as
   well as on import, so a self-consistent namespace row/hash rewrite cannot
   replace the independent provenance. Share canonical receipt-shape validation
   with the creation journal instead of duplicating its definition.
4. Extend removal-history and open admission/activation targeting to recognize
   the imported combined creation. Bind admission to the original fence and
   owner; activation still requires the current acknowledged deferred event.
   Historical import must never resurrect an owner after cancellation or adopt a
   successor epoch. Require import before a new creation-bound open is admitted.
5. Preserve old namespace/open JSON, hashes and rows. Evaluate a new compatibility
   marker without new tables; refuse the new imported shape under an older
   marker before migration/relabeling. Keep the 64-table snapshot bound.

An import may finish before open admission. Its complete durable namespace row
and original creation record must permit exact recovery after a crash between
those operations. No active handle may be inferred from that intermediate state.
The exact public method and marker remain proposals until implementation review.

## Required evidence and following work

Use public same-owner worker APIs for successful import and open activation,
restart, queue/deadline/cancellation behavior and exact deduplication. Kill owners
before/after import commit and admission; exercise real SQLITE_FULL rollback,
quota pressure, wrong source/key/owner/session, missing or corrupted independent
proof, retained old bytes and actual old-binary refusal. Verify that generic
namespace admission cannot bypass the importer and that original versus
successor owner histories stay separate. Run the full local and own hosted
Linux/Windows/book/native regression gates before promotion.

Sparse owned-unlinked publication still needs exact original fence/current event
binding in reservations, dirty-view preservation and unresolved-effect barriers
before final removal. Native delete-on-close/save-replace, cold metadata recovery,
retention/GC, physical sign-in/reboot/SSH/tmux and newly approved real Wasabi
acceptance remain later work. This proposal grants no provider mutation or
service/startup installation permission and selects no Turso hosting option.

## Implementation declaration — 2026-10-21

Base main25fc926/runtime9381456/schema43/all374. Implement
`Namespace::import_creation(operation)` on an existing chunk capability. Its
synchronous journal operation requires the same retained chunk key and reads
an independently validated, acknowledged owner-bearing creation from the same
SQLite connection. The caller supplies no receipt, owner, source or filepath.
The imported namespace row is complete from its first committed visibility.
Generic begin refuses this mutation even when a caller constructs a matching
Input; get/import provide exact repeat recovery. The loader rechecks provenance,
so changed namespace rows/hashes alone cannot manufacture an admission.

Use schema44 as a compatibility marker without DDL. For existing43 chunk roles,
first reject imported canonical namespace shapes under the old marker, then
validate under a transaction-local44 marker before committing the upgrade.
Validation failure rolls back the marker and every row; strict runtime role
checks remain exact. Preserve old namespace/open JSON and all independent
creation/staging/upload witnesses byte-for-byte. Earlier unsupported chunk-role
migration paths remain explicit refusals.

The import retains historical evidence. Local open activation records current
acknowledged local deferred history; it does not contact the remote authority or
prove that an unobserved remote operation has not happened. Native integration
must retain its live authority/fence checks and is not enabled by this phase.
Import must not rewind locally known cancellation or successor epochs. Damaged
payload body bytes do not invalidate a metadata-only historical import when all
original metadata/witness checks remain valid; damaged provenance does.

Expected write footprint: manifest-creation proof accessor; a namespace import
module plus exact receipt validation, loader/generic-begin guards and existing
removal/creation targeting; open admission/activation checks; one bounded worker
method; schema/native expectations; focused state and SDK tests; book/handoff.
No new dependency, S3 capability, OS callback, quota increase or table.
Full unchanged-source local and own hosted/native regression gates are required
before promotion. Use owned loopback fixtures; no new live provider mutations.

## Focused candidate evidence — 2026-10-21

Twelve state cases passed, including seven killed-worker transaction boundaries,
actual SQLITE_FULL during import/open preparation/activation, closing headroom,
byte-preserving43→44 upgrade, failed-upgrade rollback and independently forged
namespace/creator records. Two additional focused tests pass for complete creator
role metadata projection and a real remote commit whose local receipt is still
unknown. Import refuses that unknown local receipt until exact acknowledgment.
Three SDK/HTTP cases pass for same-owner admission, rejected ordinary/foreign-owner
imports and process-death recovery with damaged staged body/absent credentials.
Existing worker queue/lifetime limits are reused; the full local and own hosted/
native gates remain pending. No acceptance is inferred from these focused tests.

The first test compilation needed an explicit helper borrow lifetime; the next
run found a missing parent fixture directory. A later run exposed fixture reuse
of an obsolete runtime session and an ordinary read of a pending-removal node.
The corrected crash fixture snapshots committed child setup at a ready barrier,
then kills the real worker transaction. It retains obsolete-session refusal and
uses owned pending-removal reads. A Debug-formatting fixture compile error was
also corrected. All failures remain in the local evidence logs.

Repeated namespace/open loads check the complete creator role's record/hash/
format projection, then the selected creator's original staging/upload witness.
Full-role APIs still validate all physical witnesses. This avoids repeating every
other creator's physical SQL proof for each open without weakening the selected
proof or the role projection. No quota, worker deadline or stack bound increased.

Native create wiring must also reserve namespace/open closing headroom before
sending a new S3/authority create. This historical importer checks available
closing capacity for an already acknowledged creation; it does not pre-admit a
future create. Preserve the original creator on capacity refusal and add that
prospective reservation with the native lifecycle bridge. Retention remains
separate; no history reclamation is enabled here.
