from pathlib import Path
import datetime,hashlib,json,subprocess
root=Path('/home/marshall/src/s3drive')
candidate=Path('/home/marshall/src/worktrees/s3drive-creator-open-sdk')
expected='8780ce4a023a26982051b0aee54e9ee9bd64880c'
source='8022fae3d1b496c511321f0ee6294908bc749039'
base=Path('/tmp/s3drive-creator-open-sdk')
output=Path('/tmp/s3drive-canonical-creator-open-sdk-publication.json')
assert not output.exists()
def read(suffix):return json.loads(Path(str(base)+suffix).read_text())
def git(*args,cwd=root):return subprocess.check_output(['git',*args],cwd=cwd,text=True).strip()
assert git('branch','--show-current')=='main' and git('rev-parse','HEAD')==expected
assert not git('status','--porcelain') and not git('status','--porcelain',cwd=candidate)
branch=git('rev-parse','HEAD',cwd=candidate)
subprocess.run(['git','merge-base','--is-ancestor',source,branch],cwd=root,check=True)
gate=read('-gate1-result.json');assert gate['head']==source and gate['exit_code']==0 and gate['unchanged']
local=read('-local-review.json');assert local['source']==source and local['all_candidate_cases_passed'] and local['candidate_cases']==10 and local['all_slow_notices_resolved']
run=read('-hosted1-result.json');assert run['headSha']==source and run['conclusion']=='success' and len(run['jobs'])==3 and all(j['conclusion']=='success' for j in run['jobs'])
review=read('-hosted1-raw-reviewed.json');assert review['source']==source and review['reviewed'] and review['test_faults']==0 and review['all_raw_record_fields_and_json_types_match']
assert read('-hosted1-collection-result.json')['collected']
src=read('-hosted1-source-proof.json');assert src['source']==source and src['all_digests_match'] and src['all_source_files']==739
frozen=read('-candidate1-frozen.json');assert len(frozen)==381
def runtime(where):
    for path,digest in frozen.items():assert hashlib.sha256((where/path).read_bytes()).hexdigest()==digest,path
runtime(candidate)
doc=read('-doc-gate-result.json');assert doc['passed'] and doc['runtime_inputs_unchanged']==381
for path,digest in doc['doc_fingerprints'].items():assert hashlib.sha256((candidate/path).read_bytes()).hexdigest()==digest,path
for kind in ['local-archive','hosted-archive']:
    proof=read('-'+kind+'-proof.json');archive=candidate/'docs/src/evidence'/Path(proof['archive']).name
    assert proof['all_members_verified'] and hashlib.sha256(archive.read_bytes()).hexdigest()==proof['sha256']
subprocess.run(['git','fetch','origin','main'],cwd=root,check=True)
assert git('rev-parse','origin/main')==expected,'main moved; preserve candidate and re-evaluate'
def visibility():return subprocess.check_output(['gh','api','repos/marshallr12/s3drive','--jq','.visibility'],text=True).strip()
assert visibility()=='public'
subprocess.run(['git','merge','--squash',branch],cwd=root,check=True)
runtime(root)
for path,digest in doc['doc_fingerprints'].items():assert hashlib.sha256((root/path).read_bytes()).hexdigest()==digest,path
changed=git('diff','--cached','--name-only').splitlines();assert changed
for path in changed:assert path in frozen or path in ['HANDOFF.md','README.md'] or path.startswith(('docs/src/','docs/archive/')),path
with Path(str(base)+'-canonical-doc-gate.log').open('wb') as log:
    for command in [['python3','scripts/check-schema-fixtures.py'],['python3','scripts/check-doc-links.py'],['mdbook','build','docs'],['mdbook','test','docs']]:
        subprocess.run(command,cwd=root,stdout=log,stderr=subprocess.STDOUT,check=True)
subprocess.run(['git','diff','--cached','--check'],cwd=root,check=True)
subprocess.run(['git','commit','-m','Add verified prospective creator and open admission SDK'],cwd=root,check=True)
head=git('rev-parse','HEAD');runtime(root);assert not git('status','--porcelain')
subprocess.run(['git','push','origin','main'],cwd=root,check=True)
remote=git('ls-remote','origin','refs/heads/main').split()[0];assert remote==head and visibility()=='public'
proof={'published_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'main':head,'remote_main':remote,'previous_main':expected,'accepted_runtime':source,'docs_branch':branch,'runtime_inputs':381,'all_runtime_digests_match':True,'clean':True,'visibility':'public','visibility_checks':'GET-only; no visibility mutation','own_run':run['databaseId'],'local_gate_seconds':gate['elapsed_seconds'],'changed_paths':changed}
output.write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps(proof))
