from pathlib import Path
import hashlib,json,re
base='/tmp/s3drive-creator-open-sdk'
result=json.loads(Path(base+'-gate1-result.json').read_text());assert result['exit_code']==0 and result['unchanged']
p=Path(base+'-gate1.log');raw=p.read_text();lines=raw.splitlines()
root=Path('/home/marshall/src/worktrees/s3drive-creator-open-sdk')
names=re.findall(r'fn (creator_open_\w+)\(', (root/'crates/s3drive-cli/tests/chunk_publication.rs').read_text());assert len(names)==10
for name in names:assert 'test '+name+' ... ok' in lines,name
assert not re.search(r'^test result: FAILED|^error:|^failures:',raw,re.M)
cohorts=re.findall(r'^test result: ok\..*$',raw,re.M);assert len(cohorts)>=37
slow=[]
for n,line in enumerate(lines):
 m=re.fullmatch(r'test (.+) has been running for over 60 seconds',line)
 if m:
  end=next((i for i in range(n+1,len(lines)) if lines[i]=='test '+m.group(1)+' ... ok'),None);assert end is not None,m.group(1)
  slow.append({'test':m.group(1),'notice':n+1,'later_pass':end+1})
proof={'source':result['head'],'passing_cohorts':len(cohorts),'candidate_cases':len(names),'all_candidate_cases_passed':True,'slow_notices':slow,'all_slow_notices_resolved':True,'log_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'schema':'45 unchanged; no new forward-refusal test claimed'}
Path(base+'-local-review.json').write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps(proof))
