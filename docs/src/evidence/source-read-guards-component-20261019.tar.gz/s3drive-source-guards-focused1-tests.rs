use super::*;
use crate::sparse_views::{Binding, Client, Id, Options, Piece};
use std::{future::Future, task::Poll, time::Duration};

async fn fixture(path: &Path) -> (Storage, Client, Id) {
    let storage = Storage::open(path, cache::Options::default(), journal::Options::default())
        .await
        .unwrap();
    let client = storage.sparse_views(Options::default()).unwrap();
    let binding = Binding::new(
        s3drive_core::manifest::base::Descriptor::from_hex(
            &"01".repeat(16),
            &"02".repeat(16),
            &"03".repeat(16),
            &"04".repeat(32),
        )
        .unwrap(),
        [5; 16],
        [6; 32],
        "07".repeat(32),
        "objects/".into(),
        32,
    )
    .unwrap();
    let view = client.begin([1; 32], binding, 32).await.unwrap();
    let view = client
        .write([2; 32], view.id(), 0, Arc::from("café 🦀".as_bytes()))
        .await
        .unwrap();
    (storage, client, view.id())
}
async fn active(storage: &Storage) -> usize {
    storage
        .owner
        .call(|store| {
            Ok(store.state.connection.query_row(
                "SELECT count(*) FROM source_read_pins",
                [],
                |r| r.get(0),
            )?)
        })
        .await
        .unwrap()
}
async fn submit_only<F: Future>(future: std::pin::Pin<&mut F>) {
    let mut future = future;
    std::future::poll_fn(|cx| {
        assert!(future.as_mut().poll(cx).is_pending());
        Poll::Ready(())
    })
    .await;
}
async fn block(storage: &Storage) -> std::sync::mpsc::Sender<()> {
    let (started, ready) = oneshot::channel();
    let (release, wait) = std::sync::mpsc::channel();
    storage
        .owner
        .sender
        .try_send(Command::Work(Box::new(move |_| {
            started.send(()).unwrap();
            wait.recv_timeout(Duration::from_secs(10)).unwrap();
        })))
        .unwrap_or_else(|_| panic!("block command admission"));
    ready.await.unwrap();
    release
}
#[tokio::test]
async fn clones_retain_one_exact_unicode_view_until_the_final_drop() {
    let temp = tempfile::tempdir().unwrap();
    let (storage, client, id) = fixture(temp.path()).await;
    let first = client.guard(id).await.unwrap();
    let second = first.clone();
    assert_eq!(first.view().id(), id);
    assert_eq!(active(&storage).await, 1);
    drop(first);
    assert_eq!(active(&storage).await, 1);
    assert_eq!(
        second.read(0, "café 🦀".len()).await.unwrap(),
        vec![Piece::Local("café 🦀".as_bytes().to_vec())]
    );
    drop(second);
    assert_eq!(active(&storage).await, 0);
    storage.close().await.unwrap();
}
#[tokio::test]
async fn final_drop_survives_a_completely_full_eight_command_queue() {
    let temp = tempfile::tempdir().unwrap();
    let (storage, client, id) = fixture(temp.path()).await;
    let guard = client.guard(id).await.unwrap();
    let release = block(&storage).await;
    let (done, ready) = oneshot::channel();
    for _ in 0..QUEUE_SIZE - 1 {
        storage
            .owner
            .sender
            .try_send(Command::Work(Box::new(|_| {})))
            .unwrap_or_else(|_| panic!("queue fill"));
    }
    storage
        .owner
        .sender
        .try_send(Command::Work(Box::new(move |_| {
            let _ = done.send(());
        })))
        .unwrap_or_else(|_| panic!("last queue slot"));
    drop(guard);
    assert_eq!(storage.owner.read_pins.lock().len(), 1);
    assert_eq!(storage.owner.sender.capacity(), 0);
    release.send(()).unwrap();
    ready.await.unwrap();
    assert_eq!(active(&storage).await, 0);
    assert!(storage.owner.read_pins.lock().is_empty());
    storage.close().await.unwrap();
}
#[tokio::test]
async fn canceled_queued_acquisition_and_unread_committed_reply_leave_no_pin() {
    let temp = tempfile::tempdir().unwrap();
    let (storage, client, id) = fixture(temp.path()).await;
    let release = block(&storage).await;
    let mut queued = Box::pin(client.guard(id));
    submit_only(queued.as_mut()).await;
    drop(queued);
    release.send(()).unwrap();
    assert_eq!(active(&storage).await, 0);
    let mut committed = Box::pin(client.guard(id));
    submit_only(committed.as_mut()).await;
    // FIFO barrier proves the guard was committed and sent, but its future has
    // not consumed the reply. Dropping that receiver drops the guard itself.
    assert_eq!(active(&storage).await, 1);
    drop(committed);
    assert_eq!(active(&storage).await, 0);
    storage.close().await.unwrap();
}
#[tokio::test]
async fn cleanup_failure_preserves_the_pin_and_retries_after_fault_removal() {
    let temp = tempfile::tempdir().unwrap();
    let (storage, client, id) = fixture(temp.path()).await;
    let guard = client.guard(id).await.unwrap();
    storage.owner.call(|s| { s.state.connection.execute_batch(
        "CREATE TRIGGER deny_guard_release BEFORE DELETE ON source_read_pins BEGIN SELECT RAISE(ABORT,'deny'); END;"
    )?; Ok(()) }).await.unwrap();
    drop(guard);
    assert_eq!(active(&storage).await, 1);
    assert_eq!(storage.owner.read_pins.lock().len(), 1);
    storage
        .owner
        .call(|s| {
            s.state
                .connection
                .execute_batch("DROP TRIGGER deny_guard_release")?;
            Ok(())
        })
        .await
        .unwrap();
    assert_eq!(active(&storage).await, 0);
    assert!(storage.owner.read_pins.lock().is_empty());
    storage.close().await.unwrap();
}
