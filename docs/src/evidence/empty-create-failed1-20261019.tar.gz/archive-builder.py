from pathlib import Path
import json,hashlib,tarfile,io,subprocess
root=Path('/home/marshall/src/worktrees/s3drive-empty-manifest-create')
out=root/'docs/src/evidence/empty-create-failed1-20261019.tar.gz';assert not out.exists()
run=json.loads(subprocess.check_output(['gh','api','repos/marshallr12/s3drive/actions/runs/39302692507/attempts/1']))
jobs=json.loads(subprocess.check_output(['gh','api','repos/marshallr12/s3drive/actions/runs/39302692507/attempts/1/jobs?per_page=100']))
assert run['head_sha']=='0c7f8b72bcea830760f437036d201eb9c077ea1b' and run['status']=='completed' and run['conclusion']=='failure'
assert {j['id'] for j in jobs['jobs']}=={118231697807,118231697493,118231698174}
assert all(j['status']=='completed' and j['head_sha']==run['head_sha'] for j in jobs['jobs'])
r=json.loads(Path('/tmp/s3drive-empty-create-gate1-result.json').read_text());assert r['exit_code']==101 and r['all_inputs_unchanged']
f=json.loads(Path('/tmp/s3drive-empty-create-candidate1-frozen.json').read_text());assert len(f)==349
with tarfile.open('/tmp/s3drive-empty-create-candidate1-source.tar.gz') as t:
 for name,digest in f.items():assert hashlib.sha256(t.extractfile(name).read()).hexdigest()==digest,name
files={}
for suffix in ['candidate1-frozen.json','candidate1-source.tar.gz','gate1.log','gate1-running.json','gate1-result.json','gate1-runner.py']:
 p=Path('/tmp/s3drive-empty-create-'+suffix);files[p.name]=p.read_bytes()
assert hashlib.sha256(files['s3drive-empty-create-gate1.log']).hexdigest()==r['sha256']
for job,name in [(118231697807,'book'),(118231697493,'linux'),(118231698174,'windows')]:
 p=Path('/tmp/s3drive-empty-create-hosted-'+name+'.log');assert p.is_file();files[p.name]=p.read_bytes()
files['run.json']=(json.dumps(run,indent=2)+'\n').encode();files['jobs.json']=(json.dumps(jobs,indent=2)+'\n').encode()
files['archive-builder.py']=Path(__file__).read_bytes()
index={name:hashlib.sha256(body).hexdigest() for name,body in files.items()}
with tarfile.open(out,'x:gz') as t:
 for name,body in sorted(files.items()):
  i=tarfile.TarInfo(name);i.mode=0o644;i.mtime=0;i.size=len(body);t.addfile(i,io.BytesIO(body))
 body=(json.dumps(index,indent=2)+'\n').encode();i=tarfile.TarInfo('sha256-index.json');i.mode=0o644;i.mtime=0;i.size=len(body);t.addfile(i,io.BytesIO(body))
with tarfile.open(out) as t:
 assert set(t.getnames())==set(index)|{'sha256-index.json'}
 for name,digest in index.items():assert hashlib.sha256(t.extractfile(name).read()).hexdigest()==digest,name
proof={'source':run['head_sha'],'run':run['id'],'path':str(out.relative_to(root/'docs/src')),'sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'bytes':out.stat().st_size,'members':len(index)+1,'all_members_verified':True,'scope':'failed first cohort only; not acceptance'}
Path('/tmp/s3drive-empty-create-failed1-archive-proof.json').write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps(proof))
