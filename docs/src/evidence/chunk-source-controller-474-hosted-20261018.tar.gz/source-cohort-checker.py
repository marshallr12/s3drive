"""One-use checker: a complete, reviewed exact chunk source controller cohort only; all GitHub calls GET."""
import datetime
import hashlib
import io
import json
from pathlib import Path
import re
import subprocess
import zipfile

SOURCE = '474601edd5582ebed9316d04cf4524db6d72694b'
RUN = 39165918104
ATTEMPT = 1
REPO = 'marshallr12/s3drive'
ROOT = Path('/home/marshall/src/s3drive')
JOBS = {117788707767: 'rust (windows-latest)', 117788707918: 'book', 117788707913: 'rust (ubuntu-latest)'}
PRIMARY_ARTIFACT_IDS = {12149243457, 12149814008, 12147997314, 12147329360, 12147331157, 12147209844, 12146631312, 12146506974, 12145416969, 12145194101, 12144981486, 12144507996, 12143780290, 12143656516, 12142621547, 12142503573, 12139939008, 12141530185, 12140403755, 12139721137, 12141120690, 12139390103, 12140285720, 12139435870}
OUTPUT = Path('/tmp/s3drive-chunk-source-controller-474-artifacts')
MARKER = Path('/tmp/s3drive-chunk-source-controller-474-raw-reviewed.json')

def gh_json(endpoint):
    return json.loads(subprocess.check_output(['gh', 'api', f'repos/{REPO}/{endpoint}']))

def instant(value):
    return datetime.datetime.fromisoformat(value.replace('Z', '+00:00'))

run = gh_json(f'actions/runs/{RUN}/attempts/{ATTEMPT}')
assert run['id'] == RUN and run['run_attempt'] == ATTEMPT and run['head_sha'] == SOURCE
assert run['status'] == 'completed' and run['conclusion'] == 'success'
jobs = gh_json(f'actions/runs/{RUN}/attempts/{ATTEMPT}/jobs?per_page=100')
assert jobs['total_count'] == 3
assert {j['id']: j['name'] for j in jobs['jobs']} == JOBS
assert all(j['run_id'] == RUN and j['run_attempt'] == ATTEMPT and j['head_sha'] == SOURCE
           and j['status'] == 'completed' and j['conclusion'] == 'success' for j in jobs['jobs'])
review = json.loads(MARKER.read_text())
assert review['source'] == SOURCE and review['run_id'] == RUN and review['run_attempt'] == ATTEMPT
assert review['reviewed'] is True and set(review['jobs']) == {str(j) for j in JOBS}
for job, entry in review['jobs'].items():
    assert entry['job_id'] == int(job) and entry['run_attempt'] == ATTEMPT and entry['reviewed'] is True
    assert hashlib.sha256(Path(entry['log']).read_bytes()).hexdigest() == entry['sha256']
for job_id in ('117788707767', '117788707913'):
    raw = Path(review['jobs'][job_id]['log']).read_text()
    for name in ['chunk_sources_publish_unicode_sparse_empty_and_acknowledge_exact_history', 'chunk_sources_killed_unknown_publish_recovers_without_credentials_or_source_bytes', 'chunk_sources_killed_after_failed_ack_recovers_known_root_without_rpc', 'chunk_sources_expired_narrow_policy_busy_and_concurrent_first_ack']:
        assert re.search(r'test ' + re.escape(name) + r' \.\.\. ok', raw), (job_id, name)
    assert '12 passed; 0 failed' in raw
windows = next(j for j in jobs['jobs'] if j['id'] == 117788707767)
raw_log = Path(review['jobs']['117788707767']['log']).read_text()
log = re.sub(r'\x1b\[[0-9;]*[A-Za-z]', '', raw_log)
ids = {}
for kind in ('replacement', 'disposition'):
    name = f'windows-{kind}-reference-{SOURCE}'
    matches = re.findall(r'Artifact ' + re.escape(name) + r'\.zip successfully finalized\. Artifact ID (\d+)', log)
    assert len(matches) == 1, (kind, 'not exactly one own finalized artifact')
    ids[kind] = int(matches[0])
assert len(set(ids.values())) == 2 and not set(ids.values()) & PRIMARY_ARTIFACT_IDS
metadata = gh_json(f'actions/runs/{RUN}/artifacts?per_page=100')
assert metadata['total_count'] == len(metadata['artifacts'])
selected = [a for a in metadata['artifacts'] if a['id'] in ids.values()]
assert len(selected) == 2 and {a['id'] for a in selected} == set(ids.values())
for artifact in selected:
    kind = next(k for k, v in ids.items() if v == artifact['id'])
    assert artifact['name'] == f'windows-{kind}-reference-{SOURCE}'
    assert artifact['expired'] is False
    assert artifact['workflow_run']['id'] == RUN and artifact['workflow_run']['head_sha'] == SOURCE
    assert instant(windows['started_at']) <= instant(artifact['created_at']) <= instant(windows['completed_at'])
    assert instant(artifact['updated_at']) <= instant(windows['completed_at'])
for name in ('scripts/windows-replacement-fixture.ps1', 'scripts/windows-reference-fixture.ps1',
             'docs/src/evidence/windows-replacement-reference-20261017.json',
             'docs/src/evidence/windows-disposition-reference-20261017.json'):
    assert (ROOT / name).read_bytes() == subprocess.check_output(['git', '-C', str(ROOT), 'show', SOURCE + ':' + name])
identity = json.loads(subprocess.check_output(['gh', 'repo', 'view', REPO, '--json', 'nameWithOwner,visibility']))
assert identity['nameWithOwner'] == REPO and identity['visibility'] == 'PUBLIC'
frozen = json.loads(Path('/tmp/s3drive-chunk-source-controller-frozen.json').read_text())
assert len(frozen) == 253
for path, digest in frozen.items():
    assert hashlib.sha256((ROOT / path).read_bytes()).hexdigest() == digest
    assert hashlib.sha256(subprocess.check_output(['git', '-C', str(ROOT), 'show', SOURCE + ':' + path])).hexdigest() == digest
OUTPUT.mkdir(mode=0o700)
for name, value in [('run', run), ('jobs', jobs), ('artifact-metadata', selected)]:
    (OUTPUT / f'{name}.json').write_text(json.dumps(value, indent=2) + '\n')
proof = []
for artifact in selected:
    kind = next(k for k, v in ids.items() if v == artifact['id'])
    raw = subprocess.check_output(['gh', 'api', f'repos/{REPO}/actions/artifacts/{artifact["id"]}/zip'])
    digest = hashlib.sha256(raw).hexdigest()
    assert artifact['digest'] == 'sha256:' + digest
    name = f'windows-{kind}-reference.json'
    with zipfile.ZipFile(io.BytesIO(raw)) as archive:
        assert archive.namelist() == [name] and archive.getinfo(name).file_size < 1024 * 1024
        data = archive.read(name)
    (OUTPUT / f'{kind}.zip').write_bytes(raw)
    (OUTPUT / name).write_bytes(data)
    proof.append({'kind': kind, 'id': artifact['id'], 'source': SOURCE, 'run_id': RUN, 'run_attempt': ATTEMPT,
                  'windows_job': windows['id'], 'zip_sha256': digest, 'json_sha256': hashlib.sha256(data).hexdigest(),
                  'primary_artifact_reused': False})
(OUTPUT / 'download-proof.json').write_text(json.dumps(proof, indent=2) + '\n')
check = subprocess.check_output(['python3', '/tmp/s3drive-check-native-artifacts.py', '--source', SOURCE,
                                '--directory', str(OUTPUT), '--repository', str(ROOT)])
(OUTPUT / 'independent-check.json').write_bytes(check)
project = subprocess.check_output(['pwsh', '-NoProfile', '-NonInteractive', '-File',
                                   '/tmp/s3drive-chunk-source-controller-474-reference-check.ps1'])
(OUTPUT / 'project-oracles.log').write_bytes(project)
print(check.decode(), end='')
print(project.decode(), end='')
print(json.dumps(proof, indent=2))
