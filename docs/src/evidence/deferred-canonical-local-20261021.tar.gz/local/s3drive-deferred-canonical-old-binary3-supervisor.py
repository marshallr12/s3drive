from pathlib import Path
import subprocess,json
p=subprocess.run(['python3','/tmp/s3drive-deferred-canonical-old-binary3.py'])
Path('/tmp/s3drive-deferred-canonical-old-binary3-exit.json').write_text(json.dumps({'exit_code':p.returncode})+'\n')
raise SystemExit(p.returncode)
