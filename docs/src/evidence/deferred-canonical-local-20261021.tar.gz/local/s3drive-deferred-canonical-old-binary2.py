"""Owned Linux compatibility control. Run only after the new full gate closes."""
from pathlib import Path
import hashlib,json,os,subprocess,tempfile,sqlite3
from contextlib import closing
root=Path('/home/marshall/src/worktrees/s3drive-deferred-canonical-create');oldroot=Path('/home/marshall/src/worktrees/s3drive-chunk-directories')
source='3e670915cdfe3dbafee9cd40c33d1a70cf979234';oldsource='fea3b379e9d8ee6124c0ee9b3526f11c010d6f04'
base=Path('/tmp/s3drive-deferred-canonical-old-binary');assert not Path(str(base)+'-result.json').exists()
gate=json.loads(Path('/tmp/s3drive-deferred-canonical-gate2-result.json').read_text());assert gate['head']==source and gate['exit_code']==0 and gate['unchanged']
newmap=json.loads(Path('/tmp/s3drive-deferred-canonical-candidate2-frozen.json').read_text());oldmap=json.loads(Path('/tmp/s3drive-chunk-directories-candidate3-frozen.json').read_text())
def verify(where,sha,files):
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=where,text=True).strip()==sha
 assert not subprocess.check_output(['git','status','--porcelain'],cwd=where,text=True).strip()
 for p,digest in files.items():assert hashlib.sha256((where/p).read_bytes()).hexdigest()==digest,p
verify(root,source,newmap);verify(oldroot,oldsource,oldmap)
env=os.environ.copy();env['CARGO_TARGET_DIR']='/home/marshall/src/s3drive/target';env['RUST_TEST_THREADS']='4'
exe=Path(env['CARGO_TARGET_DIR'])/'debug/s3drive'
def digest(p):return hashlib.file_digest(p.open('rb'),'sha256').hexdigest()
proof={'new_source':source,'old_source':oldsource,'platform':'Linux','new_runtime_inputs':len(newmap),'old_runtime_inputs':len(oldmap)}
with tempfile.TemporaryDirectory(prefix='s3drive-schema-forward-control-') as temporary:
 state=Path(temporary)/'state'
 initial=subprocess.run([str(exe),'init-state','--directory',str(state)],capture_output=True,text=True,timeout=30)
 assert initial.returncode==0 and 'schema=42' in initial.stdout
 proof['new_binary_sha256']=digest(exe);proof['new_initial_stdout']=initial.stdout
 database=state/'metadata.sqlite3';before=digest(database)
 with closing(sqlite3.connect(database)) as db:assert db.execute('PRAGMA user_version').fetchone()[0]==42
 try:
  with Path(str(base)+'-old-build.log').open('wb') as log:subprocess.run(['cargo','build','-p','s3drive-cli','--locked'],cwd=oldroot,env=env,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=600)
  proof['old_binary_sha256']=digest(exe)
  old=subprocess.run([str(exe),'init-state','--directory',str(state)],capture_output=True,text=True,timeout=30)
  proof['old_exit_code']=old.returncode;proof['old_stdout']=old.stdout;proof['old_stderr']=old.stderr
  assert old.returncode!=0 and digest(database)==before
  with closing(sqlite3.connect(database)) as db:assert db.execute('PRAGMA user_version').fetchone()[0]==42
  proof['old_refused_schema42']=True;proof['database_bytes_unchanged']=True
 finally:
  # Restore the new source through Cargo, never copy a binary over its fingerprint.
  with Path(str(base)+'-restore-new-build.log').open('wb') as log:subprocess.run(['cargo','build','-p','s3drive-cli','--locked'],cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=600)
 restored=subprocess.run([str(exe),'init-state','--directory',str(state)],capture_output=True,text=True,timeout=30)
 assert restored.returncode==0 and 'schema=42' in restored.stdout
 proof['new_binary_restored_by_cargo']=True;proof['restored_binary_sha256']=digest(exe)
verify(root,source,newmap);verify(oldroot,oldsource,oldmap)
Path(str(base)+'-result.json').write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps(proof))
