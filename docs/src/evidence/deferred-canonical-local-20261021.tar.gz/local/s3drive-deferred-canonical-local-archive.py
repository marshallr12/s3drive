import gzip,hashlib,io,json,subprocess,tarfile
from pathlib import Path
root=Path('/home/marshall/src/worktrees/s3drive-deferred-canonical-create');source='feead7700aee4a4e5af825cb13c3cf6399cdcd61'
out=Path('/tmp/deferred-canonical-local-20261021.tar.gz');assert not out.exists()
result=json.loads(Path('/tmp/s3drive-deferred-canonical-gate1-result.json').read_text());frozen=json.loads(Path('/tmp/s3drive-deferred-canonical-gate1-source.json').read_text())
assert result['head']==frozen['head']==source and result['exit_code']==0 and result['unchanged']
for name,digest in frozen['inputs'].items():assert hashlib.sha256((root/name).read_bytes()).hexdigest()==digest,name
runtime=json.loads(Path('/tmp/s3drive-deferred-canonical-candidate1-frozen.json').read_text());assert len(runtime)==372
members={}
def add(name,data):
 assert name not in members and not name.startswith('/') and '..' not in Path(name).parts
 members[name]=data
for name,digest in runtime.items():
 data=(root/name).read_bytes();assert hashlib.sha256(data).hexdigest()==digest;add('source/'+name,data)
for p in sorted(Path('/tmp').glob('s3drive-deferred-canonical-*')):
 if p.is_file() and 'hosted' not in p.name and p.suffix in ['.log','.json','.py']:add('local/'+p.name,p.read_bytes())
add('local/candidate1.patch',subprocess.check_output(['git','diff','--binary','19ac76f',source],cwd=root))
for name in ['HANDOFF.md','docs/src/atomic-deferred-manifest-create.md','docs/src/deferred-manifest-integration.md']:add('declared/'+name,(root/name).read_bytes())
index={'source':source,'runtime_inputs':372,'all_gate_inputs':709,'scope':'own full local authority/state gate; hosted/native and provider acceptance separate','members':{n:{'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()} for n,b in sorted(members.items())}}
add('index.json',(json.dumps(index,indent=2)+'\n').encode())
with out.open('xb') as disk:
 with gzip.GzipFile(filename='',fileobj=disk,mode='wb',mtime=0) as gz:
  with tarfile.open(fileobj=gz,mode='w') as t:
   for name,data in sorted(members.items()):
    i=tarfile.TarInfo(name);i.size=len(data);i.mode=0o644;i.mtime=0;t.addfile(i,io.BytesIO(data))
with tarfile.open(out) as t:
 assert len(t.getmembers())==len(members)
 for n,b in members.items():assert t.extractfile(n).read()==b
proof={'archive':str(out),'members':len(members),'bytes':out.stat().st_size,'sha256':hashlib.file_digest(out.open('rb'),'sha256').hexdigest(),'all_members_verified':True}
Path('/tmp/s3drive-deferred-canonical-local-archive-proof.json').write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps(proof))
