from pathlib import Path
from contextlib import closing
import hashlib,json,os,subprocess,tempfile,sqlite3
root=Path('/home/marshall/src/worktrees/s3drive-deferred-canonical-create');oldroot=Path('/home/marshall/src/worktrees/s3drive-chunk-directories')
source='3e670915cdfe3dbafee9cd40c33d1a70cf979234';oldsource='fea3b379e9d8ee6124c0ee9b3526f11c010d6f04'
base=Path('/tmp/s3drive-deferred-canonical-old-binary4');final=Path('/tmp/s3drive-deferred-canonical-old-binary-result.json');assert not final.exists()
gate=json.loads(Path('/tmp/s3drive-deferred-canonical-gate3-result.json').read_text());assert gate['head']==source and gate['exit_code']==0 and gate['unchanged']
newmap=json.loads(Path('/tmp/s3drive-deferred-canonical-candidate2-frozen.json').read_text());oldmap=json.loads(Path('/tmp/s3drive-chunk-directories-candidate3-frozen.json').read_text())
def verify(where,sha,files):
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=where,text=True).strip()==sha
 assert not subprocess.check_output(['git','status','--porcelain'],cwd=where,text=True).strip()
 for name,digest in files.items():assert hashlib.sha256((where/name).read_bytes()).hexdigest()==digest,name
verify(root,source,newmap);verify(oldroot,oldsource,oldmap)
env=os.environ.copy();env['CARGO_TARGET_DIR']='/home/marshall/src/s3drive/target';env['RUST_TEST_THREADS']='4';exe=Path(env['CARGO_TARGET_DIR'])/'debug/s3drive'
def digest(path):return hashlib.file_digest(path.open('rb'),'sha256').hexdigest()
proof={'new_source':source,'old_source':oldsource,'platform':'Linux','new_runtime_inputs':372,'old_runtime_inputs':368,'method':'invalidate only s3drive-state artifacts at each worktree switch; actual CLI schema checks; shared target freshness alone is not proof'}
def save(stage):
 proof['stage']=stage;Path(str(base)+'-progress.json').write_text(json.dumps(proof,indent=2)+'\n')
def build(where,label):
 with Path(str(base)+'-'+label+'-build.log').open('xb') as log:
  for args in [['cargo','clean','-p','s3drive-state'],['cargo','build','-p','s3drive-cli','--locked']]:subprocess.run(args,cwd=where,env=env,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=600)
def init(path):return subprocess.run([str(exe),'init-state','--directory',str(path)],capture_output=True,text=True,timeout=30)
with tempfile.TemporaryDirectory(prefix='s3drive-schema-forward-control4-') as temporary:
 fixture=Path(temporary);state=fixture/'state'
 build(root,'new-initial');r=init(state);proof['initial']={'exit_code':r.returncode,'stdout':r.stdout,'stderr':r.stderr};save('initial-new');assert r.returncode==0 and 'schema=42' in r.stdout
 proof['new_binary_sha256']=digest(exe);database=state/'metadata.sqlite3';before=digest(database)
 with closing(sqlite3.connect(database)) as db:assert db.execute('PRAGMA user_version').fetchone()[0]==42
 try:
  build(oldroot,'old');sanity=init(fixture/'old-sanity');proof['old_sanity']={'exit_code':sanity.returncode,'stdout':sanity.stdout,'stderr':sanity.stderr};save('old-built');assert sanity.returncode==0 and 'schema=41' in sanity.stdout
  proof['old_binary_sha256']=digest(exe);r=init(state);proof['old_exit_code']=r.returncode;proof['old_stdout']=r.stdout;proof['old_stderr']=r.stderr;save('old-attempt')
  assert r.returncode!=0 and 'schema' in r.stderr.lower() and digest(database)==before
  with closing(sqlite3.connect(database)) as db:assert db.execute('PRAGMA user_version').fetchone()[0]==42
  proof['old_refused_schema42']=True;proof['database_bytes_unchanged']=True;save('old-refused')
 finally:
  build(root,'new-restored')
 r=init(state);proof['restored']={'exit_code':r.returncode,'stdout':r.stdout,'stderr':r.stderr};save('new-restored');assert r.returncode==0 and 'schema=42' in r.stdout
 proof['new_binary_restored_by_cargo']=True;proof['restored_binary_sha256']=digest(exe)
verify(root,source,newmap);verify(oldroot,oldsource,oldmap);proof['stage']='complete';final.write_text(json.dumps(proof,indent=2)+'\n');save('complete');print(json.dumps(proof))
