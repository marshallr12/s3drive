from pathlib import Path
import hashlib,json,shutil
root=Path('/home/marshall/src/worktrees/s3drive-deferred-canonical-create');source='3e670915cdfe3dbafee9cd40c33d1a70cf979234'
base=Path('/tmp/s3drive-deferred-canonical-hosted2')
run=json.loads(Path(str(base)+'-result.json').read_text());assert run['headSha']==source and run['conclusion']=='success' and len(run['jobs'])==3 and all(j['conclusion']=='success' for j in run['jobs'])
review=json.loads(Path(str(base)+'-raw-reviewed.json').read_text());assert review['source']==source and review['reviewed'] and review['test_faults']==0
local=json.loads(Path('/tmp/s3drive-deferred-canonical-gate3-result.json').read_text());assert local['head']==source and local['exit_code']==0 and local['unchanged']
compat=json.loads(Path('/tmp/s3drive-deferred-canonical-old-binary-result.json').read_text());assert compat['new_source']==source and compat['old_refused_schema42'] and compat['database_bytes_unchanged'] and compat['new_binary_restored_by_cargo']
frozen=json.loads(Path('/tmp/s3drive-deferred-canonical-candidate2-frozen.json').read_text());assert len(frozen)==372
for p,h in frozen.items():assert hashlib.sha256((root/p).read_bytes()).hexdigest()==h,p
archives=[]
for kind in ['local','hosted']:
 proof=json.loads(Path(f'/tmp/s3drive-deferred-canonical-{kind}-archive-proof.json').read_text());assert proof['all_members_verified'];archive=Path(proof['archive']);assert hashlib.file_digest(archive.open('rb'),'sha256').hexdigest()==proof['sha256']
 target=root/'docs/src/evidence'/archive.name;assert not target.exists();shutil.copyfile(archive,target);archives.append((kind,proof))
image=root/'docs/src/images/atomic-deferred-canonical.svg';assert not image.exists();shutil.copyfile('/tmp/s3drive-deferred-canonical-transaction.svg',image)
p=root/'docs/src/atomic-deferred-manifest-create.md';s=p.read_text();s=s.replace('Declared2026-10-21 from accepted main19ac76f/schema41/runtime368. Proposal and\nimplementation candidate until its own gates pass. This is an authority/state','Declared2026-10-21 from accepted main19ac76f/schema41/runtime368. The\nauthority/state prerequisite is now accepted; the dated candidate history below\nis retained. This is an authority/state')
s+='\n\n## Authority/state acceptance —2026-10-21\n\n'
s+=f'Runtime `{source}`, schema42/all372, exactly16 runtime paths from accepted\nmain19ac76f. No new tables/dependencies or old BLOB/hash rewrites. Own full local\ngate3 passed{local["elapsed_seconds"]}s with all709 inputs unchanged; logSHA\n`{local["log_sha256"]}`.\n'
s+=f'Own [CI{run["databaseId"]}](https://github.com/marshallr12/s3drive/actions/runs/{run["databaseId"]})\nattempt1 Linux/Windows/book all succeeded. Exact GitHub ZIP/all709 digests,\nAPI artifact ZIP digests, strict typed21+14/project oracles, every raw-record\nfield/type and full raw-log/warning/slow/interleaved review passed.\n\n'
s+='The13 new state tests and authenticated HTTP case passed within the complete\nsuites. They cover eight killed-owner points, actual SQLITE_FULL, initial and\nsuccessor owner separation, later owned manifest publication, name/store/parent\nraces, missing/forged retained history and events, closing credits,41→42 migration\nand private snapshot copy/inspection without restore rights. Existing real FUSE/\nWinFsp, Unicode chunk folders and file I/O/remount,128KiB callback controls and\nstartup regressions passed on the same source. No new native lifecycle callback\nwas enabled and no S3 upload was performed by the new metadata-only tests.\n\n'
s+='A separate Linux binary compatibility control built the accepted schema41\nsourcefea3b379, which refused a disposable schema42 database without changing its\nbytes. Cargo rebuilt the new source afterward and its binary reopened42. The\ncontrol does not install or upgrade a real user database.\n\n'
s+='Candidatefeead770/gate1 remains rejected: stale41 fixture expectation,551\nstate passed/1failed/1ignored locally; both hosted Rust jobs rejected it. Corrected\nsource3e670915 gate2 completed its tests but lost its supervisor (exit143) before\na final status could be recorded. The orphan child was verified live, then\nreaped; its final exit was not inferred from logs. Only afterward did gate3\nrepeat with a session-isolated supervisor and retain the authoritative status.\n\n'
for kind,proof in archives:s+=f'- [{kind.title()} indexed archive](evidence/{Path(proof["archive"]).name}): {proof["members"]} members, {proof["bytes"]} bytes; SHA256 `{proof["sha256"]}`. Every member verified.\n'
s+='\n![Rust authority atomically stores canonical file metadata, original fence/event and exact result; the future SDK verifies the S3 object.](images/atomic-deferred-canonical.svg)\n\n'
s+='The physical root is still a caller claim at the metadata service. The next\nphase must persist the original creator/physical proof and import its exact\nreceipt into the same-owner open journal. Sparse owned-unlinked publication must\nbind the original fence and current removal event. Native delete-on-close,\nsave-replace/rename/delete, retention/GC and cold recovery remain unsupported in\nthe chunk profile. Real managed Wasabi, physical MX/Windows10/11 reboot/session,\nindependent-host deployment/restore and usable packaging remain separate gates.\nBoth hosting options and optional Turso remain open. No provider authorization,\ncredentials, service provision or user startup installation is implied.\n';p.write_text(s)
p=root/'docs/src/deferred-manifest-integration.md';s=p.read_text();old='Source review dated2026-10-19. Proposal only, not implemented or a resolved\nwire/API contract. Reviewed against\n66d78db. Keep native delete-on-close/save-replace flags unsupported until proven.';assert old in s;s=s.replace(old,'Original source review dated2026-10-19 against66d78db. The\n[atomic deferred canonical authority/state contract](atomic-deferred-manifest-create.md)\nis now implemented and independently accepted at3e670915/schema42. The SDK\nprovenance import, owned-unlinked publisher and native lifecycle integration\nbelow remain future work. Keep delete-on-close/save-replace flags unsupported.');p.write_text(s)
p=root/'docs/src/architecture.md';s=p.read_text();needle='The [read-pin diagram](source-read-pins.md) explains retained source dependencies.';assert s.count(needle)==1;s=s.replace(needle,needle+'\n\n[Atomic deferred canonical creation](atomic-deferred-manifest-create.md) now\ncommits the empty canonical payload/history, original removal fence/event and\nexact result in one authority SQLite transaction. The service holds no S3\ncredentials and records the caller\'s upload claim. Client provenance import and\nchunk-backed native lifecycle callbacks remain separate work.\n\n![Atomic authority transaction with original ownership and an explicitly future SDK-to-S3 bridge.](images/atomic-deferred-canonical.svg)');p.write_text(s)
p=root/'README.md';s=p.read_text();needle='This remains an experimental profile.';assert s.count(needle)==1;s=s.replace(needle,'The [atomic deferred canonical creation prerequisite](docs/src/atomic-deferred-manifest-create.md)\nis accepted at3e670915/schema42 with its own full local and Linux/Windows/book\ngates. It commits canonical metadata and original removal ownership together;\nits client journal/open import and native lifecycle integration remain pending.\n\n'+needle);p.write_text(s)
p=root/'docs/src/implementation-plan.md';s=p.read_text();s+=f'''\n\n### Atomic deferred canonical authority/state accepted —2026-10-21

[Contract and indexed evidence](atomic-deferred-manifest-create.md),3e670915,
schema42/all372,16 runtime deltas from19ac76f. Full local gate3
{local['elapsed_seconds']}s/all709 unchanged and own CI39579144740 all3 passed.
Raw/source/API ZIP/strict21+14/project/all35 field/type and full warning/slow/
interleaved review passed.13 state +1 HTTP, eight crash points, actual SQLITE_FULL,
exact initial ownership/history, successor-owner separation, later owned roots,
byte-preserving migration, snapshot inspection and a real old-Linux-binary42
refusal control passed. Existing FUSE/WinFsp and startup regressions passed.
The initial authority transaction is implemented; SDK intent/provenance import,
sparse owned-unlinked publication and native lifecycle flags remain subsequent
phases. Retention/GC, cold recovery, physical startup and real-provider/remote
service acceptance remain required. No provider or visibility mutation authorized.
''';p.write_text(s)
p=root/'HANDOFF.md';before=p.read_text();archive=root/'docs/archive/HANDOFF-before-deferred-canonical-refresh-20261021.md';assert not archive.exists();archive.write_text(before)
# Keep accepted drive behavior/permissions and replace phase-specific live state.
s=before;start=s.index('## Accepted runtime and publication');end=s.index('## Next work and boundaries')
s=s[:start]+f'''## Accepted runtime and publication

Runtime `{source}`, schema42/all372,16 runtime deltas from main19ac76f.
[Authority/state contract and evidence](docs/src/atomic-deferred-manifest-create.md).
Full local gate3 CLOSED0/{local['elapsed_seconds']}s/all709 unchanged, logSHA
{local['log_sha256']}.
Own CI39579144740 attempt1 Linux/Windows/book all success. Exact source/API ZIP,
strict21+14/project/all35 raw fields/types and full raw-log review passed.
Canonical publication proof will be /tmp/s3drive-canonical-deferred-canonical-publication.json;
verify current HEAD/remote and runtime372 rather than copying historical19ac.

CreateDeferredEmptyManifest commits canonical node/payload/upload history plus
original removal fence and initial event in one transaction. PublishedRemoval
contains payload and exact fence; replay checks immutable initial evidence,
keeps older receipts after content/mode/name/epoch changes, never adopts a newer
owner. Schema42 marker only;64-table snapshot bound, old BLOB/hash bytes retained.
The authority records upload claims, has no S3 credentials. No SDK creation/import,
sparse owned-unlinked or OS lifecycle callback is enabled by this phase.

Version8 canonical file create/read/write/resize/exact-view flush and nested
Unicode directory create/list/remount remain natively verified. Four bounded
owned Tokio tasks, abort-on-drop and128KiB callback control unchanged. Old
profiles3–7 retain behavior and older writable8MiB bounds. Dirty/newer edits and
unknown identities remain preserved. Hosted Ubuntu and WindowsServer2025 use
owned loopback fixtures; not physical MX/Windows10/11 or live managed Wasabi.

## Evidence and superseded runs

Indexed local/hosted deferred-canonical archives in docs/src/evidence; every member
verified. Exact hashes/counts, job/raw review and all inherited directory/file-I/O
archives are linked from the contract. /tmp/s3drive-deferred-canonical-checkpoint.json
and candidate2-frozen.json hold continuation pointers. Archive writers DONE,
never rerun. Real schema41 Linux binaryfea3b379 refused42 unchanged; Cargo restored
new binary. No user database or startup installation touched.

Development check1 visibility/tests2 signed-SQL conversion errors retained;
tests3 red missing-history NotFound normalized to integrity error. Focused2
13state/1HTTP/Clippy passed. Candidatefeead770 gate1 failed stale41 expectation
773.99s unchanged; both hosted Rust jobs failed the same fixture. Source3e670915
gate2 lost its supervisor after tests, child was waited to reaping without
inferring its exit. Only fresh isolated-supervisor gate3 counts as full acceptance.
Earlier native directory/file stack rejections remain in their own indexed
archives. No timeout, stack threshold or dirty-preservation barrier was weakened.

'''+s[end:]
active=s.find('\n\n## Active authority prerequisite candidate')
if active!=-1:s=s[:active]+'\n'
s=s.replace('1. Declare rename/delete/save-replace, deferred canonical creation and owned-\n   unlinked publication phases.','1. Implement the durable deferred creation SDK and exact verified creator-to-open\n   journal import, then sparse owned-unlinked and native lifecycle phases.')
s=s.replace('runtime368\nmap','runtime372\nmap').replace('No subagents were authorized/spawned for this phase.','No subagents were authorized/spawned for this phase.')
s+='\nBefore refresh handoff archived verbatim in docs/archive/HANDOFF-before-deferred-canonical-refresh-20261021.md.\n'
p.write_text(s)
proof={'before_lines':len(before.splitlines()),'after_lines':len(s.splitlines()),'archive':str(archive.relative_to(root)),'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest()};Path('/tmp/s3drive-deferred-canonical-handoff-refresh.json').write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps(proof))
