# Atomic deferred canonical creation

Declared2026-10-21 from accepted main19ac76f/schema41/runtime368. Proposal and
implementation candidate until its own gates pass. This is an authority/state
prerequisite for chunk-backed delete-on-close, not native lifecycle activation.

The accepted empty-manifest mutation commits canonical64-byte root metadata,
file node, upload history and exact operation result together. Existing deferred
creation instead commits a metadata-empty node plus an original removal fence.
Combining those two calls would leave an observable/crash boundary without the
required original ownership. Source findings: namespace/publication/empty.rs,
namespace/removals.rs::{created,origin}, and removals/events.rs::proof.

The explicit wire mutation is `create-deferred-empty-manifest`, with the same
parent/revision/name/store/upload proof fields as `create-empty-manifest` and an
additional32-hex-digit nonzero `owner`. The feature is
`atomic-deferred-empty-manifest-v1`. Its receipt artifact is `published-removal`,
containing `payload` and `fence`. The fence intent is the original operation ID;
its owner is the exact requested owner. No path or later node can mint that fence.
The authority still records a caller's physical-upload claim; it does not gain
S3 credentials or independently verify an object body.

Reuse canonical root derivation and exact historical receipt checks. One immediate
SQLite transaction commits the node, canonical payload/upload history, deferred
removal row, initial removal event, volume sequence and exact operation result.
The initial reservation retains its ordinary canonical payload identity; the
removal fence governs later owned work. Validate the resulting history and
original ownership before committing. A failure must leave the entire old state
or the complete new state; no partial success receipt is returned.

Use schema42 as a compatibility fence, without new tables or old BLOB/hash
rewrites. Existing schema41 records remain byte-identical. New operations under
an earlier schema marker are rejected before migration; old binaries refuse42.
The64-table snapshot bound remains unchanged. Old mutation/artifact JSON vectors
must remain unchanged. Existing clients do not fabricate creation provenance or
silently accept the new artifact as an ordinary namespace admission.

Done criteria for this phase:

- Authority feature negotiation, exact wire validation, canonical empty root,
  original fence/event and retained upload-history reads work through real APIs.
- Exact replay and operation lookup retain the original receipt after cancellation,
  mode changes, rename/removal, later content, restart and concurrent contenders.
  Changed operation bytes, owner, store, parent revision and malformed proof fail
  explicitly. Fresh unrelated sequence advancement must not replace entry guards.
- Killed-owner checkpoints and SQLITE_FULL tests cover node, payload/history,
  removal/event, outcome, sequence and commit boundaries. Missing/ignored/rewritten
  rows and forged ownership/history refuse success and roll back.
- Migration preserves existing request/outcome bytes and rejects downgraded42
  operations. Preserve operation closing credits, quota/collision and64-table
  snapshot behavior. Full local gate and own hosted Linux/Windows/book regression
  acceptance are required before promotion.

Expected footprint: namespace mutation/artifact validation, shared canonical
creation helper and deferred module/tests, removal origin/event proofs, manifest
history reads, schema marker/migration checks, authority feature/wire tests,
native schema assertions and mdBook/handoff. No dependency, S3 executor, SDK
creation journal, sparse publisher or OS callback change is intended. Future
phases must import exact verified creation provenance into the same-owner open
journal and bind owned-unlinked reservations to the original fence/event before
enabling native save-replace/delete-on-close. GC, cold recovery, real-provider
and physical startup acceptance remain separate. Both hosting choices and
optional Turso remain open; no service or credentials are provisioned.


## Candidate status —2026-10-21

The authority/state candidate implements the explicit mutation and combined
artifact, using a private projection into the existing canonical physical-proof
helper. The projection is never stored or sent; the original owned request is
retained byte-for-byte. Replay checks the immutable initial removal event and
canonical upload history, without comparing an old receipt with a newer live
node. Later owned root publication and a replacement ownership epoch retain
the original receipt and cannot rebind its fence. No new tables or dependencies.

Focused2 passed13 state tests, one authenticated HTTP contender/restart case,
and workspace/all-target Clippy. Tests cover eight killed-owner points, explicit
SQLITE_FULL rollback/exact retry, operation closing credits, name/store/parent/
proof validation, missing/forged history/events, old-marker laundering (including
an artifact attached to an old operation), byte-preserving41→42 migration and
private offline snapshot inspection without restore rights. The HTTP case uses
normalization-colliding Unicode names in two stores and the production wire
client. It records caller upload claims, not actual S3 writes.

Earlier development evidence is retained: check1 found a helper visibility error;
tests2 found a gated unsigned SQLite conversion, resolved by reading signed SQL
integers and checking the conversion; tests3 exposed a missing-history NotFound
classification, corrected to an integrity error; focused1 stopped at a malformed
test literal before running Cargo. Tests1 passed3 initial cases and tests4 passed10
before the final later-publication/snapshot/epoch cases. Only the final unchanged
source can receive complete acceptance. Full local and own hosted/native gates
remain pending. Native lifecycle flags, client creation journals, provenance
import and sparse owned-unlinked publication are deliberately unchanged.


Candidatefeead770 complete local gate1 stopped after773.99s/exit101, all709
inputs unchanged.551 state tests passed,1 failed,1 ignored: an older ownership
fixture correctly refused a missing role but then expected its unchanged current
marker to be41 instead of42. Its explicit pre41 downgrade40 expectation remains
40; the current-marker branch is corrected to SCHEMA_VERSION. The hosted Linux
cohort also failed that fixture. No acceptance is borrowed from this cohort;
corrected source requires complete fresh gates. Gate1 logSHA
3869ebeb89e629d735dd541b4f57cf5066302916e1d26b1bcdf8c8f863792e5c.
