$ErrorActionPreference='Stop'
Set-StrictMode -Version Latest
$repo='/home/marshall/src/worktrees/s3drive-manifest-page-proofs'
. "$repo/scripts/windows-replacement-fixture.ps1"
. "$repo/scripts/windows-reference-fixture.ps1"
$replacement=Get-Content -Raw /tmp/s3drive-page-proofs-bf2-artifacts/windows-replacement-reference.json|ConvertFrom-Json
$original=Get-Content -Raw /tmp/s3drive-page-proofs-bf2-artifacts/windows-disposition-reference.json|ConvertFrom-Json
$rf=Get-Content -Raw "$repo/docs/src/evidence/windows-replacement-reference-20261017.json"|ConvertFrom-Json
$of=Get-Content -Raw "$repo/docs/src/evidence/windows-disposition-reference-20261017.json"|ConvertFrom-Json
foreach($report in @($replacement,$original)) {if($report.source_commit -cne 'bf2e6aed16d32c62e094082a50769141f8f90ef6'){throw 'Wrong source'}}
Assert-WindowsReplacementReference -Fixture $rf -Observation $replacement
Assert-WindowsDispositionReference -Fixture $of -Observation $original
Write-Output 'PASS: bf2e6ae manifest page proof cohort typed21/14 project oracles and exact source'
