import hashlib,json,re
from pathlib import Path
base=Path('/tmp/s3drive-page-proofs-bf2-artifacts')
def obj(pairs):
 d={}
 for k,v in pairs:
  assert k not in d, ('duplicate JSON key',k)
  d[k]=v
 return d
def bad(x): raise AssertionError(('nonfinite JSON',x))
def parse(s): return json.loads(s,object_pairs_hook=obj,parse_constant=bad)
def equal(a,b):
 assert type(a) is type(b),(type(a),type(b))
 if isinstance(a,dict):
  assert a.keys()==b.keys()
  for k in a:equal(a[k],b[k])
 elif isinstance(a,list):
  assert len(a)==len(b)
  for x,y in zip(a,b):equal(x,y)
 else: assert a==b,(a,b)
log=Path('/tmp/s3drive-page-proofs-bf2-windows.log').read_text()
results=[]
for kind,count in [('replacement',21),('disposition',14)]:
 rows=[parse(m.group(1)) for m in re.finditer('S3DRIVE_'+kind.upper()+r'_REFERENCE (\{[^\r\n]+\})',log)]
 assert len(rows)==count
 artifact=parse((base/f'windows-{kind}-reference.json').read_text())
 keys=lambda rows:{(r['backend'],r['case']):r for r in rows}
 actual,expected=keys(rows),keys(artifact['records'])
 assert len(actual)==len(expected)==count
 equal(actual,expected)
 results.append({'kind':kind,'records':count,'all_fields_and_types_equal':True,'duplicate_keys_or_nonfinite_json_rejected':True})
(base/'raw-record-comparison.json').write_text(json.dumps(results,indent=2)+'\n')
print(json.dumps(results,indent=2))
