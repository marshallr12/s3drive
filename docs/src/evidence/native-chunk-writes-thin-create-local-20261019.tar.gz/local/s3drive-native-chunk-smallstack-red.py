import hashlib,json,os,subprocess,time
from pathlib import Path
root=Path('/home/marshall/src/worktrees/s3drive-native-chunk-writes')
paths=['crates/s3drive-fs/src/lib.rs','crates/s3drive-fs/src/managed/chunk_writes.rs']
# Remove temporary production-only probes before retaining the repaired bytes.
p=root/paths[0];s=p.read_text();s='\n'.join(l for l in s.splitlines() if 'eprintln!("SMALL_STACK_STAGE' not in l)+'\n';p.write_text(s)
saved={name:(root/name).read_bytes() for name in paths}
base='8f1fb7b817b94d66f96720cbfa1c63400a6efda9'
try:
 for name in paths:(root/name).write_bytes(subprocess.check_output(['git','show',base+':'+name],cwd=root))
 env=os.environ.copy();env['CARGO_TARGET_DIR']='/home/marshall/src/s3drive/target';env['RUST_TEST_THREADS']='4'
 cmd=['cargo','test','-p','s3drive-cli','--test','chunk_publication','native_chunk_callbacks_use_owned_runtime_tasks_on_a_small_driver_stack','--locked','--','--exact','--nocapture']
 started=time.monotonic()
 with Path('/tmp/s3drive-native-chunk-smallstack-red.log').open('wb') as log:r=subprocess.run(cmd,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=300)
 report={'production_source':base,'replaced_paths':paths,'harness_files_sha256':{n:hashlib.sha256((root/n).read_bytes()).hexdigest() for n in ['crates/s3drive-cli/tests/chunk_publication.rs','crates/s3drive-cli/tests/chunk_publication/native_writer.rs']},'exit_code':r.returncode,'elapsed_seconds':round(time.monotonic()-started,2),'repaired_files_restored':True}
finally:
 for name,data in saved.items():(root/name).write_bytes(data)
Path('/tmp/s3drive-native-chunk-smallstack-red.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
