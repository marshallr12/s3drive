from pathlib import Path
import hashlib,json,subprocess,zipfile
base=Path('/tmp/s3drive-chunk-directories-hosted3');source='7c980745c6d2a2bd55805a3536b15d874d6b6b22'
frozen=json.loads(Path('/tmp/s3drive-chunk-directories-gate3-source.json').read_text());assert frozen['head']==source
archive=Path(str(base)+'-source.zip');assert not archive.exists()
with archive.open('xb') as out:
 subprocess.run(['gh','api','--allow-escape-sequences','repos/marshallr12/s3drive/zipball/'+source],stdout=out,check=True,timeout=120)
assert archive.stat().st_size<256*1024*1024
with zipfile.ZipFile(archive) as z:
 entries=[i for i in z.infolist() if not i.is_dir()]
 assert len(entries)==len(frozen['inputs'])
 assert len({i.filename.split('/')[0] for i in entries})==1
 assert sum(i.file_size for i in entries)<512*1024*1024
 observed={}
 for i in entries:
  name=i.filename.split('/',1)[1]
  assert name not in observed and '..' not in Path(name).parts and not name.startswith('/')
  assert i.file_size<128*1024*1024
  observed[name]=hashlib.sha256(z.read(i)).hexdigest()
 assert observed==frozen['inputs'],[p for p in set(observed)|set(frozen['inputs']) if observed.get(p)!=frozen['inputs'].get(p)]
proof={'source':source,'all_source_files':len(observed),'all_digests_match':True,'zip_sha256':hashlib.file_digest(archive.open('rb'),'sha256').hexdigest(),'zip_bytes':archive.stat().st_size}
Path(str(base)+'-source-proof.json').write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps(proof))
