from pathlib import Path
import subprocess,json,time,datetime
base=Path('/tmp/s3drive-creator-open-state-hosted1')
root=Path('/home/marshall/src/worktrees/s3drive-creator-open-admission')
for _ in range(181):
 result=Path(str(base)+'-result.json')
 if result.exists():
  run=json.loads(result.read_text())
  assert run['conclusion']=='success' and all(j['conclusion']=='success' for j in run['jobs']), 'hosted suite did not succeed; no acceptance inferred'
  subprocess.run(['python3',str(base)+'-check.py'],check=True,timeout=600)
  art=Path(str(base)+'-artifacts')
  with (art/'project-oracles.log').open('wb') as log:
   subprocess.run(['pwsh','-NoProfile','-File','/tmp/s3drive-chunk-composition-project-oracles.ps1','-Repository',str(root),'-Artifacts',str(art)],stdout=log,stderr=subprocess.STDOUT,check=True,timeout=120)
  for name in ['raw-compare','review-raw']:
   subprocess.run(['python3',str(base)+'-'+name+'.py'],check=True,timeout=120)
  api=subprocess.check_output(['gh','api','repos/marshallr12/s3drive/actions/runs/39616964879'],timeout=60)
  Path(str(base)+'-api-run.json').write_bytes(api)
  Path(str(base)+'-collection-result.json').write_text(json.dumps({'collected':True,'source':run['headSha'],'run':run['databaseId'],'manual_raw_review_still_required':True,'at':datetime.datetime.now(datetime.timezone.utc).isoformat()},indent=2)+'\n')
  raise SystemExit(0)
 time.sleep(20)
raise SystemExit('observation limit reached; inspect live run before retry')
