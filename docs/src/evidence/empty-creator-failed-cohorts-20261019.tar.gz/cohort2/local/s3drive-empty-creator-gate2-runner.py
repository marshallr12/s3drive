import subprocess, pathlib, json, os, time, hashlib
root=pathlib.Path('/home/marshall/src/worktrees/s3drive-empty-manifest-publisher')
prefix=pathlib.Path('/tmp/s3drive-empty-creator-gate2')
started=time.time()
source=json.loads(pathlib.Path('/tmp/s3drive-empty-creator-gate2-source.json').read_text())
env=dict(os.environ,CARGO_TARGET_DIR='/home/marshall/src/s3drive/target',RUST_TEST_THREADS='4')
with open(str(prefix)+'.log','wb') as log:
 p=subprocess.Popen(['bash','scripts/gate.sh'],cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
 pathlib.Path(str(prefix)+'-running.json').write_text(json.dumps(dict(runner=os.getpid(),child=p.pid,started=started,root=str(root))))
 code=p.wait()
changed=[s for s,h in source.items() if not (root/s).is_file() or hashlib.sha256((root/s).read_bytes()).hexdigest()!=h]
pathlib.Path(str(prefix)+'-result.json').write_text(json.dumps(dict(exit_code=code,started=started,finished=time.time(),changed=changed,source_count=len(source)),indent=2)+'\n')
