import hashlib,io,json,subprocess,tarfile
from pathlib import Path
root=Path('/home/marshall/src/s3drive')
result=Path('/tmp/s3drive-chunk-source-controller-gate-result.json')
r=json.loads(result.read_text());assert r['exit_code']==0 and r['all_253_hashes_match'] is True
frozen=Path('/tmp/s3drive-chunk-source-controller-frozen.json');m=json.loads(frozen.read_text());assert len(m)==253
for p,h in m.items(): assert hashlib.sha256((root/p).read_bytes()).hexdigest()==h,p
files={
'full-gate.log':Path('/tmp/s3drive-chunk-source-controller-gate.log'),
'focused.log':Path('/tmp/s3drive-chunk-source-controller-focus2.log'),
'corrupt-record-focused.log':Path('/tmp/s3drive-chunk-source-controller-corrupt.log'),
'gate-result.json':result,
'frozen-source.json':frozen,
'self-review.json':Path('/tmp/s3drive-chunk-source-controller-review.json'),
'production-chunks.rs':root/'crates/s3drive-managed/src/chunks.rs',
'parent-integration.rs':root/'crates/s3drive-cli/tests/chunk_publication.rs',
'source-integration.rs':root/'crates/s3drive-cli/tests/chunk_publication/source_settlement.rs',
'parent-and-production-delta.patch':Path('/tmp/s3drive-chunk-source-controller-runtime.patch'),
'archive-builder.py':Path(__file__),
}
archive=root/'docs/src/evidence/chunk-source-controller-local-20261018.tar.gz';assert not archive.exists()
index={n:hashlib.sha256(p.read_bytes()).hexdigest() for n,p in sorted(files.items())}
with tarfile.open(archive,'w:gz') as t:
 for n,p in sorted(files.items()):t.add(p,arcname=n)
 raw=(json.dumps(index,indent=2)+'\n').encode();i=tarfile.TarInfo('sha256-index.json');i.size=len(raw);t.addfile(i,io.BytesIO(raw))
with tarfile.open(archive) as t:
 assert set(t.getnames())==set(index)|{'sha256-index.json'}
 for n,h in index.items():assert hashlib.sha256(t.extractfile(n).read()).hexdigest()==h,n
proof={'path':str(archive.relative_to(root/'docs/src')),'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'bytes':archive.stat().st_size,'members':len(index)+1,'all_indexed_members_verified':True,'scope':'local gate/controller fixture evidence; no own hosted/native chunk/provider acceptance'}
Path('/tmp/s3drive-chunk-source-controller-archive-proof.json').write_text(json.dumps(proof,indent=2)+'\n')
print(json.dumps(proof,indent=2))
