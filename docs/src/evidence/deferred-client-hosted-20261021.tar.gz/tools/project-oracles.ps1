param([Parameter(Mandatory=$true)][string]$Repository,[Parameter(Mandatory=$true)][string]$Artifacts)
$ErrorActionPreference='Stop'
Set-StrictMode -Version Latest
. (Join-Path $Repository 'scripts/windows-replacement-fixture.ps1')
. (Join-Path $Repository 'scripts/windows-reference-fixture.ps1')
foreach ($kind in @('replacement','disposition')) {
 $fixture=Get-Content -Raw -LiteralPath (Join-Path $Repository "docs/src/evidence/windows-$kind-reference-20261017.json")|ConvertFrom-Json
 $observed=Get-Content -Raw -LiteralPath (Join-Path $Artifacts "windows-$kind-reference.json")|ConvertFrom-Json
 if ($kind -eq 'replacement') {Assert-WindowsReplacementReference -Fixture $fixture -Observation $observed}
 else {Assert-WindowsDispositionReference -Fixture $fixture -Observation $observed}
 Write-Output "PASS: project $kind oracle"
}
