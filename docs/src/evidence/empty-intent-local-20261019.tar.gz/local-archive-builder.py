"""One-use full local combined-retention evidence; own native/platform gates remain separate."""
from pathlib import Path
import json,hashlib,tarfile,io,subprocess,re
root=Path('/home/marshall/src/worktrees/s3drive-empty-manifest-intent');out=root/'docs/src/evidence/empty-intent-local-20261019.tar.gz';assert not out.exists()
m=json.loads(Path('/tmp/s3drive-empty-intent-candidate2-frozen.json').read_text());assert len(m)==354
r=json.loads(Path('/tmp/s3drive-empty-intent-gate2-result.json').read_text());assert r['exit_code']==0 and r['all_inputs_unchanged'] and r['runtime_inputs']==354 and r['rust_test_threads']==4
assert r['command']==['bash','scripts/gate.sh']
raw=Path(r['log']).read_bytes();assert hashlib.sha256(raw).hexdigest()==r['sha256']
counts={}
for label,passed,ignored in [('publication',24,0),('state',520,1),('reader',26,1),('core',39,0),('s3',62,0)]:
 match=re.search(fr'test result: ok\. {passed} passed; 0 failed; {ignored} ignored; 0 measured; 0 filtered out; finished in ([0-9.]+)s'.encode(),raw);assert match,label
 counts[label]={'passed':passed,'ignored':ignored,'seconds':float(match.group(1))}
files={}
for name,sha in m.items():
 body=(root/name).read_bytes();assert hashlib.sha256(body).hexdigest()==sha,name
 assert hashlib.sha256(subprocess.check_output(['git','-C',str(root),'show','bb17161:'+name])).hexdigest()==sha,name
 files['final-source/'+name]=body
for suffix in ['candidate2-frozen.json','gate2.log','gate2-running.json','gate2-result.json','gate2-runner.py']:
 p=Path('/tmp/s3drive-empty-intent-'+suffix);files[p.name]=p.read_bytes()
parents=[('atomic-create-local',Path('/home/marshall/src/s3drive/docs/src/evidence/empty-create-local-20261019.tar.gz'),Path('/tmp/s3drive-empty-create-local-archive-proof.json')),('atomic-create-hosted',Path('/home/marshall/src/s3drive/docs/src/evidence/empty-create-hosted-20261019.tar.gz'),Path('/tmp/s3drive-empty-create2-hosted-archive-proof.json')),('failed-first-cohort',root/'docs/src/evidence/empty-intent-failed1-20261019.tar.gz',Path('/tmp/s3drive-empty-intent-failed1-archive-proof.json'))]
for label,path,proof_path in parents:
 proof=json.loads(proof_path.read_text());assert hashlib.sha256(path.read_bytes()).hexdigest()==proof['sha256']
 with tarfile.open(path) as t:
  index=json.loads(t.extractfile('sha256-index.json').read());assert set(t.getnames())==set(index)|{'sha256-index.json'}
  for name,sha in index.items():assert hashlib.sha256(t.extractfile(name).read()).hexdigest()==sha,(label,name)
 files['parent-evidence/'+label+'/'+path.name]=path.read_bytes();files['parent-evidence/'+label+'/'+proof_path.name]=proof_path.read_bytes()
for suffix in ['check1-source.json','check1-source.tar.gz','check1-result.json','check1.log','check2.log','migrations1.log','clippy1.log','clippy2.log','clippy3.log','snapshot-cli-repair1.log','snapshot-state-repair1.log','candidate1-frozen.json','candidate1-source.tar.gz','gate1.log','gate1-running.json','gate1-result.json','gate1-runner.py']:
 p=Path('/tmp/s3drive-empty-intent-'+suffix);files[p.name]=p.read_bytes()
for number in range(1,7):
 for suffix in ['source.json','source.tar.gz','log']:
  p=Path('/tmp/s3drive-empty-intent-state'+str(number)+'-'+suffix) if suffix!='log' else Path('/tmp/s3drive-empty-intent-state'+str(number)+'.log')
  files[p.name]=p.read_bytes()
files['local-archive-builder.py']=Path(__file__).read_bytes()
files['executed-contract.md']=(root/'docs/src/empty-manifest-publisher.md').read_bytes()
index={name:hashlib.sha256(body).hexdigest() for name,body in files.items()}
with tarfile.open(out,'x:gz') as t:
 for name,body in sorted(files.items()):
  info=tarfile.TarInfo(name);info.mode=0o644;info.mtime=0;info.size=len(body);t.addfile(info,io.BytesIO(body))
 body=(json.dumps(index,indent=2)+'\n').encode();info=tarfile.TarInfo('sha256-index.json');info.mode=0o644;info.mtime=0;info.size=len(body);t.addfile(info,io.BytesIO(body))
with tarfile.open(out) as t:
 assert set(t.getnames())==set(index)|{'sha256-index.json'}
 for name,sha in index.items():assert hashlib.sha256(t.extractfile(name).read()).hexdigest()==sha,name
proof={'scope':'complete local gate only; parent and own hosted/platform/source/native acceptance required','path':str(out.relative_to(root/'docs/src')),'sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'bytes':out.stat().st_size,'members':len(index)+1,'all_indexed_members_verified':True,'runtime_inputs':354,'source_checkpoint':'bb17161','schema':40,'gate_exit_code':0,'gate_log_sha256':r['sha256'],'rust_test_threads':4,'reduced_sdk_admission':False,'counts':counts,'parent_archives_independently_verified':3}
Path('/tmp/s3drive-empty-intent-local-archive-proof.json').write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps(proof,indent=2))
