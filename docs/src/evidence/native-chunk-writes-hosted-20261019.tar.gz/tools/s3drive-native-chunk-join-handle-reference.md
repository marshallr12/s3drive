API review dated2026-10-19: the pinned Tokio1.53.3 implementation was inspected
locally. A bare JoinHandle drop detaches the task; abort requests cancellation,
which may complete later. The live reference served Tokio1.54.0 when checked;
it is supporting API documentation, not a dependency upgrade or a substitute
for checking the pinned source. [Tokio JoinHandle ownership and abort](https://docs.rs/tokio/latest/tokio/task/struct.JoinHandle.html#method.abort),
[owned spawning and Send/static bounds](https://tokio.rs/tokio/tutorial/spawning).
An aborted upload or metadata request can already have committed remotely;
S3Drive retains its exact recovery identity and does not infer rollback from
local task cancellation.
