import gzip,hashlib,io,json,tarfile
from pathlib import Path
base=Path('/tmp/s3drive-native-chunk-hosted5')
source='d95a6343d1c232dfc7f7e63ca958e70cee819bf0'
out=Path('/tmp/native-chunk-writes-hosted-20261019.tar.gz')
assert not out.exists(), 'one-use archive already exists'
run=json.loads(Path(str(base)+'-result.json').read_text())
assert run['headSha']==source and run['conclusion']=='success' and len(run['jobs'])==3
assert all(j['status']=='completed' and j['conclusion']=='success' for j in run['jobs'])
art=Path(str(base)+'-artifacts')
strict=json.loads((art/'strict-independent.json').read_text());assert {(r['kind'],r['records']) for r in strict}=={('replacement',21),('disposition',14)}
assert all(r['source']==source and r['strict_types_and_all_fields_match'] for r in strict)
compare=json.loads((art/'raw-record-comparison.json').read_text());assert all(r['all_fields_and_types_equal'] and r['duplicate_keys_or_nonfinite_json_rejected'] for r in compare)
ps=(art/'project-oracles.log').read_text();assert 'PASS: project replacement oracle' in ps and 'PASS: project disposition oracle' in ps
review=json.loads(Path(str(base)+'-raw-reviewed.json').read_text());assert review['source']==source and review['reviewed'] and review['test_faults']==0 and review['all_raw_record_fields_and_json_types_match']
sourceproof=json.loads(Path(str(base)+'-source-proof.json').read_text());assert sourceproof['source']==source and sourceproof['all_source_files']==693 and sourceproof['all_digests_match']
metadata=json.loads(Path(str(base)+'-api-run.json').read_text());assert metadata['head_sha']==source and metadata['run_attempt']==1 and metadata['conclusion']=='success'
members={}
def add(name,p):
 assert name not in members and not name.startswith('/') and '..' not in Path(name).parts
 members[name]=Path(p).read_bytes()
for n in [1,2,3,4,5]:
 prefix=f's3drive-native-chunk-hosted{n}'
 for p in sorted(Path('/tmp').glob(prefix+'*')):
  if p.is_file() and p.suffix in ['.json','.py','.log','.ps1']:
   add(f'cohort{n}/'+p.name,p)
 for kind in ['book','linux','windows']:
  assert Path('/tmp/'+prefix+'-'+kind+'.log').exists(),(n,kind)
for p in sorted(art.iterdir()):
 if p.is_file() and p.suffix in ['.json','.zip','.log']:add('artifacts/'+p.name,p)
for name in ['s3drive-check-native-artifacts.py','s3drive-chunk-composition-project-oracles.ps1','s3drive-native-chunk-hosted-archive.py','s3drive-native-chunk-checkpoint.json','s3drive-native-chunk-join-handle-reference.md']:
 add('tools/'+name,Path('/tmp')/name)
index={'source':source,'scope':'complete own hosted/native/source/artifact review; rejected cohorts1-4 retained separately','run':39351215634,'attempt':1,'members':{n:{'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)} for n,b in sorted(members.items())}}
members['index.json']=(json.dumps(index,indent=2)+'\n').encode()
with out.open('xb') as disk:
 with gzip.GzipFile(filename='',fileobj=disk,mode='wb',mtime=0) as gz:
  with tarfile.open(fileobj=gz,mode='w') as t:
   for name,b in sorted(members.items()):
    i=tarfile.TarInfo(name);i.size=len(b);i.mtime=0;i.mode=0o644;t.addfile(i,io.BytesIO(b))
with tarfile.open(out,'r:gz') as t:
 assert {i.name for i in t.getmembers()}==set(members)
 for name,b in members.items():assert t.extractfile(name).read()==b,name
proof={'source':source,'archive':str(out),'members':len(members),'bytes':out.stat().st_size,'sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'all_members_verified':True,'one_use':'DONE - do not rerun'}
Path('/tmp/s3drive-native-chunk-hosted-archive-proof.json').write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps(proof))
