import datetime,json,pathlib,subprocess,time
base=pathlib.Path('/tmp/s3drive-native-chunk-hosted4')
start=time.monotonic()
for n in range(181):
    r=subprocess.run(['gh','run','view','39349233353','--repo','marshallr12/s3drive','--json','databaseId,headSha,status,conclusion,url,jobs'],capture_output=True,text=True,timeout=40)
    if r.returncode==0:
        state=json.loads(r.stdout)
        if state['headSha']!='428581fef30c4f20868031f5f7e872848d502303':raise SystemExit('wrong source')
        state['observed_at']=datetime.datetime.now(datetime.timezone.utc).isoformat()
        pathlib.Path(str(base)+'-status.json').write_text(json.dumps(state,indent=2)+'\n')
        if state['status']=='completed':
            pathlib.Path(str(base)+'-result.json').write_text(json.dumps(state,indent=2)+'\n')
            print(json.dumps({'status':state['status'],'conclusion':state['conclusion'],'elapsed':round(time.monotonic()-start,2),'jobs':[(j['name'],j['databaseId'],j['conclusion']) for j in state['jobs']]}),flush=True)
            raise SystemExit(0 if state['conclusion']=='success' else 1)
    else:
        pathlib.Path(str(base)+'-observation-error.txt').write_text(r.stderr)
    time.sleep(20)
raise SystemExit('observer time limit reached; check live run')
