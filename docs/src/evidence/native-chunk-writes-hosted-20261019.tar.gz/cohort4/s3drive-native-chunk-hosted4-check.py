import hashlib,json,pathlib,subprocess,zipfile
root=pathlib.Path('/home/marshall/src/worktrees/s3drive-native-chunk-writes')
base=pathlib.Path('/tmp/s3drive-native-chunk-hosted4')
source='428581fef30c4f20868031f5f7e872848d502303'
out=pathlib.Path(str(base)+'-artifacts')
assert not out.exists(),'one-use output already exists'
run=json.loads(pathlib.Path(str(base)+'-result.json').read_text())
assert run['headSha']==source and run['conclusion']=='success'
assert len(run['jobs'])==3 and all(j['conclusion']=='success' for j in run['jobs'])
out.mkdir()
def gh(*args): return subprocess.check_output(['gh',args[0],'--allow-escape-sequences',*args[1:]],timeout=120)
metadata=json.loads(gh('api','repos/marshallr12/s3drive/actions/runs/39349233353/artifacts'))
assert not metadata.get('total_count',0)>10
(out/'api-artifacts.json').write_text(json.dumps(metadata,indent=2)+'\n')
reports=[]
for kind in ['replacement','disposition']:
 name='windows-'+kind+'-reference'
 [a]=[a for a in metadata['artifacts'] if a['name']==name+'-'+source]
 assert a['expired'] is False and a['size_in_bytes']<8*1024*1024
 assert a['workflow_run']['head_sha']==source
 raw=gh('api',f"repos/marshallr12/s3drive/actions/artifacts/{a['id']}/zip")
 digest=hashlib.sha256(raw).hexdigest();assert a['digest']=='sha256:'+digest
 path=out/(name+'.zip');path.write_bytes(raw)
 with zipfile.ZipFile(path) as z:
  files=[i for i in z.infolist() if not i.is_dir()]
  assert len(files)==1 and files[0].filename==name+'.json' and files[0].file_size<2*1024*1024
  (out/(name+'.json')).write_bytes(z.read(files[0]))
 reports.append({'kind':kind,'id':a['id'],'zip_sha256':digest,'api_digest_matches':True})
strict=subprocess.check_output(['python3','/tmp/s3drive-check-native-artifacts.py','--source',source,'--directory',str(out),'--repository',str(root)],text=True,timeout=60)
(out/'strict-independent.json').write_text(strict)
for j in run['jobs']:
 name={'book':'book','rust (ubuntu-latest)':'linux','rust (windows-latest)':'windows'}[j['name']]
 path=pathlib.Path(str(base)+'-'+name+'.log')
 if path.exists():
  proof=json.loads(pathlib.Path(str(base)+'-'+name+'-raw-proof.json').read_text())
  assert proof['id']==j['databaseId'] and proof['source']==source
  raw=path.read_bytes();assert hashlib.sha256(raw).hexdigest()==proof['raw_log_sha256']
 else:
  raw=gh('api',f"repos/marshallr12/s3drive/actions/jobs/{j['databaseId']}/logs");path.write_bytes(raw)
 reports.append({'job':name,'id':j['databaseId'],'raw_log_sha256':hashlib.sha256(raw).hexdigest()})
(out/'api-proof.json').write_text(json.dumps(reports,indent=2)+'\n')
print(json.dumps(reports))
