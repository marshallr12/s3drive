"""Seal only a successful unchanged local candidate; no hosted/native acceptance."""
import pathlib,hashlib,json,tarfile,io,subprocess
root=pathlib.Path('/home/marshall/src/worktrees/s3drive-empty-manifest-publisher')
out=pathlib.Path('/tmp/s3drive-empty-creator-local-20261019.tar.gz')
assert not out.exists()
source='70680135b2692e5d1266bbe22d5dfe9d19f9a735'
r=json.load(open('/tmp/s3drive-empty-creator-gate3-result.json'))
assert r['exit_code']==0 and r['changed']==[] and r['source_count']==668
all_inputs=json.load(open('/tmp/s3drive-empty-creator-gate3-source.json'))
for p,h in all_inputs.items():assert hashlib.sha256((root/p).read_bytes()).hexdigest()==h,p
frozen=json.load(open('/tmp/s3drive-empty-creator-candidate3-frozen.json')); assert len(frozen)==357
files={}
for p,h in frozen.items():
 data=(root/p).read_bytes(); assert hashlib.sha256(data).hexdigest()==h
 assert subprocess.check_output(['git','-C',str(root),'show',source+':'+p])==data
 files['source/'+p]=data
for name in ['state1.log','check1.log','check2.log','sdk1.log','sdk2.log','sdk3.log','sdk4.log','stack-focus1.log','state-test-list.txt','candidate3-frozen.json','gate1-all-inputs.json','gate1-source.json','gate2-source.json','gate3-source.json','gate3-runner.py','gate3-running.json','gate3-result.json','gate3.log']:
 p=pathlib.Path('/tmp/s3drive-empty-creator-'+name); assert p.exists(),p;files['local/'+p.name]=p.read_bytes()
for name in ['docs/src/empty-manifest-publisher.md','docs/src/implementation-plan.md','HANDOFF.md']:
 data=(root/name).read_bytes(); assert hashlib.sha256(data).hexdigest()==all_inputs[name]
 files['declaration/'+name]=data
failed=json.load(open('/tmp/s3drive-empty-creator-failed-archive-proof.json'))
p=pathlib.Path(failed['archive']); assert failed['verified'] and hashlib.sha256(p.read_bytes()).hexdigest()==failed['sha256']
files['failed/'+p.name]=p.read_bytes()
files['failed/archive-proof.json']=json.dumps(failed,indent=2).encode()
parents={}
for name,expected in [('empty-intent-local-20261019.tar.gz','a66a26b0e73fa50afe0267e13ca8f7669cd9a2c5a19ec37cc15a9bd8a42e2d09'),('empty-intent-hosted-20261019.tar.gz','5aa41539617cd261118f87668dcb75a0679c601331e3180fcc60204970cd53bf'),('empty-intent-failed1-20261019.tar.gz','36ca0c7555201edc2cff0949e2c81337eafe9ca19775b2702e0dcf9ac48cec83')]:
 p=root/'docs/src/evidence'/name; assert hashlib.sha256(p.read_bytes()).hexdigest()==expected
 parents['docs/src/evidence/'+name]={'sha256':expected,'bytes':p.stat().st_size,'embedded':False,'repository_parent':'4a6a811c379eae2c227806d5a630dbabfb4bea13'}
files['parent-evidence-references.json']=json.dumps(parents,indent=2).encode()
files['status.json']=json.dumps({'source':source,'scope':'complete local gate only; hosted/native/provider gates are separate','runtime_inputs':357,'all_gate_inputs':668,'unchanged':True,'schema':40,'new_schema':False,'native_chunk_writes':False,'wasabi_mutations':False},indent=2).encode()
files['archive-builder.py']=pathlib.Path(__file__).read_bytes()
index=json.dumps({k:{'sha256':hashlib.sha256(v).hexdigest(),'bytes':len(v)} for k,v in files.items()},indent=2).encode()
with tarfile.open(out,'w:gz') as t:
 for name,data in [*sorted(files.items()),('index.json',index)]:
  info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o600;t.addfile(info,io.BytesIO(data))
with tarfile.open(out) as t:
 assert len(t.getmembers())==len(files)+1
 assert t.extractfile('index.json').read()==index
 for name,data in files.items():assert t.extractfile(name).read()==data,name
proof={'archive':str(out),'source':source,'sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'bytes':out.stat().st_size,'members':len(files)+1,'all_inputs_unchanged':True,'runtime_inputs':357,'local_gate_exit':0,'verified':True,'hosted_acceptance':False}
pathlib.Path('/tmp/s3drive-empty-creator-local-archive-proof.json').write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps(proof))
