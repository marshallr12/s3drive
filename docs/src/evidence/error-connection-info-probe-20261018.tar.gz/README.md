# Error connection metadata control (2026-10-18)

Standalone Linux research only, not production S3Drive code. Extract into a
fresh temporary directory and run `cargo run --locked` (`--offline` when cached).
It binds local ephemeral listeners and generates a private CA in memory.

Four HTTP/TLS complete/lost-reply controls compare connector metadata to an
independent peer. In each lost-reply case the public Hyper-util Error::connect_info
metadata also matches that exact peer connection through reqwest's error source
chain. Six PASS lines, including two error-metadata comparisons.

The fixture uses GET without authentication/body or real S3. Absence of error
metadata is not proof of no send/commit. Dependency source chains are not stable
across releases; production use requires pinned-version and privacy controls.
