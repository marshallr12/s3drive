#[test]
fn rewritten_request_and_physical_snapshot_cannot_replace_the_independent_verified_upload() {
    for which in 0..3 {
        let tmp = tempfile::tempdir().unwrap();
        let path = tmp.path().join("state");
        let mut state = State::open_managed(&path).unwrap();
        let input = input(4);
        let mut record = prepared(&mut state, &input);
        let ns::Mutation::CreateEmptyManifest {
            etag,
            upload_operation,
            version,
            ..
        } = &mut record.request.as_mut().unwrap().mutation
        else {
            panic!()
        };
        let proof = record.physical.as_mut().unwrap();
        match which {
            0 => {
                *etag = "\"rewritten\"".into();
                proof.etag = etag.clone();
            }
            1 => {
                *upload_operation = "b".repeat(64);
                proof.operation = upload_operation.clone();
            }
            _ => {
                *version = Some("rewritten-version".into());
                proof.version = version.clone();
            }
        }
        // Recompute both local checksums: a self-consistent duplicate snapshot
        // is still not the original, independently retained upload proof.
        let raw = serde_json::to_vec(&record).unwrap();
        let mut map = BTreeMap::new();
        map.insert(input.operation.clone(), record.clone());
        state
            .connection
            .execute(
                "UPDATE manifest_creations SET record=?1,state_hash=?2",
                params![raw, record_hash(&record).unwrap().as_slice()],
            )
            .unwrap();
        state
            .connection
            .execute(
                "UPDATE manifest_creation_role SET state_hash=?1",
                [projection(&map).unwrap().as_slice()],
            )
            .unwrap();
        let before = rows(&state);
        assert!(
            Journal::new(&mut state, Limits::default()).is_err(),
            "rewritten physical field {which} was admitted"
        );
        assert_eq!(rows(&state), before);
        drop(state);
        assert!(RecoveryStore::open(&path).is_err());
        assert!(State::open_managed(&path).is_err());
    }
}
