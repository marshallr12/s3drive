//! Exploratory public API control only; not the production authority client.
use hyper_util::client::legacy::connect::{Connection, HttpInfo};
use std::{
    future::Future,
    net::SocketAddr,
    pin::Pin,
    sync::{Arc, Mutex},
    task::{Context, Poll},
    time::Duration,
};
use tokio::io::{AsyncReadExt, AsyncWriteExt};
use tower_layer::Layer;
use tower_service::Service;
type Addresses = (SocketAddr, SocketAddr);
#[derive(Clone)]
struct Observe(Arc<Mutex<Vec<Addresses>>>);
#[derive(Clone)]
struct Observed<S>(S, Arc<Mutex<Vec<Addresses>>>);
impl<S> Layer<S> for Observe {
    type Service = Observed<S>;
    fn layer(&self, inner: S) -> Self::Service {
        Observed(inner, self.0.clone())
    }
}
impl<S, R> Service<R> for Observed<S>
where
    S: Service<R>,
    S::Future: Send + 'static,
    S::Response: Connection + 'static,
    S::Error: 'static,
{
    type Response = S::Response;
    type Error = S::Error;
    type Future = Pin<Box<dyn Future<Output = Result<Self::Response, Self::Error>> + Send>>;
    fn poll_ready(&mut self, cx: &mut Context<'_>) -> Poll<Result<(), Self::Error>> {
        self.0.poll_ready(cx)
    }
    fn call(&mut self, r: R) -> Self::Future {
        let future = self.0.call(r);
        let observed = self.1.clone();
        Box::pin(async move {
            let result = future.await;
            if let Ok(connection) = &result {
                let mut extras = http::Extensions::new();
                connection.connected().get_extras(&mut extras);
                let info = extras
                    .get::<HttpInfo>()
                    .expect("connector did not expose HttpInfo");
                observed
                    .lock()
                    .unwrap()
                    .push((info.local_addr(), info.remote_addr()));
            }
            result
        })
    }
}
async fn exchange<T: tokio::io::AsyncRead + tokio::io::AsyncWrite + Unpin>(
    mut stream: T,
    reply: bool,
) {
    let mut header = Vec::new();
    while !header.ends_with(b"\r\n\r\n") {
        assert!(header.len() < 8192);
        header.push(stream.read_u8().await.unwrap());
    }
    assert!(header.starts_with(b"GET /control HTTP/1.1\r\n"));
    if !reply {
        return;
    }
    stream
        .write_all(b"HTTP/1.1 200 OK\r\nContent-Length: 2\r\nConnection: close\r\n\r\nok")
        .await
        .unwrap();
    stream.flush().await.unwrap();
}
#[tokio::main(flavor = "multi_thread", worker_threads = 2)]
async fn main() {
    for tls in [false, true] {
        for reply in [true, false] {
            let listener = tokio::net::TcpListener::bind("127.0.0.1:0").await.unwrap();
            let address = listener.local_addr().unwrap();
            let key = rcgen::KeyPair::generate().unwrap();
            let cert = rcgen::CertificateParams::new(vec!["127.0.0.1".into()])
                .unwrap()
                .self_signed(&key)
                .unwrap();
            let server = rustls::ServerConfig::builder_with_provider(Arc::new(
                rustls::crypto::aws_lc_rs::default_provider(),
            ))
            .with_safe_default_protocol_versions()
            .unwrap()
            .with_no_client_auth()
            .with_single_cert(
                vec![cert.der().clone()],
                rustls::pki_types::PrivatePkcs8KeyDer::from(key.serialize_der()).into(),
            )
            .unwrap();
            let acceptor = tokio_rustls::TlsAcceptor::from(Arc::new(server));
            let mut peer = tokio::spawn(async move {
                tokio::time::timeout(Duration::from_secs(5), async move {
                    let (stream, client_address) = listener.accept().await.unwrap();
                    let server_address = stream.local_addr().unwrap();
                    if tls {
                        exchange(acceptor.accept(stream).await.unwrap(), reply).await;
                    } else {
                        exchange(stream, reply).await;
                    }
                    assert!(
                        tokio::time::timeout(Duration::from_millis(200), listener.accept())
                            .await
                            .is_err(),
                        "unexpected second connection"
                    );
                    (client_address, server_address)
                })
                .await
                .unwrap()
            });
            let observations = Arc::new(Mutex::new(Vec::new()));
            let client = reqwest::Client::builder()
                .no_proxy()
                .http1_only()
                .retry(reqwest::retry::never())
                .redirect(reqwest::redirect::Policy::none())
                .connect_timeout(Duration::from_secs(2))
                .timeout(Duration::from_secs(4))
                .tls_certs_only([reqwest::Certificate::from_pem(cert.pem().as_bytes()).unwrap()])
                .connector_layer(Observe(observations.clone()))
                .build()
                .unwrap();
            let scheme = if tls { "https" } else { "http" };
            let result = client
                .get(format!("{scheme}://{address}/control"))
                .header("connection", "close")
                .send()
                .await;
            let result = match result {
                Ok(response) => response.bytes().await,
                Err(error) => Err(error),
            };
            let finished = tokio::time::timeout(Duration::from_secs(6), &mut peer).await;
            if finished.is_err() {
                peer.abort();
                let _ = peer.await;
            }
            let addresses = finished.unwrap().unwrap();
            if reply {
                assert_eq!(&result.unwrap()[..], b"ok");
            } else {
                assert!(result.is_err(), "lost reply returned success");
            }
            assert_eq!(&observations.lock().unwrap()[..], &[addresses]);
            println!(
                "PASS: {} {} public connector HttpInfo matches independently accepted TCP socket",
                scheme,
                if reply {
                    "complete-reply"
                } else {
                    "lost-reply"
                }
            );
        }
    }
}
