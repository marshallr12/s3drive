# Exploratory connector metadata control (2026-10-18)

This standalone Linux-only control is not production S3Drive code. It tests
reqwest's public connector_layer and Hyper-util Connection/HttpInfo APIs with
local HTTP/TLS peers, complete replies and lost replies. No S3 or credentials.

Extract into a fresh temporary directory. Run `cargo run --locked` there
(`--offline` also works if all locked dependencies are cached). It binds only
127.0.0.1:0 and generates an ephemeral certificate in memory. Expected: four PASS
lines; no address, private key or certificate is printed.

A connector candidate is not proof of which pooled socket a production RPC
selected. No native Windows or filesystem/provider acceptance is established.
