import gzip,hashlib,io,json,tarfile
from pathlib import Path
base=Path('/tmp/s3drive-deferred-canonical-hosted2');source='3e670915cdfe3dbafee9cd40c33d1a70cf979234'
out=Path('/tmp/deferred-canonical-hosted-20261021.tar.gz');assert not out.exists()
run=json.loads(Path(str(base)+'-result.json').read_text());assert run['headSha']==source and run['conclusion']=='success' and len(run['jobs'])==3
assert all(j['status']=='completed' and j['conclusion']=='success' for j in run['jobs'])
art=Path(str(base)+'-artifacts');strict=json.loads((art/'strict-independent.json').read_text())
assert {(r['kind'],r['records']) for r in strict}=={('replacement',21),('disposition',14)}
assert all(r['source']==source and r['strict_types_and_all_fields_match'] for r in strict)
compare=json.loads((art/'raw-record-comparison.json').read_text());assert all(r['all_fields_and_types_equal'] and r['duplicate_keys_or_nonfinite_json_rejected'] for r in compare)
ps=(art/'project-oracles.log').read_text();assert 'PASS: project replacement oracle' in ps and 'PASS: project disposition oracle' in ps
review=json.loads(Path(str(base)+'-raw-reviewed.json').read_text());assert review['source']==source and review['reviewed'] and review['test_faults']==0 and review['all_raw_record_fields_and_json_types_match']
proof=json.loads(Path(str(base)+'-source-proof.json').read_text());assert proof['source']==source and proof['all_source_files']==709 and proof['all_digests_match']
metadata=json.loads(Path(str(base)+'-api-run.json').read_text());assert metadata['head_sha']==source and metadata['run_attempt']==1 and metadata['conclusion']=='success'
members={}
def add(name,p):
 assert name not in members and not name.startswith('/') and '..' not in Path(name).parts
 members[name]=p.read_bytes()
for n in [1,2]:
 prefix=f's3drive-deferred-canonical-hosted{n}'
 for p in sorted(Path('/tmp').glob(prefix+'*')):
  if p.is_file() and p.suffix in ['.json','.py','.log']:add(f'cohort{n}/'+p.name,p)
 for kind in ['linux','windows','book']:assert Path(f'/tmp/{prefix}-{kind}.log').exists(),(n,kind)
for p in sorted(art.iterdir()):
 if p.is_file() and p.suffix in ['.json','.zip','.log']:add('artifacts/'+p.name,p)
add('tools/project-oracles.ps1',Path('/tmp/s3drive-chunk-composition-project-oracles.ps1'))
add('tools/strict-independent.py',Path('/tmp/s3drive-check-native-artifacts.py'))
add('tools/hosted-archive.py',Path(__file__))
index={'source':source,'accepted_run':run['databaseId'],'attempt':1,'scope':'own complete hosted authority/state regression acceptance; native lifecycle unchanged, no live provider or physical reboot','members':{n:{'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()} for n,b in sorted(members.items())}}
members['index.json']=(json.dumps(index,indent=2)+'\n').encode()
with out.open('xb') as disk:
 with gzip.GzipFile(filename='',fileobj=disk,mode='wb',mtime=0) as gz:
  with tarfile.open(fileobj=gz,mode='w') as t:
   for name,b in sorted(members.items()):
    i=tarfile.TarInfo(name);i.size=len(b);i.mode=0o644;i.mtime=0;t.addfile(i,io.BytesIO(b))
with tarfile.open(out) as t:
 assert len(t.getmembers())==len(members)
 for n,b in members.items():assert t.extractfile(n).read()==b
proof={'archive':str(out),'members':len(members),'bytes':out.stat().st_size,'sha256':hashlib.file_digest(out.open('rb'),'sha256').hexdigest(),'all_members_verified':True}
Path('/tmp/s3drive-deferred-canonical-hosted-archive-proof.json').write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps(proof))
