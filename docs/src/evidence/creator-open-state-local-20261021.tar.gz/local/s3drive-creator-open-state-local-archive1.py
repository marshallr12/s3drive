import gzip,hashlib,io,json,subprocess,tarfile
from pathlib import Path
root=Path('/home/marshall/src/worktrees/s3drive-creator-open-admission');source='20420d73bf07ccb0929c3b188e32c6d23a37dfec'
out=Path('/tmp/creator-open-state-local-20261021.tar.gz');assert not out.exists()
result=json.loads(Path('/tmp/s3drive-creator-open-state-gate1-result.json').read_text());frozen=json.loads(Path('/tmp/s3drive-creator-open-state-gate1-source.json').read_text())
assert result['head']==frozen['head']==source and result['exit_code']==0 and result['unchanged']
for name,digest in frozen['inputs'].items():assert hashlib.sha256((root/name).read_bytes()).hexdigest()==digest,name
runtime=json.loads(Path('/tmp/s3drive-creator-open-state-candidate1-frozen.json').read_text());assert len(runtime)==380
members={}
def add(name,data):
 assert name not in members and not name.startswith('/') and '..' not in Path(name).parts
 members[name]=data
for name,digest in runtime.items():
 data=(root/name).read_bytes();assert hashlib.sha256(data).hexdigest()==digest;add('source/'+name,data)
for p in sorted(Path('/tmp').glob('s3drive-creator-open-state-*')):
 if p.is_file() and 'hosted' not in p.name and p.suffix in ['.log','.json','.py']:add('local/'+p.name,p.read_bytes())
add('local/s3drive-creator-open-old44-retained.json',Path('/tmp/s3drive-creator-open-old44-retained.json').read_bytes())
add('local/candidate1.patch',subprocess.check_output(['git','diff','--binary','02133e0',source],cwd=root))
for name in ['HANDOFF.md','docs/src/creator-open-state.md','docs/src/deferred-manifest-integration.md']:add('declared/'+name,(root/name).read_bytes())
index={'source':source,'runtime_inputs':380,'all_gate_inputs':733,'scope':'own full local prospective creator/open state admission gate; hosted/native and provider acceptance separate','members':{n:{'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()} for n,b in sorted(members.items())}}
add('index.json',(json.dumps(index,indent=2)+'\n').encode())
with out.open('xb') as disk:
 with gzip.GzipFile(filename='',fileobj=disk,mode='wb',mtime=0) as gz:
  with tarfile.open(fileobj=gz,mode='w') as t:
   for name,data in sorted(members.items()):
    i=tarfile.TarInfo(name);i.size=len(data);i.mode=0o644;i.mtime=0;t.addfile(i,io.BytesIO(data))
with tarfile.open(out) as t:
 assert len(t.getmembers())==len(members)
 for n,b in members.items():assert t.extractfile(n).read()==b
proof={'archive':str(out),'members':len(members),'bytes':out.stat().st_size,'sha256':hashlib.file_digest(out.open('rb'),'sha256').hexdigest(),'all_members_verified':True}
Path('/tmp/s3drive-creator-open-state-local-archive-proof.json').write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps(proof))
