from pathlib import Path
import re,json,hashlib
base='/tmp/s3drive-creator-open-state-hosted1';scan=json.loads(Path(base+'-raw-review-scan.json').read_text());details={}
for job,data in scan.items():
 p=Path(data['log']);assert hashlib.sha256(p.read_bytes()).hexdigest()==data['sha256'];raw=re.sub(r'\x1b\[[0-9;]*[A-Za-z]','',p.read_text());lines=[re.sub(r'^\ufeff?\d{4}-\d\d-\d\dT\S+Z ','',re.sub(r'^[^\t]*\t[^\t]*\t','',s)) for s in raw.splitlines()]
 slow=[]
 for n,line in enumerate(lines):
  m=re.fullmatch(r'test (.+) has been running for over 60 seconds',line)
  if m:
   end=next((i for i in range(n+1,len(lines)) if lines[i]=='test '+m.group(1)+' ... ok'),None);assert end is not None,(job,m.group(1));slow.append({'test':m.group(1),'notice_line':n+1,'later_pass_line':end+1})
 contexts=[{'line':n,'context':lines[max(0,n-3):n+9]} for n,line in data['fault_lines']]
 warnings=[s for s in data['warnings'] if '-D warnings' not in s]
 details[job]={'slow':slow,'fault_contexts':contexts,'warnings':warnings,'image':data['image']}
 print(json.dumps({'job':job,**details[job]}))
Path(base+'-manual-review-details.json').write_text(json.dumps(details,indent=2)+'\n')
raw=Path(base+'-windows.log').read_text();lines=[re.sub(r'^\ufeff?\d{4}-\d\d-\d\dT\S+Z ','',re.sub(r'\x1b\[[0-9;]*[A-Za-z]','',s)) for s in raw.splitlines()];interleaved=[]
for n,line in enumerate(lines):
 m=re.match(r'test (.+?) \.\.\. S3DRIVE_[A-Z_]+_REFERENCE ',line)
 if m:
  end=next((i for i in range(n+1,min(n+51,len(lines))) if lines[i]=='ok'),None);assert end is not None
  assert not any(s.startswith(('test ','test result:')) for s in lines[n+1:end]);interleaved.append({'test':m.group(1),'start':n+1,'later_ok':end+1})
assert len(interleaved)==15;Path(base+'-interleaved-completions.json').write_text(json.dumps(interleaved,indent=2)+'\n');print(json.dumps({'interleaved':interleaved}))
root=Path('/home/marshall/src/worktrees/s3drive-creator-open-admission')
state=re.findall(r'(?:async )?fn (creator_import_\w+)\(', (root/'crates/s3drive-state/src/manifest_creation/journal_impl/tests/creator_import.rs').read_text());assert len(state)==14
prospective=re.findall(r'(?:async )?fn (prospective_\w+)\(', (root/'crates/s3drive-state/src/manifest_creation/journal_impl/tests/creator_import/prospective.rs').read_text());assert len(prospective)==17
for kind in ['linux','windows']:
 raw=Path(base+'-'+kind+'.log').read_text()
 for name in state+prospective+['creator_import_flow','creator_import_controls','creator_import_crash']:
  assert re.search(r'test [^\r\n]*'+re.escape(name)+r' \.\.\. ok',raw),(kind,name)
print('All17 prospective state,14 prior import state and3 prior SDK case completions checked in both hosted Rust jobs; worker entries included, no new SDK behavior claimed.')
