# Prospective creation admission: state candidate

Updated 2026-10-21. **Candidate, not accepted or installed.** This implements
step A of the [prospective admission design](creator-open-admission.md) in the
Rust state library, using schema 45 and creator format 3. The SDK entry point,
native lifecycle integration and hosted acceptance remain pending. Accepted
main was `02133e0` / runtime `3c38ad1` / schema 44 when this candidate began.

## Implemented local contract

`chunk_mount::Client::creations(limits)` returns a creator client retaining that
worker's typed chunk capability. A format-3 `manifest_creation::Input` includes
an original owner and `CreationOpen { id, session, delete_on_close, posix }`.
`Journal::for_chunks` is the corresponding synchronous state entry point.
Neither API sends a network request. The original source/store/volume must be
in the retained binding; the owner must match the capability, and the session
must belong to the current exclusive state acquisition.

One immediate transaction writes the creator and role projection, original
source binding, inactive controlled/session-bound open, and independent retained
open anchor. It then validates the complete graph and namespace quota before
commit. Any capacity failure, changed retry input, duplicate open or namespace
operation collision rolls back the transaction. Successful repeated admission
returns the same record without charging again. Generic creator admission
refuses format 3; generic open preparation cannot recreate its row. Historical
read/update recovery retains the original identities, without reviving an old
session as a fresh handle.

Unimported, nonrejected creators reserve three namespace slots: the future
import row plus two deferred closing slots. Namespace begin, acknowledgment and
import account for those reservations. Only the exact complete canonical import
converts the reservation into ordinary retained namespace/history accounting.
Other operations cannot steal its operation ID. Exact terminal authority
rejection releases the prospective namespace budget, while the open row remains
until explicit recovery closure and retirement. An unknown result retains both.

An unrelated admitted closing attempt can temporarily occupy its own reserved
credit while its result is unknown. A verified prospective import may still
convert its existing reservation if the complete projected budget is unchanged
and the physical namespace-row limit is respected. This exception permits no
fresh capacity and does not apply to legacy imports without a reservation.

The actual inactive row consumes the existing open-row quota and reserves the
existing controlled callback budget. No counters, tables, quotas, worker slots,
deadlines or stack limits were added or raised. Logical quotas do not reserve
filesystem space; later disk failure remains possible and recoverable.

## Proof and recovery boundaries

Creator loading checks its original raw open input/owner, row checksum and
retained anchor, without reducing open events. Open loading checks creator
metadata/projection and its selected original physical/open witness before
validating events. This avoids recursive role loaders. Namespace budget checks
validate the complete creator metadata projection and physical/open witnesses
for prospective creators; existing full-role APIs still validate all witnesses.
No historical input, stage key, source bytes or receipt is rewritten.

Fresh activation additionally requires the original current runtime session,
successful creator import, and the original fence still locally deferred.
Cancellation or a successor fence cannot activate the original inactive open.
Stored activation proofs are checked against the frozen creator origin; later
history does not erase already recorded activation facts. Local activation does
not prove remote liveness or grant a kernel handle.

Unknown creations, including successful remote creates whose receipt/import is
not locally complete, block session abandonment and retirement. This guard also
runs when loading recovery proofs, so forged no-effect recovery cannot bypass
the mutator's checks. A known rejected creation can close an obsolete session
without fabricating activation or a successful namespace entry. Successful
creations retain their exact closing work after import. No automatic abandon,
deletion, retention or GC is enabled.

## Schema compatibility

Schema 45 is a marker-only change. Format 3 uses a new staging-key hash domain;
its canonical initial 64-byte manifest and authority mutation are unchanged.
New optional fields are omitted from legacy serialization. Format-1/2 inputs,
stage keys, BLOBs, JSON and role hashes retain their original representation.

Before any transaction-local marker change, a bounded raw-shape guard rejects
prospective creators or creator-referencing opens under pre-45 markers. The
pre-44 canonical-import guard still runs against the original version. Valid
43/44 roles then receive a transaction-local current marker for strict role
validation; failure rolls everything back. Earlier unsupported role migrations
remain refusals. Saturated legacy format-1/2 imports still require their own
explicit recovery work; these records have no retrospective reservation.

## Candidate verification

Workspace check and Clippy passed locally. The 15-case focused run passed in
46.17 seconds, followed by a separate concurrent public-worker admission case
(0.20 seconds) and the unrelated-pending-closing conversion case (23.30 seconds).
One of the 15 cases is the subprocess worker entry; the other
cases exercise actual state transactions. The initial workspace check failed
on one missing `creation: None` in an existing multiline test fixture; that
fixture was corrected, and both failed and successful logs are retained.

The tests cover real worker termination at four admission transaction/commit
boundaries, actual SQLITE_FULL rollback/retry, independently saturated open-row
and callback budgets, namespace capacity through import/promotion/final closure,
operation collisions, unknown remote outcomes, known rejection closure,
obsolete sessions, cancellation/successor refusal, schema-44 migration/rollback,
missing anchors and joint creator/open/anchor forgery against the independent
staging witness. Concurrent public-worker calls with the same open ID yield
one complete admission and one refusal, with no partial second creator.

Physical receipts and bulk namespace/open quota history in these state tests
are **modeled**. Worker termination, public worker serialization and SQLite
transactions/disk-full are real. These tests do not establish any provider,
mount, reboot, hosted Windows or remote fencing behavior. Full local gate,
actual schema-44 executable forward-refusal check, exact-source hosted jobs,
native artifact review are pending for state acceptance. SDK step B and native
lifecycle acceptance remain additional prerequisites for integrating this into
mounted creation. Do not enable native flags on the strength of state tests.

Development evidence lives under `/tmp/s3drive-creator-open-state-*`; the retained
actual schema-44 CLI and its checked binary digest are recorded in
`/tmp/s3drive-creator-open-old44-retained.json`. Publication/acceptance evidence
must be made durable before promotion. No user database, credentials, bucket,
startup installation or hosting was touched.
