//! Actual SDK + authenticated authority. No provider/native chunk-write claim.
use super::*;
use s3drive_managed::chunks::{MixedRootRecovery, Reader};
use s3drive_state::sparse_views::{
    self,
    preparation::{self as plans, publication as roots},
};
const C: u64 = s3drive_core::manifest::CHUNK_BYTES;
pub async fn crash(config: &s3drive_core::Config, root: &Path, s: &Server) {
    let seed = setup(config, root, s).await;
    let old = publisher(&seed, s).await;
    let tail = b"unchanged tail!!\0";
    let (oldplan, _) = plan(&seed, s, 10, 40, tail, Some(130 * C + 17), 0).await;
    old.begin(oldplan, id(41)).await.unwrap();
    let initial = old.resume(oldplan).await.unwrap().metadata().clone();
    let st = storage(root, "mixed-root").await;
    let local = st.sparse_views(sparse_views::Options::default()).unwrap();
    let e = executor(config, st.clone(), false, false).await;
    let volume = info(&s.direct).await.id;
    let reader = Reader::open(s.wire.clone(), volume.clone(), vec![(id(200), e.reader())])
        .await
        .unwrap();
    let base = reader.open_file(&id(10)).await.unwrap().pinned_base();
    let v = local
        .begin([1; 32], base.sparse_binding().unwrap(), base.size())
        .await
        .unwrap();
    let bytes = "café 日本語 🦀".as_bytes();
    let edited = local
        .write([2; 32], v.id(), 3, Arc::from(bytes))
        .await
        .unwrap();
    let edit = reader
        .reopen_edited(local.clone(), edited.id())
        .await
        .unwrap();
    let prep = edit
        .begin_preparation([3; 32], [91; 16], plans::Options::default())
        .await
        .unwrap();
    prep.prepare().await.unwrap();
    let publisher = prep.publisher(e.clone(), roots::Limits::default()).unwrap();
    assert!(
        prep.publisher(seed.clone(), roots::Limits::default())
            .is_err()
    );
    assert!(publisher.begin(id(101)).await.is_err());
    s.proxy.mode.store(8, Ordering::SeqCst);
    assert!(publisher.check_semantics().await.is_err());
    s.proxy.mode.store(0, Ordering::SeqCst);
    publisher.check_semantics().await.unwrap();
    assert!(
        publisher.begin(id(101)).await.is_err(),
        "root reserved before physical receipts"
    );
    let physical = prep
        .uploader(e.clone())
        .unwrap()
        .upload_tree()
        .await
        .unwrap();
    assert_eq!(physical.new_objects(), 3);
    s.proxy.mode.store(4, Ordering::SeqCst);
    assert!(publisher.begin(id(101)).await.is_err());
    s.proxy.mode.store(0, Ordering::SeqCst);
    s.proxy.clear();
    let reserved_input = publisher.begin(id(101)).await.unwrap();
    assert!(reserved_input.reservation().is_none());
    assert!(s.proxy.applies().is_empty());
    change(
        &s.direct,
        50,
        Mutation::Move {
            node: id(10),
            parent: s3drive_authority::ROOT.into(),
            name: "renamed café 🦀.bin".into(),
        },
    )
    .await;
    s.proxy.mode.store(1, Ordering::SeqCst);
    assert!(
        publisher.resume().await.is_err(),
        "lost reserve response was acknowledged"
    );
    let client = local
        .preparations(plans::Options::default())
        .unwrap()
        .publications(roots::Limits::default())
        .unwrap();
    let r = client.get(prep.id()).await.unwrap();
    assert!(r.reservation().is_none());
    assert_eq!(r.input().reserve(), reserved_input.input().reserve());
    s.proxy.clear();
    let recovered = publisher.recovery().recover(prep.id()).await.unwrap();
    assert!(recovered.reservation().is_some());
    assert!(recovered.publication().is_none());
    only_exact_apply(s, reserved_input.input().reserve());
    let narrow = executor(config, st.clone(), true, false).await;
    let denied = prep.publisher(narrow, roots::Limits::default()).unwrap();
    s.proxy.clear();
    assert!(denied.resume().await.is_err());
    assert!(
        s.proxy.applies().is_empty(),
        "fresh publish bypassed narrowed policy"
    );
    let newest = local
        .write([4; 32], edited.id(), 1, Arc::from(&b"newer"[..]))
        .await
        .unwrap();
    s.proxy.mode.store(2, Ordering::SeqCst);
    assert!(
        publisher.resume().await.is_err(),
        "lost Publish response was acknowledged"
    );
    let r = client.get(prep.id()).await.unwrap();
    assert!(r.publication().is_some());
    assert!(r.receipt().is_none());
    assert_eq!(r.input().view(), edited.id());
    let n = node(&s.direct, &volume, &id(10)).await;
    assert_eq!(n.name, "renamed café 🦀.bin");
    assert_ne!(n.payload, initial.node.payload);
    let file = reader.open_file(&id(10)).await.unwrap();
    assert_eq!(file.size(), 130 * C + 17);
    assert_eq!(file.read(3, bytes.len()).await.unwrap(), bytes);
    assert_eq!(file.read(130 * C, 17).await.unwrap(), tail);
    assert_eq!(local.head(edited.binding().clone()).await.unwrap(), newest);
    std::fs::write(
        root.join("mixed-root-saved.json"),
        serde_json::to_vec(&r).unwrap(),
    )
    .unwrap();
    std::fs::write(
        root.join("mixed-root-newest.json"),
        serde_json::to_vec(&newest.id()).unwrap(),
    )
    .unwrap();
    checkpoint("CRASH_ROOT");
    std::future::pending::<()>().await;
}
pub async fn recover(root: &Path, s: &Server) {
    let saved: roots::Record =
        serde_json::from_slice(&std::fs::read(root.join("mixed-root-saved.json")).unwrap())
            .unwrap();
    let p = saved.input().plan();
    let path = root.join("mixed-root");
    assert!(
        Storage::open(
            &path,
            cache::Options::default(),
            journal::Options::default()
        )
        .await
        .is_err(),
        "strict normal open accepted damaged source bytes"
    );
    let recovery = MixedRootRecovery::open_existing(
        &path,
        s.wire.clone(),
        saved.input().reserve().volume.clone(),
        saved.input().store().id.clone(),
    )
    .await
    .unwrap();
    s.proxy.clear();
    let done = recovery.recover(p).await.unwrap();
    assert!(done.receipt().is_some());
    assert_eq!(done.publication(), saved.publication());
    assert_eq!(done.input(), saved.input());
    only_exact_apply(s, saved.publication().unwrap());
    s.proxy.clear();
    assert_eq!(recovery.recover(p).await.unwrap(), done);
    assert!(
        s.proxy.requests().is_empty(),
        "known root replay issued RPC"
    );
    recovery.close().await.unwrap();
    assert!(
        Storage::open(
            &path,
            cache::Options::default(),
            journal::Options::default()
        )
        .await
        .is_err(),
        "metadata recovery repaired source data"
    );
    let db = rusqlite::Connection::open(path.join("metadata.sqlite3")).unwrap();
    let head: Vec<u8> = db
        .query_row("SELECT head FROM sparse_view_files", [], |r| r.get(0))
        .unwrap();
    let newest: [u8; 32] =
        serde_json::from_slice(&std::fs::read(root.join("mixed-root-newest.json")).unwrap())
            .unwrap();
    assert_eq!(head, newest);
}
