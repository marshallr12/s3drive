"""Archive the completed W2a portable local gate, not native acceptance."""
import hashlib, io, json, subprocess, tarfile
from pathlib import Path
root=Path('/home/marshall/src/worktrees/s3drive-base-identity-core')
result_path=Path('/tmp/s3drive-base-identity-core-gate-result.json')
r=json.loads(result_path.read_text());assert r['exit_code']==0 and r['session']==33550
frozen_path=Path('/tmp/s3drive-base-identity-core-frozen.json')
frozen=json.loads(frozen_path.read_text());assert len(frozen)==267
for n,h in frozen.items():assert hashlib.sha256((root/n).read_bytes()).hexdigest()==h,n
baseline='41188dd35d6518ff3f97683fce9bec92ab7f3409'
assert subprocess.check_output(['git','-C',str(root),'rev-parse','HEAD']).decode().strip()==baseline
files={'archive-script.py':Path(__file__),'gate-result.json':result_path,'frozen-source.json':frozen_path}
for suffix in ['focused.log','readers.log','gate.log']:files[suffix]=Path('/tmp/s3drive-base-identity-core-'+suffix)
for n,src in {'core-manifest.rs':'crates/s3drive-core/src/manifest.rs','base-codec.rs':'crates/s3drive-core/src/manifest/base.rs','managed-base.rs':'crates/s3drive-managed/src/chunks/reader/base.rs'}.items():files[n]=root/src
p=Path('/tmp/s3drive-base-identity-core-baseline-managed.rs');assert not p.exists();p.write_bytes(subprocess.check_output(['git','-C',str(root),'show',baseline+':crates/s3drive-managed/src/chunks/reader/base.rs']));files['baseline-managed-base.rs']=p
p=Path('/tmp/s3drive-base-identity-core-working.patch');p.write_bytes(subprocess.check_output(['git','-C',str(root),'diff','--binary']));files['working-tree.patch']=p
index={n:hashlib.sha256(p.read_bytes()).hexdigest() for n,p in sorted(files.items())}
archive=root/'docs/src/evidence/base-identity-core-local-20261019.tar.gz';assert not archive.exists()
with tarfile.open(archive,'w:gz') as t:
 for n,p in sorted(files.items()):t.add(p,arcname=n)
 raw=(json.dumps(index,indent=2)+'\n').encode();info=tarfile.TarInfo('sha256-index.json');info.size=len(raw);t.addfile(info,io.BytesIO(raw))
with tarfile.open(archive) as t:
 assert set(t.getnames())==set(index)|{'sha256-index.json'}
 for n,h in index.items():assert hashlib.sha256(t.extractfile(n).read()).hexdigest()==h
proof={'path':str(archive.relative_to(root/'docs/src')),'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'bytes':archive.stat().st_size,'members':len(index)+1,'all_indexed_members_verified':True,'scope':'W2a portable local only'}
Path('/tmp/s3drive-base-identity-core-archive-proof.json').write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps(proof,indent=2))
