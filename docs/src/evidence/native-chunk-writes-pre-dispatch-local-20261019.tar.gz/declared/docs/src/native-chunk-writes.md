# Native chunk writer implementation

Declared 2026-10-19, isolated `codex/native-chunk-writes` from accepted main
1ce2394/schema41/runtime362. Implementation and acceptance are pending.

![Candidate native writer, local S3 and authority clients, private SQLite and immutable bucket objects.](images/native-chunk-writer.svg)

This phase connects canonical creation and the existing authenticated sparse
pipeline to the shared filesystem engine and both native adapters. An explicit
managed version8 write profile selects it, with the same policy-bound executors,
private SQLite owner and immutable bucket objects. Versions3–7 retain their
existing behavior. This is not permission to mutate Wasabi or install startup.

Done criterion: the actual shared filesystem API and real FUSE/WinFsp fixtures
create Unicode canonical files, write/read/flush beyond8MiB without whole-file
hydration, append and constrained-write correctly, shrink/regrow without tail
resurrection, repeat clean flush without new PUTs, close/reopen/remount and recover
exact unknown publication before creating another root. A newer local edit must
survive an older root acknowledgment. Failures retain bytes/requests and return
conflicts; no unguarded overwrite or fresh-ID recovery fallback.

Load-bearing source findings:

- Sparse views expose no bounded all-head enumeration or public clean-state hint;
  shutdown/restart cannot find closed dirty files from in-memory weak references.
- Mixed root recovery can use a normal client only behind a live preparation;
  native startup needs saved-request recovery on that already open owner before
  any fresh base S3 access. The new constructor must retain exact volume/store
  checks and grant no new mutation preparation or physical upload permission.
- A deterministic private domain derives preparation, generation, publication
  and acknowledgment operation IDs from the immutable view ID. Retry must reuse
  original IDs and validate exact saved input. Fresh local edits have new IDs.
- Native writable inodes must keep stable global IDs and report dirty local sizes;
  the immutable-snapshot inode projection used by read-only chunk mounts must
  not conceal writes or substitute a different opened file generation.

Initial footprint: sparse model/worker enumeration helpers; normal mixed-root
recovery constructor; shared filesystem chunk writer and dispatch/config; owned
SDK/shared-engine and FUSE/WinFsp acceptance fixtures; mdBook and handoff. Inspect
actual dependency sources before using new APIs. Preserve target-specific driver
dependencies. No authority schema/mutation, retention deletion or credential work.

This first native writer does not enable rename/delete, deferred creation,
delete-on-close or open-unlinked chunk publication. Those require the separately
[reviewed fence protocol](deferred-manifest-integration.md). Unsupported requests
must fail explicitly; this phase is not full lifecycle or goal completion.
Metadata-empty and old whole-object files remain readable by existing paths but
must not be silently promoted into writable sparse origins. Cold metadata-only
namespace/open recovery and full retry-forest retention remain additional work.

Run focused failure/restart cases, the full local gate and own hosted/native gates
on an unchanged candidate before promotion. Native cases cannot be replaced by
portable API tests. New live provider tests require a separately approved plan.


## Implementation checkpoint

The candidate adds explicit version8 dispatch, a shared sparse writer, bounded
head enumeration and a normal-owner saved-root recovery constructor. Flush IDs
are derived from the captured view; unknown Publish recovery uses the original
saved request before a new plan. Stable writable inodes report local sizes;
read-only immutable snapshot projection stays unchanged for version3.

The SDK/shared-filesystem case passed in19.30s, then the expanded policy narrowing
case passed in50.49s. It covers >8MiB sparse edits, Unicode, append/constrained
writes, shrink/regrow, lost Publish reply, owner restart, exact request replay,
no repeated immutable-target PUT, and retained dirty reads under a narrowed
policy. A later regression also tests that a changed live content format cannot
hide a retained local head; it passed in SDK4/52.51s. Bounded head enumeration
and restart/corruption checks passed in0.18s. Workspace Clippy passed after fixing
one collapsible-if diagnostic without suppression.

Local native attempt1 stopped on a test TOML table insertion bug, fixed before
mounting. Attempt2 reached FUSE and was denied with `Operation not permitted`
despite the device being present. No local native success is claimed and no root
or mount permissions were changed. The new real FUSE/WinFsp fixture is an explicit
CI acceptance step; its coverage cannot be replaced by the passing API test.
The candidate is not promoted or natively accepted yet.

Version8 deliberately uses a separate private journal; populated old writer roles
are refused. The example `examples/managed-chunk-writes.toml` is a template, not a
live-provider authorization or automatic conversion. Readable legacy origins do
not gain write permission. Retained heads are registered at restart so a changed
remote representation produces conflict rather than concealing local bytes.

The current64-file/512-view/64MiB dirty defaults, bounded creation/root histories,
and authority history limits are prototypes, not a completed long-running
retention policy. No reclamation, schema migration or bucket deletion is added.


The captured-view concurrency regression passed in the combined SDK5 case/106.13s.
The scenarios were then split without removing coverage: SDK6 passed all three
shared-filesystem cases in19.95s (one real-driver test explicitly ignored). Each
fixture verifies its exact immutable PUT count and that no target was PUT twice.
They independently cover large Unicode writes/restart, policy/format conflicts,
and an older flush preserving a newer dirty edit. This keeps native platform
failures separate from portable shared-engine failures. The full local gate and
own real OS CI cohort are still required before promotion.


Resolved dependency APIs were inspected locally: getrandom0.4.3 `fill`, sha2
0.11.1/Digest, Tokio1.53.3 semaphore/barrier contracts and rusqlite0.40.2 deferred
transactions. No dependency version or platform driver API was changed. Final
pre-freeze workspace Clippy3 passed in5.87s. The accepted main baseline's own
post-publication CI39339566702 also completed successfully; it does not accept
this new writer candidate.


## First complete cohort rejected

Source a6a44fbf8ca1a27e91e3954b46a64853b5cbf8f1, all692 inputs/runtime365,
failed own CI39343852321 before new native acceptance: Linux's existing paired
authority fixture overflowed the managed child stack, and Windows's existing
metadata-flush mount overflowed the CLI main stack. Book passed and all692 remote
source digests matched; neither fact accepts the writer. The local gate was
explicitly stopped with SIGTERM after149.15s, exit-15, inputs unchanged, to repair
the confirmed regression. It is not a passing gate. Raw logs and frozen inputs
are retained under /tmp/s3drive-native-chunk-{gate1,hosted1}*.

The Linux startup failure reproduced locally (stack-red1). Boxing only the sparse
constructor did not fix it (stack-green1 failed). Boxing the new create, flush-all,
namespace-sync and shutdown dispatch boundaries as well made the same existing
fixture pass in3.79s (stack-green2), without larger stacks, skipped tests or changed
semantics. Complete repaired local and OS cohorts remain required.

Repair focused SDK7 passed3 cases/20.91s, one explicit native-only ignored. Clippy4
passed. A temporary compiler layout probe (outside the repository) measured the
shared flush-all future dropping from24656 to2024 bytes and create from23424 to
10272 bytes. This supports the allocation fix but does not replace real platform
acceptance. No stack-size setting, timeout or fixture requirement was weakened.


## Second complete cohort and ready-marker repair

Repaired source390cf0019b3b8f3fe2514d442735da7f2653f61b passed the full local
gate2 at2026-10-20T00:08:39Z,717.08s, all692 inputs unchanged. State539+1ignored,
publication34+1native-only ignored/178.92s, core39 and S362 passed, together with
formatting, workspaceClippy/build and95 Markdown link checks. Log SHA
0047eabd01314e486c40114f21c9de24f241416f6a27cc394b52a951214c54e5.

Own CI39344646208 Linux failed an existing multipart process-kill fixture at
tests.rs594: its generation-ID ready file existed before fs::write filled it,
and the parent parsed an empty string. This is a fixture synchronization race,
not a passing gate or native evidence. The new fix writes a same-directory pending
file and atomically renames it to the ready path. Parent waiting, all five crash
points, actual child kills, deadlines and database recovery assertions remain
unchanged. The repaired source needs its own full local and OS gates.

The atomic marker fixture passed once/0.37s, then20 repetitions/7.60s exercising
100 actual child kills across the same five boundaries. Workspace Clippy5 passed.
No production state format, metadata protocol or timeout changed in this repair.
