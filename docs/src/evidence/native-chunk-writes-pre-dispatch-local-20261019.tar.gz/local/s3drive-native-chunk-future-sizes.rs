use s3drive_fs::{ReadOnlyFs,OpenFile};
#[unsafe(no_mangle)] pub fn s3drive_open_size(f:&ReadOnlyFs)->usize{let v=f.open(0); let n=std::mem::size_of_val(&v);std::mem::forget(v);n}
#[unsafe(no_mangle)] pub fn s3drive_create_size(f:&ReadOnlyFs)->usize{let v=f.create_file(0,"x",|a,b|a==b,true); let n=std::mem::size_of_val(&v);std::mem::forget(v);n}
#[unsafe(no_mangle)] pub fn s3drive_metadata_size(f:&ReadOnlyFs)->usize{let v=f.metadata(0); let n=std::mem::size_of_val(&v);std::mem::forget(v);n}
#[unsafe(no_mangle)] pub fn s3drive_file_flush_size(f:&OpenFile)->usize{let v=f.flush(); let n=std::mem::size_of_val(&v);std::mem::forget(v);n}
#[unsafe(no_mangle)] pub fn s3drive_flush_all_size(f:&ReadOnlyFs)->usize{let v=f.flush_all(); let n=std::mem::size_of_val(&v);std::mem::forget(v);n}
#[unsafe(no_mangle)] pub fn s3drive_sync_namespace_size(f:&ReadOnlyFs)->usize{let v=f.sync_namespace(); let n=std::mem::size_of_val(&v);std::mem::forget(v);n}
