	.att_syntax
	.file	"s3drive_native_chunk_future_sizes.762049ab1beb0133-cgu.0"
	.section	.text._RNvYNCNvCsa8Mwgk4PN17_33s3drive_native_chunk_future_sizes19s3drive_create_size0INtNtNtCskADBYZwJmSU_4core3ops8function6FnOnceTReB20_EE9call_onceB6_,"ax",@progbits
	.prefalign	4, .Lfunc_end0, nop
	.type	_RNvYNCNvCsa8Mwgk4PN17_33s3drive_native_chunk_future_sizes19s3drive_create_size0INtNtNtCskADBYZwJmSU_4core3ops8function6FnOnceTReB20_EE9call_onceB6_,@function
_RNvYNCNvCsa8Mwgk4PN17_33s3drive_native_chunk_future_sizes19s3drive_create_size0INtNtNtCskADBYZwJmSU_4core3ops8function6FnOnceTReB20_EE9call_onceB6_:
	.cfi_startproc
	cmpq	%rcx, %rsi
	jne	.LBB0_1
	pushq	%rax
	.cfi_def_cfa_offset 16
	movq	%rsi, %rax
	movq	%rdx, %rsi
	movq	%rax, %rdx
	callq	*bcmp@GOTPCREL(%rip)
	testl	%eax, %eax
	sete	%al
	addq	$8, %rsp
	.cfi_def_cfa_offset 8
	retq
.LBB0_1:
	xorl	%eax, %eax
	retq
.Lfunc_end0:
	.size	_RNvYNCNvCsa8Mwgk4PN17_33s3drive_native_chunk_future_sizes19s3drive_create_size0INtNtNtCskADBYZwJmSU_4core3ops8function6FnOnceTReB20_EE9call_onceB6_, .Lfunc_end0-_RNvYNCNvCsa8Mwgk4PN17_33s3drive_native_chunk_future_sizes19s3drive_create_size0INtNtNtCskADBYZwJmSU_4core3ops8function6FnOnceTReB20_EE9call_onceB6_
	.cfi_endproc

	.section	.text.s3drive_create_size,"ax",@progbits
	.globl	s3drive_create_size
	.prefalign	4, .Lfunc_end1, nop
	.type	s3drive_create_size,@function
s3drive_create_size:
	.cfi_startproc
	subq	$4096, %rsp
	.cfi_adjust_cfa_offset 4096
	movq	$0, (%rsp)
	subq	$4096, %rsp
	.cfi_adjust_cfa_offset 4096
	movq	$0, (%rsp)
	subq	$4096, %rsp
	.cfi_adjust_cfa_offset 4096
	movq	$0, (%rsp)
	subq	$4096, %rsp
	.cfi_adjust_cfa_offset 4096
	movq	$0, (%rsp)
	subq	$4096, %rsp
	.cfi_adjust_cfa_offset 4096
	movq	$0, (%rsp)
	subq	$2952, %rsp
	.cfi_def_cfa_offset 23440
	movq	%rdi, %rsi
	movl	$1, (%rsp)
	leaq	.Lanon.df0c9e3c6ff5c9c1f621deddbac92001.0(%rip), %rcx
	leaq	_RNvYNCNvCsa8Mwgk4PN17_33s3drive_native_chunk_future_sizes19s3drive_create_size0INtNtNtCskADBYZwJmSU_4core3ops8function6FnOnceTReB20_EE9call_onceB6_(%rip), %r9
	leaq	8(%rsp), %rdi
	movl	$1, %r8d
	xorl	%edx, %edx
	callq	*_RNvMs2_Cs3DjFjzdO3fA_10s3drive_fsNtB5_10ReadOnlyFs11create_file@GOTPCREL(%rip)
	movl	$23424, %eax
	addq	$23432, %rsp
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end1:
	.size	s3drive_create_size, .Lfunc_end1-s3drive_create_size
	.cfi_endproc

	.section	.text.s3drive_file_flush_size,"ax",@progbits
	.globl	s3drive_file_flush_size
	.prefalign	4, .Lfunc_end2, nop
	.type	s3drive_file_flush_size,@function
s3drive_file_flush_size:
	.cfi_startproc
	subq	$40, %rsp
	.cfi_def_cfa_offset 48
	movq	%rdi, %rsi
	leaq	8(%rsp), %rdi
	callq	*_RNvMs1_Cs3DjFjzdO3fA_10s3drive_fsNtB5_8OpenFile5flush@GOTPCREL(%rip)
	movl	$32, %eax
	addq	$40, %rsp
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end2:
	.size	s3drive_file_flush_size, .Lfunc_end2-s3drive_file_flush_size
	.cfi_endproc

	.section	.text.s3drive_flush_all_size,"ax",@progbits
	.globl	s3drive_flush_all_size
	.prefalign	4, .Lfunc_end3, nop
	.type	s3drive_flush_all_size,@function
s3drive_flush_all_size:
	.cfi_startproc
	subq	$4096, %rsp
	.cfi_adjust_cfa_offset 4096
	movq	$0, (%rsp)
	subq	$4096, %rsp
	.cfi_adjust_cfa_offset 4096
	movq	$0, (%rsp)
	subq	$4096, %rsp
	.cfi_adjust_cfa_offset 4096
	movq	$0, (%rsp)
	subq	$4096, %rsp
	.cfi_adjust_cfa_offset 4096
	movq	$0, (%rsp)
	subq	$4096, %rsp
	.cfi_adjust_cfa_offset 4096
	movq	$0, (%rsp)
	subq	$4096, %rsp
	.cfi_adjust_cfa_offset 4096
	movq	$0, (%rsp)
	subq	$88, %rsp
	.cfi_def_cfa_offset 24672
	movq	%rdi, %rsi
	leaq	8(%rsp), %rdi
	callq	*_RNvMs2_Cs3DjFjzdO3fA_10s3drive_fsNtB5_10ReadOnlyFs9flush_all@GOTPCREL(%rip)
	movl	$24656, %eax
	addq	$24664, %rsp
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end3:
	.size	s3drive_flush_all_size, .Lfunc_end3-s3drive_flush_all_size
	.cfi_endproc

	.section	.text.s3drive_metadata_size,"ax",@progbits
	.globl	s3drive_metadata_size
	.prefalign	4, .Lfunc_end4, nop
	.type	s3drive_metadata_size,@function
s3drive_metadata_size:
	.cfi_startproc
	subq	$2472, %rsp
	.cfi_def_cfa_offset 2480
	movq	%rdi, %rsi
	movq	%rsp, %rdi
	xorl	%edx, %edx
	callq	*_RNvMs2_Cs3DjFjzdO3fA_10s3drive_fsNtB5_10ReadOnlyFs8metadata@GOTPCREL(%rip)
	movl	$2472, %eax
	addq	$2472, %rsp
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end4:
	.size	s3drive_metadata_size, .Lfunc_end4-s3drive_metadata_size
	.cfi_endproc

	.section	.text.s3drive_open_size,"ax",@progbits
	.globl	s3drive_open_size
	.prefalign	4, .Lfunc_end5, nop
	.type	s3drive_open_size,@function
s3drive_open_size:
	.cfi_startproc
	subq	$40, %rsp
	.cfi_def_cfa_offset 48
	movq	%rdi, %rsi
	leaq	8(%rsp), %rdi
	xorl	%edx, %edx
	callq	*_RNvMs2_Cs3DjFjzdO3fA_10s3drive_fsNtB5_10ReadOnlyFs4open@GOTPCREL(%rip)
	movl	$32, %eax
	addq	$40, %rsp
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end5:
	.size	s3drive_open_size, .Lfunc_end5-s3drive_open_size
	.cfi_endproc

	.section	.text.s3drive_sync_namespace_size,"ax",@progbits
	.globl	s3drive_sync_namespace_size
	.prefalign	4, .Lfunc_end6, nop
	.type	s3drive_sync_namespace_size,@function
s3drive_sync_namespace_size:
	.cfi_startproc
	subq	$4096, %rsp
	.cfi_adjust_cfa_offset 4096
	movq	$0, (%rsp)
	subq	$4096, %rsp
	.cfi_adjust_cfa_offset 4096
	movq	$0, (%rsp)
	subq	$4096, %rsp
	.cfi_adjust_cfa_offset 4096
	movq	$0, (%rsp)
	subq	$4096, %rsp
	.cfi_adjust_cfa_offset 4096
	movq	$0, (%rsp)
	subq	$4096, %rsp
	.cfi_adjust_cfa_offset 4096
	movq	$0, (%rsp)
	subq	$2776, %rsp
	.cfi_def_cfa_offset 23264
	movq	%rdi, %rsi
	movq	%rsp, %rdi
	callq	*_RNvMs2_Cs3DjFjzdO3fA_10s3drive_fsNtB5_10ReadOnlyFs14sync_namespace@GOTPCREL(%rip)
	movl	$23256, %eax
	addq	$23256, %rsp
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end6:
	.size	s3drive_sync_namespace_size, .Lfunc_end6-s3drive_sync_namespace_size
	.cfi_endproc

	.type	.Lanon.df0c9e3c6ff5c9c1f621deddbac92001.0,@object
	.section	.rodata..Lanon.df0c9e3c6ff5c9c1f621deddbac92001.0,"a",@progbits
.Lanon.df0c9e3c6ff5c9c1f621deddbac92001.0:
	.byte	120
	.size	.Lanon.df0c9e3c6ff5c9c1f621deddbac92001.0, 1

	.ident	"rustc version 1.99.1 (58cf8f9c3 2026-10-13)"
	.section	".note.GNU-stack","",@progbits
