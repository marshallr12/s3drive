import datetime,hashlib,json,os,pathlib,subprocess,time
root=pathlib.Path('/home/marshall/src/worktrees/s3drive-native-chunk-writes')
base=pathlib.Path('/tmp/s3drive-native-chunk-gate3')
def now(): return datetime.datetime.now(datetime.timezone.utc).isoformat()
def catalog():
    paths=subprocess.check_output(['git','ls-files','-z','--cached','--others','--exclude-standard'],cwd=root).split(b'\0')
    return {os.fsdecode(p):hashlib.sha256((root/os.fsdecode(p)).read_bytes()).hexdigest() for p in sorted(set(paths)) if p}
def save(suffix,data): pathlib.Path(str(base)+suffix).write_text(json.dumps(data,indent=2)+'\n')
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
before=catalog();save('-source.json',{'head':head,'inputs':before})
env=os.environ.copy();env['CARGO_TARGET_DIR']='/home/marshall/src/s3drive/target';env['RUST_TEST_THREADS']='4'
started=now();clock=time.monotonic()
with open(str(base)+'.log','wb') as out:
    child=subprocess.Popen(['bash','scripts/gate.sh'],cwd=root,env=env,stdout=out,stderr=subprocess.STDOUT,start_new_session=True)
    save('-running.json',{'runner':os.getpid(),'child':child.pid,'head':head,'started':started,'inputs':len(before)})
    print(json.dumps({'runner':os.getpid(),'child':child.pid,'head':head,'inputs':len(before)}),flush=True)
    try: code=child.wait(timeout=3600)
    except subprocess.TimeoutExpired:
        import signal
        os.killpg(child.pid,signal.SIGTERM);child.wait(timeout=30);code=124
    after=catalog()
    changed=[p for p in sorted(set(before)|set(after)) if before.get(p)!=after.get(p)]
    result={'head':head,'started':started,'finished':now(),'elapsed_seconds':round(time.monotonic()-clock,2),'exit_code':code,'inputs':len(before),'unchanged':not changed,'changed':changed,'log_sha256':hashlib.sha256(pathlib.Path(str(base)+'.log').read_bytes()).hexdigest()}
    save('-result.json',result);print(json.dumps(result),flush=True)
raise SystemExit(code if code else (0 if not changed else 3))
