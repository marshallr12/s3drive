$ErrorActionPreference='Stop'
Set-StrictMode -Version Latest
$repo='/home/marshall/src/worktrees/s3drive-mixed-upload-auth-batch'
. "$repo/scripts/windows-replacement-fixture.ps1"
. "$repo/scripts/windows-reference-fixture.ps1"
$replacement=Get-Content -Raw /tmp/s3drive-upload-auth-batch-hosted-artifacts/windows-replacement-reference.json|ConvertFrom-Json
$original=Get-Content -Raw /tmp/s3drive-upload-auth-batch-hosted-artifacts/windows-disposition-reference.json|ConvertFrom-Json
$rf=Get-Content -Raw "$repo/docs/src/evidence/windows-replacement-reference-20261017.json"|ConvertFrom-Json
$of=Get-Content -Raw "$repo/docs/src/evidence/windows-disposition-reference-20261017.json"|ConvertFrom-Json
foreach($report in @($replacement,$original)) {if($report.source_commit -cne '2fc45fed5a15c1a24f0f9713ab7caca02569ec5b'){throw 'Wrong source'}}
Assert-WindowsReplacementReference -Fixture $rf -Observation $replacement
Assert-WindowsDispositionReference -Fixture $of -Observation $original
Write-Output 'PASS: UploadAuthBatch mixed-root publication and metadata-only recovery cohort typed21/14 project oracles and exact source'
