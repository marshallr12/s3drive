$ErrorActionPreference='Stop'
Set-StrictMode -Version Latest
$repo='/home/marshall/src/worktrees/s3drive-empty-manifest-intent'
. "$repo/scripts/windows-replacement-fixture.ps1"
. "$repo/scripts/windows-reference-fixture.ps1"
$replacement=Get-Content -Raw /tmp/s3drive-empty-intent2-hosted-artifacts/windows-replacement-reference.json|ConvertFrom-Json
$original=Get-Content -Raw /tmp/s3drive-empty-intent2-hosted-artifacts/windows-disposition-reference.json|ConvertFrom-Json
$rf=Get-Content -Raw "$repo/docs/src/evidence/windows-replacement-reference-20261017.json"|ConvertFrom-Json
$of=Get-Content -Raw "$repo/docs/src/evidence/windows-disposition-reference-20261017.json"|ConvertFrom-Json
foreach($report in @($replacement,$original)) {if($report.source_commit -cne 'bb17161ecd60d31b34dfc90b341b5ea4d3d6d899'){throw 'Wrong source'}}
Assert-WindowsReplacementReference -Fixture $rf -Observation $replacement
Assert-WindowsDispositionReference -Fixture $of -Observation $original
Write-Output 'PASS: EmptyIntent repaired cohort inherited Windows reference typed21/14 project oracles and exact source'
