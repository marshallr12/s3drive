from pathlib import Path
import os,subprocess,json,hashlib,datetime,signal
root=Path('/home/marshall/src/worktrees/s3drive-managed-reader-guards');base=Path('/tmp/s3drive-managed-guards-component1');frozen=Path('/tmp/s3drive-managed-guards-candidate1-frozen.json');m=json.loads(frozen.read_text());assert len(m)==337
for p,h in m.items():assert hashlib.sha256((root/p).read_bytes()).hexdigest()==h,p
running=Path(str(base)+'-running.json');result=Path(str(base)+'-result.json');assert not running.exists() and not result.exists()
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def ticks(pid):return Path(f'/proc/{pid}/stat').read_text().rsplit(')',1)[1].split()[19]
def save(p,d):
 t=Path(str(p)+'.tmp');t.write_text(json.dumps(d,indent=2)+'\n');os.chmod(t,0o600);t.replace(p)
env=os.environ.copy();env['CARGO_TARGET_DIR']='/home/marshall/src/s3drive/target';env['RUST_TEST_THREADS']='4'
record={'scope':'state and SDK reader component regression; not full workspace/native acceptance','runner_pid':os.getpid(),'runner_start_ticks':ticks(os.getpid()),'started':now(),'cwd':str(root),'runtime_inputs':337,'frozen_map':str(frozen),'rust_test_threads':4,'tty':False,'legs':[]}
commands=[('state',['cargo','test','-p','s3drive-state','--locked']),('reader',['cargo','test','-p','s3drive-cli','--test','chunk_reader','--locked'])]
code=0
for name,command in commands:
 log=Path(str(base)+'-'+name+'.log');assert not log.exists()
 with log.open('xb') as out:
  child=subprocess.Popen(command,cwd=root,env=env,stdin=subprocess.DEVNULL,stdout=out,stderr=subprocess.STDOUT,start_new_session=True)
  def stop(sig,_frame):
   try:os.killpg(child.pid,sig)
   except ProcessLookupError:pass
  signal.signal(signal.SIGTERM,stop);signal.signal(signal.SIGINT,stop)
  leg={'name':name,'command':command,'log':str(log),'started':now(),'child_pid':child.pid,'child_start_ticks':ticks(child.pid)};record['current_leg']=leg;save(running,record);code=child.wait()
 leg.update(exit_code=code,finished=now(),sha256=hashlib.sha256(log.read_bytes()).hexdigest());record['legs'].append(leg)
 if code:break
changed=[p for p,h in m.items() if hashlib.sha256((root/p).read_bytes()).hexdigest()!=h]
record.update(exit_code=code,finished=now(),all_inputs_unchanged=not changed,changed_inputs=changed);save(result,record)
raise SystemExit(code if code>=0 else 128-code)
