"""Archive the completed W1c1 portable local gate, not hosted acceptance."""
import hashlib
import io
import json
from pathlib import Path
import subprocess
import tarfile

root = Path('/home/marshall/src/worktrees/s3drive-payload-history-authority')
result_path = Path('/tmp/s3drive-payload-history-gate-result.json')
result = json.loads(result_path.read_text())
assert result['exit_code'] == 0 and result['session'] == 60956
frozen_path = Path('/tmp/s3drive-payload-history-frozen.json')
frozen = json.loads(frozen_path.read_text())
assert len(frozen) == 262
for name, digest in frozen.items():
    assert hashlib.sha256((root / name).read_bytes()).hexdigest() == digest, name
assert subprocess.check_output(['git', '-C', str(root), 'rev-parse', 'HEAD']).decode().strip() == 'da84d3a05e0562bed00f77f3ea5aece935e52d32'
files = {'gate-result.json': result_path, 'frozen-source.json': frozen_path,
         'archive-script.py': Path(__file__)}
for suffix in ['check.log', 'state-focused.log', 'http-focused.log', 'size-negative.log',
               'state-focused2.log', 'http-focused2.log', 'gate.log']:
    files[suffix] = Path('/tmp/s3drive-payload-history-' + suffix)
for name, path in {
    'authority.rs': 'crates/s3drive-authority/src/lib.rs',
    'wire.rs': 'crates/s3drive-authority/src/wire.rs',
    'authority-namespace-tests.rs': 'crates/s3drive-authority/tests/namespace.rs',
    'authority-history-test.rs': 'crates/s3drive-authority/tests/namespace/history.rs',
    'publication.rs': 'crates/s3drive-state/src/namespace/publication.rs',
    'history.rs': 'crates/s3drive-state/src/namespace/publication/history.rs',
    'manifest-tests.rs': 'crates/s3drive-state/src/namespace/publication/manifest/tests.rs',
    'history-tests.rs': 'crates/s3drive-state/src/namespace/publication/manifest/tests/history.rs',
}.items():
    files[name] = root / path
patch = Path('/tmp/s3drive-payload-history-working-tree.patch')
patch.write_bytes(subprocess.check_output(['git', '-C', str(root), 'diff', '--binary']))
files['working-tree.patch'] = patch
index = {name: hashlib.sha256(path.read_bytes()).hexdigest() for name, path in sorted(files.items())}
archive = root / 'docs/src/evidence/manifest-history-local-20261018.tar.gz'
assert not archive.exists()
with tarfile.open(archive, 'w:gz') as tar:
    for name, path in sorted(files.items()):
        tar.add(path, arcname=name)
    raw = (json.dumps(index, indent=2) + '\n').encode()
    entry = tarfile.TarInfo('sha256-index.json')
    entry.size = len(raw)
    tar.addfile(entry, io.BytesIO(raw))
with tarfile.open(archive) as tar:
    assert set(tar.getnames()) == set(index) | {'sha256-index.json'}
    for name, digest in index.items():
        assert hashlib.sha256(tar.extractfile(name).read()).hexdigest() == digest
proof = {'path': str(archive.relative_to(root / 'docs/src')),
         'sha256': hashlib.sha256(archive.read_bytes()).hexdigest(),
         'bytes': archive.stat().st_size, 'members': len(index) + 1,
         'all_indexed_members_verified': True, 'scope': 'W1c1 portable local only'}
Path('/tmp/s3drive-payload-history-local-archive-proof.json').write_text(json.dumps(proof, indent=2) + '\n')
print(json.dumps(proof, indent=2))
