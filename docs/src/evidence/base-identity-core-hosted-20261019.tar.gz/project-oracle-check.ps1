$ErrorActionPreference='Stop'
Set-StrictMode -Version Latest
$repo='/home/marshall/src/worktrees/s3drive-base-identity-core'
. "$repo/scripts/windows-replacement-fixture.ps1"
. "$repo/scripts/windows-reference-fixture.ps1"
$replacement=Get-Content -Raw /tmp/s3drive-base-identity-core-hosted-artifacts/windows-replacement-reference.json|ConvertFrom-Json
$original=Get-Content -Raw /tmp/s3drive-base-identity-core-hosted-artifacts/windows-disposition-reference.json|ConvertFrom-Json
$rf=Get-Content -Raw "$repo/docs/src/evidence/windows-replacement-reference-20261017.json"|ConvertFrom-Json
$of=Get-Content -Raw "$repo/docs/src/evidence/windows-disposition-reference-20261017.json"|ConvertFrom-Json
foreach($report in @($replacement,$original)) {if($report.source_commit -cne 'c279e0fe20054b86d015b5899a96b1070c261e2e'){throw 'Wrong source'}}
Assert-WindowsReplacementReference -Fixture $rf -Observation $replacement
Assert-WindowsDispositionReference -Fixture $of -Observation $original
Write-Output 'PASS: W2a core identity cohort typed21/14 project oracles and exact source'
