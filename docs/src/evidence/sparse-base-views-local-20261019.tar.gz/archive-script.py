"""Archive only completed W2b1 portable local evidence, retaining failed controls."""
import hashlib,io,json,subprocess,tarfile
from pathlib import Path
root=Path('/home/marshall/src/worktrees/s3drive-sparse-edit-views')
result_path=Path('/tmp/s3drive-sparse-views-gate3-result.json');r=json.loads(result_path.read_text());assert r['exit_code']==0 and r['session']==96485
freeze=Path('/tmp/s3drive-sparse-views-frozen.json');m=json.loads(freeze.read_text());assert len(m)==275
for n,h in m.items():assert hashlib.sha256((root/n).read_bytes()).hexdigest()==h,n
old=Path('/tmp/s3drive-sparse-views-gate1-frozen.json');oldmap=json.loads(old.read_text());assert set(oldmap)==set(m)
assert [n for n in m if m[n]!=oldmap[n]]==['crates/s3drive-state/src/authority_snapshot/native.rs']
baseline='e90d791812b63adfc53501c23c24979b37c881c5';assert subprocess.check_output(['git','-C',str(root),'rev-parse','HEAD']).decode().strip()==baseline
files={'archive-script.py':Path(__file__),'gate-result.json':result_path,'frozen-source.json':freeze,'gate1-frozen.json':old,'gate1-failure.json':Path('/tmp/s3drive-sparse-views-gate1-failure.json')}
files['gate2-termination.json']=Path('/tmp/s3drive-sparse-views-gate2-termination.json')
files['gate2-frozen.json']=Path('/tmp/s3drive-sparse-views-gate2-frozen.json')
for suffix in ['focused1.log','focused2.log','focused3.log','migrations.log','snapshot-cli.log','snapshot-state.log','snapshot-state2.log','gate.log','gate2.log','gate3.log']:
 files[suffix]=Path('/tmp/s3drive-sparse-views-'+suffix)
for name,src in {
 '029.sql':'crates/s3drive-state/migrations/029.sql','sparse-views.rs':'crates/s3drive-state/src/sparse_views.rs','model.rs':'crates/s3drive-state/src/sparse_views/model.rs','tests.rs':'crates/s3drive-state/src/sparse_views/tests.rs','faults.rs':'crates/s3drive-state/src/sparse_views/tests/faults.rs','migration-tests.rs':'crates/s3drive-state/src/sparse_views/tests/migration.rs','worker-tests.rs':'crates/s3drive-state/src/sparse_views/tests/worker.rs','legacy-fixture-helper.rs':'crates/s3drive-state/src/test_schema.rs',
 'state-lib.rs':'crates/s3drive-state/src/lib.rs','chunk-publication.rs':'crates/s3drive-state/src/chunk_publication.rs','namespace.rs':'crates/s3drive-state/src/namespace.rs','worker.rs':'crates/s3drive-state/src/worker.rs','snapshot-native.rs':'crates/s3drive-state/src/authority_snapshot/native.rs',
 'windows-session.ps1':'scripts/test-windows-session.ps1','windows-snapshot.ps1':'scripts/test-windows-snapshot-worker.ps1','diagram.svg':'docs/src/images/sparse-base-view.svg',
}.items():files[name]=root/src
files['diagram-reviewed.png']=Path('/tmp/s3drive-sparse-base-view-review.png')
p=Path('/tmp/s3drive-sparse-views-failed-native.rs');assert not p.exists();p.write_bytes(subprocess.check_output(['git','-C',str(root),'show',baseline+':crates/s3drive-state/src/authority_snapshot/native.rs']));assert hashlib.sha256(p.read_bytes()).hexdigest()==oldmap['crates/s3drive-state/src/authority_snapshot/native.rs'];files['gate1-tested-native.rs']=p
p=Path('/tmp/s3drive-sparse-views-working.patch');p.write_bytes(subprocess.check_output(['git','-C',str(root),'diff','--binary']));files['working-tree.patch']=p
index={n:hashlib.sha256(p.read_bytes()).hexdigest() for n,p in sorted(files.items())}
archive=root/'docs/src/evidence/sparse-base-views-local-20261019.tar.gz';assert not archive.exists()
with tarfile.open(archive,'w:gz') as t:
 for n,p in sorted(files.items()):t.add(p,arcname=n)
 raw=(json.dumps(index,indent=2)+'\n').encode();info=tarfile.TarInfo('sha256-index.json');info.size=len(raw);t.addfile(info,io.BytesIO(raw))
with tarfile.open(archive) as t:
 assert set(t.getnames())==set(index)|{'sha256-index.json'}
 for n,h in index.items():assert hashlib.sha256(t.extractfile(n).read()).hexdigest()==h
proof={'path':str(archive.relative_to(root/'docs/src')),'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'bytes':archive.stat().st_size,'members':len(index)+1,'all_indexed_members_verified':True,'scope':'W2b1 portable local only'}
Path('/tmp/s3drive-sparse-views-local-archive-proof.json').write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps(proof,indent=2))
