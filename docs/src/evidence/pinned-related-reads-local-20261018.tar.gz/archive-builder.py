import hashlib,io,json,tarfile
from pathlib import Path
root=Path('/home/marshall/src/worktrees/s3drive-pinned-related-reads')
result=Path('/tmp/s3drive-pinned-related-gate-result.json');r=json.loads(result.read_text());assert r['exit_code']==0 and r['all_252_hashes_match']
frozen=Path('/tmp/s3drive-pinned-related-frozen.json');m=json.loads(frozen.read_text());assert len(m)==252
for p,h in m.items():assert hashlib.sha256((root/p).read_bytes()).hexdigest()==h,p
files={'full-gate.log':Path('/tmp/s3drive-pinned-related-gate.log'),'focused.log':Path('/tmp/s3drive-pinned-related-focus2.log'),'initial-fixture-failure.log':Path('/tmp/s3drive-pinned-related-focus.log'),'gate-result.json':result,'frozen-source.json':frozen,'self-review.json':Path('/tmp/s3drive-pinned-related-review.json'),'dependency-audit.json':Path('/tmp/s3drive-pinned-related-dependency-audit.json'),'reader.rs':root/'crates/s3drive-s3/src/reader.rs','reader-tests.rs':root/'crates/s3drive-s3/src/reader/tests.rs','runtime-delta.patch':Path('/tmp/s3drive-pinned-related-runtime.patch'),'archive-builder.py':Path(__file__)}
archive=root/'docs/src/evidence/pinned-related-reads-local-20261018.tar.gz';assert not archive.exists()
index={n:hashlib.sha256(p.read_bytes()).hexdigest() for n,p in sorted(files.items())}
with tarfile.open(archive,'w:gz') as t:
 for n,p in sorted(files.items()):t.add(p,arcname=n)
 raw=(json.dumps(index,indent=2)+'\n').encode();i=tarfile.TarInfo('sha256-index.json');i.size=len(raw);t.addfile(i,io.BytesIO(raw))
with tarfile.open(archive) as t:
 assert set(t.getnames())==set(index)|{'sha256-index.json'}
 for n,h in index.items():assert hashlib.sha256(t.extractfile(n).read()).hexdigest()==h,n
proof={'path':str(archive.relative_to(root/'docs/src')),'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'bytes':archive.stat().st_size,'members':len(index)+1,'all_indexed_members_verified':True,'scope':'local S3 helper gate evidence; no hosted/native manifest/provider acceptance'}
Path('/tmp/s3drive-pinned-related-archive-proof.json').write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps(proof,indent=2))
