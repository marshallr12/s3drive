"""Review aid: scan every raw line; require explicit human/agent review before marker creation."""
from pathlib import Path
import hashlib,json,re,subprocess
run=json.loads(Path('/tmp/s3drive-creator-open-sdk-hosted1-result.json').read_text())
assert run['headSha']=='8022fae3d1b496c511321f0ee6294908bc749039' and run['conclusion']=='success'
jobs={j['databaseId']:{'book':'book','rust (ubuntu-latest)':'linux','rust (windows-latest)':'windows'}[j['name']] for j in run['jobs']}
summary={}
for job,name in jobs.items():
 p=Path('/tmp/s3drive-creator-open-sdk-hosted1-'+name+'.log')
 assert p.exists(),p
 raw=p.read_text(); clean=re.sub(r'\x1b\[[0-9;]*[A-Za-z]','',raw)
 lines=[re.sub(r'^\ufeff?\d{4}-\d\d-\d\dT\S+Z ','',re.sub(r'^[^\t]*\t[^\t]*\t','',line)) for line in clean.splitlines()]
 outcomes=[];interleaved=[];unknown=[];warnings=[];faults=[];slow=[]
 for number,line in enumerate(lines,1):
  m=re.match(r'^test (.+?) \.\.\. (.*)$',line)
  if m:
   result=m.group(2)
   if result=='ok' or result.startswith('ignored'):outcomes.append((m.group(1),result))
   elif re.match(r'S3DRIVE_[A-Z_]+_REFERENCE \{',result):interleaved.append((number,m.group(1)))
   else:unknown.append((number,line))
  if re.search(r'\bwarning\b|DeprecationWarning',line,re.I):warnings.append(line)
  if re.search(r'##\[error\]|test result: FAILED|panicked at|^failures:|^error:|^Error:|^WARNING:',line):faults.append((number,line))
  if 'has been running for over 60 seconds' in line:slow.append(line)
 assert not unknown,(name,unknown)
 assert all('test '+name+' ... ok' in clean for name,result in outcomes if result=='ok')
 for number,test in interleaved:
  following=lines[number:number+50]
  end=next((i for i,line in enumerate(following) if line=='ok'),None)
  assert end is not None,(name,test,'no bounded completion after reference records')
  assert not any(line.startswith('test ') or line.startswith('test result:') for line in following[:end]),(name,test,'another test before completion')
 summary[str(job)]={'job_id':job,'run_attempt':1,'log':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'lines':len(lines),'test_lines_parsed':len(outcomes),'interleaved_reference_test_lines':len(interleaved),'warnings':warnings,'fault_lines':faults,'slow_tests':slow,'results':[line for line in lines if 'test result:' in line],'image':[line for line in lines if 'Image:' in line or 'Version: 2026' in line or line in ['Ubuntu','Microsoft Windows Server 2025']]}
Path('/tmp/s3drive-creator-open-sdk-hosted1-raw-review-scan.json').write_text(json.dumps(summary,indent=2)+'\n')
for job,data in summary.items():print(json.dumps({'job':job,**{k:data[k] for k in ['lines','test_lines_parsed','interleaved_reference_test_lines','fault_lines','slow_tests','image']}}))
