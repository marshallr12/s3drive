"""Archive only the completed W1c2 local gate; no hosted/native acceptance."""
import hashlib, io, json, subprocess, tarfile
from pathlib import Path
root=Path('/home/marshall/src/worktrees/s3drive-payload-history-authority')
result_path=Path('/tmp/s3drive-base-reopen-gate2-result.json')
result=json.loads(result_path.read_text())
assert result['exit_code']==0 and result['session']==95974
frozen_path=Path('/tmp/s3drive-base-reopen-frozen.json')
frozen=json.loads(frozen_path.read_text());assert len(frozen)==266
for n,h in frozen.items():assert hashlib.sha256((root/n).read_bytes()).hexdigest()==h,n
files={'gate-result.json':result_path,'frozen-source.json':frozen_path,'archive-script.py':Path(__file__),
       'gate1-failure.json':Path('/tmp/s3drive-base-reopen-gate1-failure.json'),
       'gate1-frozen.json':Path('/tmp/s3drive-base-reopen-gate1-frozen.json')}
for suffix in ['check.log','focused.log','focused2.log','readers.log','gate.log','gate2.log']:
 files[suffix]=Path('/tmp/s3drive-base-reopen-'+suffix)
for name,src in {
 'reader.rs':'crates/s3drive-managed/src/chunks/reader.rs',
 'base.rs':'crates/s3drive-managed/src/chunks/reader/base.rs',
 'provenance.rs':'crates/s3drive-managed/src/chunks/reader/provenance.rs',
 'pages.rs':'crates/s3drive-managed/src/chunks/reader/provenance/pages.rs',
 'chunk-reader-tests.rs':'crates/s3drive-cli/tests/chunk_reader.rs',
 'fixture.rs':'crates/s3drive-cli/tests/chunk_reader/fixture.rs',
 'reopen-tests.rs':'crates/s3drive-cli/tests/chunk_reader/reopen.rs',
 'authority-history.rs':'crates/s3drive-state/src/namespace/publication/history.rs',
}.items():files[name]=root/src
patch=Path('/tmp/s3drive-base-reopen-working-tree.patch')
patch.write_bytes(subprocess.check_output(['git','-C',str(root),'diff','--binary']))
files['working-tree.patch']=patch
index={n:hashlib.sha256(p.read_bytes()).hexdigest() for n,p in sorted(files.items())}
archive=root/'docs/src/evidence/manifest-base-reopen-local-20261018.tar.gz'
assert not archive.exists()
with tarfile.open(archive,'w:gz') as tar:
 for n,p in sorted(files.items()):tar.add(p,arcname=n)
 raw=(json.dumps(index,indent=2)+'\n').encode();info=tarfile.TarInfo('sha256-index.json');info.size=len(raw);tar.addfile(info,io.BytesIO(raw))
with tarfile.open(archive) as tar:
 assert set(tar.getnames())==set(index)|{'sha256-index.json'}
 for n,h in index.items():assert hashlib.sha256(tar.extractfile(n).read()).hexdigest()==h
proof={'path':str(archive.relative_to(root/'docs/src')),'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),
       'bytes':archive.stat().st_size,'members':len(index)+1,'all_indexed_members_verified':True,'scope':'W1c2 portable local only'}
Path('/tmp/s3drive-base-reopen-local-archive-proof.json').write_text(json.dumps(proof,indent=2)+'\n')
print(json.dumps(proof,indent=2))
