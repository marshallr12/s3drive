"""One-use full local combined-retention evidence; own native/platform gates remain separate."""
from pathlib import Path
import json,hashlib,tarfile,io,subprocess,re
root=Path('/home/marshall/src/worktrees/s3drive-external-clean-local');out=root/'docs/src/evidence/external-clean-local-local-20261019.tar.gz';assert not out.exists()
m=json.loads(Path('/tmp/s3drive-external-clean-local-candidate1-frozen.json').read_text());assert len(m)==340
r=json.loads(Path('/tmp/s3drive-external-clean-local-gate1-result.json').read_text());assert r['exit_code']==0 and r['all_inputs_unchanged'] and r['runtime_inputs']==340 and r['rust_test_threads']==4
assert r['command']==['bash','scripts/gate.sh']
raw=Path(r['log']).read_bytes();assert hashlib.sha256(raw).hexdigest()==r['sha256']
counts={}
for label,passed,ignored in [('publication',24,0),('state',494,1),('reader',23,1),('core',37,0),('s3',62,0)]:
 match=re.search(fr'test result: ok\. {passed} passed; 0 failed; {ignored} ignored; 0 measured; 0 filtered out; finished in ([0-9.]+)s'.encode(),raw);assert match,label
 counts[label]={'passed':passed,'ignored':ignored,'seconds':float(match.group(1))}
files={}
for name,sha in m.items():
 body=(root/name).read_bytes();assert hashlib.sha256(body).hexdigest()==sha,name
 assert hashlib.sha256(subprocess.check_output(['git','-C',str(root),'show','67a75e3:'+name])).hexdigest()==sha,name
 files['final-source/'+name]=body
for suffix in ['candidate1-frozen.json','gate1.log','gate1-running.json','gate1-result.json','gate1-runner.py']:
 p=Path('/tmp/s3drive-external-clean-local-'+suffix);files[p.name]=p.read_bytes()
parents=[('accepted-guards-local',Path('/home/marshall/src/s3drive/docs/src/evidence/managed-batched-local-20261019.tar.gz'),Path('/tmp/s3drive-managed-batched-local-archive-proof.json')),('accepted-guards-hosted',Path('/home/marshall/src/s3drive/docs/src/evidence/managed-batched-hosted-20261019.tar.gz'),Path('/tmp/s3drive-managed-batched-hosted-archive-proof.json'))]
for label,path,proof_path in parents:
 proof=json.loads(proof_path.read_text());assert hashlib.sha256(path.read_bytes()).hexdigest()==proof['sha256']
 with tarfile.open(path) as t:
  index=json.loads(t.extractfile('sha256-index.json').read());assert set(t.getnames())==set(index)|{'sha256-index.json'}
  for name,sha in index.items():assert hashlib.sha256(t.extractfile(name).read()).hexdigest()==sha,(label,name)
 files['parent-evidence/'+label+'/'+path.name]=path.read_bytes();files['parent-evidence/'+label+'/'+proof_path.name]=proof_path.read_bytes()
for label in ['focused1','published1','clippy1']:
 p=Path('/tmp/s3drive-external-clean-local-'+label+'.log');files[p.name]=p.read_bytes()
files['local-archive-builder.py']=Path(__file__).read_bytes()
files['executed-contract.md']=(root/'docs/src/external-clean-local.md').read_bytes()
index={name:hashlib.sha256(body).hexdigest() for name,body in files.items()}
with tarfile.open(out,'x:gz') as t:
 for name,body in sorted(files.items()):
  info=tarfile.TarInfo(name);info.mode=0o644;info.mtime=0;info.size=len(body);t.addfile(info,io.BytesIO(body))
 body=(json.dumps(index,indent=2)+'\n').encode();info=tarfile.TarInfo('sha256-index.json');info.mode=0o644;info.mtime=0;info.size=len(body);t.addfile(info,io.BytesIO(body))
with tarfile.open(out) as t:
 assert set(t.getnames())==set(index)|{'sha256-index.json'}
 for name,sha in index.items():assert hashlib.sha256(t.extractfile(name).read()).hexdigest()==sha,name
proof={'scope':'complete local gate only; parent and own hosted/platform/source/native acceptance required','path':str(out.relative_to(root/'docs/src')),'sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'bytes':out.stat().st_size,'members':len(index)+1,'all_indexed_members_verified':True,'runtime_inputs':340,'source_checkpoint':'67a75e3','schema':38,'gate_exit_code':0,'gate_log_sha256':r['sha256'],'rust_test_threads':4,'reduced_sdk_admission':False,'counts':counts,'parent_archives_independently_verified':2}
Path('/tmp/s3drive-external-clean-local-local-archive-proof.json').write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps(proof,indent=2))
