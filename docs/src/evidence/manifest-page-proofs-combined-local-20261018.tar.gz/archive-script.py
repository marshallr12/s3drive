"""Pack only the completed combined W1b local gate and exact helper inputs."""
import hashlib
import io
import json
from pathlib import Path
import subprocess
import tarfile

root = Path('/home/marshall/src/worktrees/s3drive-manifest-page-proofs')
result_path = Path('/tmp/s3drive-page-proofs-combined-gate-result.json')
result = json.loads(result_path.read_text())
assert result['exit_code'] == 0 and result['session'] == 68162
frozen_path = Path('/tmp/s3drive-page-proofs-combined-frozen.json')
frozen = json.loads(frozen_path.read_text())
assert len(frozen) == 261
for name, digest in frozen.items():
    assert hashlib.sha256((root / name).read_bytes()).hexdigest() == digest, name
files = {'gate-result.json': result_path, 'frozen-source.json': frozen_path}
files['gate.log'] = Path('/tmp/s3drive-page-proofs-combined-gate.log')
files['independent-gate-result.json'] = Path('/tmp/s3drive-page-proofs-gate-result.json')
files['independent-archive-proof.json'] = Path('/tmp/s3drive-page-proofs-local-archive-proof.json')
for name, path in {
    'pages.rs': 'crates/s3drive-managed/src/chunks/reader/provenance/pages.rs',
    'provenance.rs': 'crates/s3drive-managed/src/chunks/reader/provenance.rs',
    'reader.rs': 'crates/s3drive-managed/src/chunks/reader.rs',
    'chunks.rs': 'crates/s3drive-managed/src/chunks.rs',
    'test-pages.rs': 'crates/s3drive-cli/tests/chunk_reader/pages.rs',
    'chunk-reader.rs': 'crates/s3drive-cli/tests/chunk_reader.rs',
    'native.rs': 'crates/s3drive-cli/tests/chunk_reader/native.rs',
    'filesystem.rs': 'crates/s3drive-fs/src/lib.rs',
    'managed-filesystem.rs': 'crates/s3drive-fs/src/managed.rs',
    'legacy-engine-control.rs': 'crates/s3drive-cli/tests/support/managed.rs',
    'fixture.rs': 'crates/s3drive-cli/tests/chunk_reader/fixture.rs',
}.items():
    files[name] = root / path
files['archive-script.py'] = Path(__file__)
base = subprocess.check_output(['git', '-C', str(root), 'rev-parse', 'HEAD']).decode().strip()
assert base == 'bf2e6aed16d32c62e094082a50769141f8f90ef6'
base_path = Path('/tmp/s3drive-page-proofs-combined-base.json')
base_path.write_text(json.dumps({'base': base, 'branch': 'codex/manifest-page-proofs',
    'scope': 'W1b plus accepted native snapshots, exact frozen source; portable local only'}, indent=2) + '\n')
files['base.json'] = base_path
index = {name: hashlib.sha256(path.read_bytes()).hexdigest() for name, path in sorted(files.items())}
archive = root / 'docs/src/evidence/manifest-page-proofs-combined-local-20261018.tar.gz'
assert not archive.exists()
with tarfile.open(archive, 'w:gz') as tar:
    for name, path in sorted(files.items()):
        tar.add(path, arcname=name)
    raw = (json.dumps(index, indent=2) + '\n').encode()
    entry = tarfile.TarInfo('sha256-index.json')
    entry.size = len(raw)
    tar.addfile(entry, io.BytesIO(raw))
with tarfile.open(archive) as tar:
    assert set(tar.getnames()) == set(index) | {'sha256-index.json'}
    for name, digest in index.items():
        assert hashlib.sha256(tar.extractfile(name).read()).hexdigest() == digest
proof = {'path': str(archive.relative_to(root / 'docs/src')),
    'sha256': hashlib.sha256(archive.read_bytes()).hexdigest(),
    'bytes': archive.stat().st_size, 'members': len(index) + 1,
    'all_indexed_members_verified': True, 'scope': 'W1b portable local only'}
Path('/tmp/s3drive-page-proofs-combined-local-archive-proof.json').write_text(json.dumps(proof, indent=2) + '\n')
print(json.dumps(proof, indent=2))
