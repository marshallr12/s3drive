from pathlib import Path
from html import escape
parts=['<svg xmlns="http://www.w3.org/2000/svg" width="960" height="1190" viewBox="0 0 960 1190" role="img" aria-labelledby="title desc">', '<title id="title">Empty managed-file creation and recovery</title>', '<desc id="desc">A Rust controller persists intent in private SQLite, uploads and verifies one immutable manifest page in S3, then saves and replays an exact metadata request to the shared Rust coordinator. The coordinator commits to its separate SQLite database. Native chunk creation is pending and Turso is optional research.</desc>', '<defs><marker id="arrow" markerWidth="9" markerHeight="9" refX="8" refY="4" orient="auto"><path d="M0,0 L8,4 L0,8" fill="none" stroke="#49637b" stroke-width="1.5"/></marker></defs>', '<rect width="960" height="1190" fill="#f6f8fc"/>', '<g font-family="DejaVu Sans,sans-serif" fill="#172e48">']
def text(x,y,label,size=18,bold=False,color='#172e48'):
 parts.append(f'<text x="{x}" y="{y}" font-size="{size}" fill="{color}"'+(' font-weight="bold"' if bold else '')+'>'+escape(label)+'</text>')
def box(x,y,w,h,title,lines,color='#e7effa',dash=False):
 parts.append(f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="13" fill="{color}" stroke="#8fa7bf" stroke-width="2"'+(' stroke-dasharray="8 5"' if dash else '')+'/>')
 text(x+18,y+31,title,21,True)
 for index,line in enumerate(lines):text(x+18,y+61+27*index,line)
def arrow(path,dash=False):
 parts.append(f'<path d="{path}" fill="none" stroke="#49637b" stroke-width="2" marker-end="url(#arrow)"'+(' stroke-dasharray="7 5"' if dash else '')+'/>')
text(35,43,'Creating an empty managed file',28,True)
text(35,76,'Rust client • private SQLite • immutable S3 data • shared metadata',18,color='#526980')
box(35,104,890,66,'Linux FUSE / Windows WinFsp create hook — integration pending',[], '#eef1f5',True)
arrow('M215,170 L215,210',True)
box(35,210,360,139,'Rust creation controller',['Bind volume, parent, name, store','Derive the canonical 64-byte root','Use the executor’s exact SQL owner'])
box(450,210,475,110,'Local credential profile',['Frozen credentials for the S3 client','Never sent to the coordinator'], '#eef1f5')
arrow('M690,320 L690,390');text(708,360,'local only',16,color='#526980')
arrow('M215,349 L215,390');text(45,377,'one SQL owner',16,color='#526980')
box(35,390,360,350,'Private local SQLite',[
 '1  Save the exact creation intent',
 '   Parent, name, store and IDs',
 '   Stage the canonical root page',
 '3  Retain verified upload metadata',
 '4  Save the exact metadata request',
 '6  Save the historical receipt',
 '',
 'Saved proof must match the',
 'original verified upload metadata.',
], '#fff6e7')
box(450,390,475,150,'Rust S3 executor',[
 '2  Conditional create: one PUT claim',
 '3  HEAD/GET verify bytes and identity',
 'On uncertainty: observe; never resend.',
])
arrow('M395,265 L423,265 L423,432 L450,432')
arrow('M450,495 L395,495');text(402,482,'3',16)
arrow('M690,540 L690,620');text(708,582,'PUT / HEAD / GET',16,color='#526980')
box(450,620,475,120,'S3-compatible service',[
 'Selected bucket: immutable manifest root',
 'Object: 64 bytes  •  logical file: 0 bytes',
], '#e8f5ef')
arrow('M215,740 L215,800');arrow('M245,800 L245,740');text(45,777,'saved metadata',16,color='#526980')
box(35,800,360,130,'Metadata commit / recovery',[
 '5  Replay only the saved request',
 'No S3 credentials or body reads',
])
box(450,800,475,130,'Shared Rust coordinator',[
 'Local loopback or remote authenticated TLS',
 'Atomic name + root + history transaction',
])
arrow('M395,846 L450,846');text(413,835,'5',16)
arrow('M450,887 L395,887');text(413,915,'6',16)
arrow('M690,930 L690,980')
box(450,980,475,120,'Shared authority database',[
 'SQLite: separate from every client journal',
 'Turso: researched, not implemented here',
], '#fff6e7')
text(35,1134,'File bytes go directly to S3; the coordinator commits metadata.',18,color='#526980')
text(35,1164,'A creation receipt is historical, not current-path or native-flush proof.',18,color='#526980')
parts.append('</g></svg>')
Path('/tmp/s3drive-creation-diagram/empty-manifest-client.svg').write_text(''.join(parts))
