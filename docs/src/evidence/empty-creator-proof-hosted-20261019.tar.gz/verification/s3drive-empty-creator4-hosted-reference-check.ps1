$ErrorActionPreference='Stop'
Set-StrictMode -Version Latest
$repo='/home/marshall/src/worktrees/s3drive-empty-manifest-publisher'
. "$repo/scripts/windows-replacement-fixture.ps1"
. "$repo/scripts/windows-reference-fixture.ps1"
$replacement=Get-Content -Raw /tmp/s3drive-empty-creator4-hosted-artifacts/windows-replacement-reference.json|ConvertFrom-Json
$original=Get-Content -Raw /tmp/s3drive-empty-creator4-hosted-artifacts/windows-disposition-reference.json|ConvertFrom-Json
$rf=Get-Content -Raw "$repo/docs/src/evidence/windows-replacement-reference-20261017.json"|ConvertFrom-Json
$of=Get-Content -Raw "$repo/docs/src/evidence/windows-disposition-reference-20261017.json"|ConvertFrom-Json
foreach($report in @($replacement,$original)) {if($report.source_commit -cne '950479ca3aacd19059fe3e8474f548502476f36a'){throw 'Wrong source'}}
Assert-WindowsReplacementReference -Fixture $rf -Observation $replacement
Assert-WindowsDispositionReference -Fixture $of -Observation $original
Write-Output 'PASS: EmptyCreator independent physical-proof cohort inherited Windows reference typed21/14 project oracles and exact source'
