"""One-use sealing of this independently verified source/run only."""
import pathlib,json,hashlib,tarfile,io,subprocess
root=pathlib.Path('/home/marshall/src/worktrees/s3drive-empty-manifest-publisher')
base=pathlib.Path('/tmp/s3drive-empty-creator4-hosted-artifacts')
source='950479ca3aacd19059fe3e8474f548502476f36a';run_id=39325779322
out=root/'docs/src/evidence/empty-creator-proof-hosted-20261019.tar.gz';assert not out.exists()
run=json.loads((base/'run.json').read_text());jobs=json.loads((base/'jobs.json').read_text())
assert run['id']==run_id and run['head_sha']==source and run['run_attempt']==1 and run['conclusion']=='success'
assert {j['id'] for j in jobs['jobs']}=={118311122005,118311122026,118311122136}
assert all(j['conclusion']=='success' and j['head_sha']==source and j['run_attempt']==1 for j in jobs['jobs'])
ind=json.loads((base/'independent-check.json').read_text());raw=json.loads((base/'raw-record-comparison.json').read_text())
assert {(i['kind'],i['records']) for i in ind}=={('replacement',21),('disposition',14)}
assert all(i['source']==source and i['strict_types_and_all_fields_match'] is True for i in ind)
assert all(i['all_fields_and_types_equal'] is True for i in raw)
assert 'PASS: EmptyCreator independent physical-proof cohort' in (base/'project-oracles.log').read_text()
review=json.load(open('/tmp/s3drive-empty-creator4-hosted-raw-reviewed.json'));assert review['reviewed'] and review['source']==source and review['run_id']==run_id
files={}
for p in base.iterdir():
 if p.is_file():files['artifacts/'+p.name]=p.read_bytes()
for job,entry in review['jobs'].items():
 data=pathlib.Path(entry['log']).read_bytes();assert entry['reviewed'] and hashlib.sha256(data).hexdigest()==entry['sha256'];files['raw/'+pathlib.Path(entry['log']).name]=data
for name in ['s3drive-empty-creator4-hosted-raw-reviewed.json','s3drive-empty-creator4-raw-review-scan.json','s3drive-empty-creator4-detailed-raw-review.json','s3drive-empty-creator4-review-raw.py','s3drive-check-empty-creator4-hosted.py','s3drive-check-native-artifacts.py','s3drive-empty-creator4-hosted-reference-check.ps1','s3drive-empty-creator4-hosted-raw-compare.py','s3drive-empty-creator4-source-artifact-check.log','s3drive-empty-creator4-raw-comparison.log','s3drive-empty-creator4-hosted-watch-result.json','s3drive-empty-creator-candidate4-frozen.json']:
 p=pathlib.Path('/tmp')/name;files['verification/'+name]=p.read_bytes()
frozen=json.loads(files['verification/s3drive-empty-creator-candidate4-frozen.json']);assert len(frozen)==357
parent=json.load(open('/tmp/s3drive-empty-intent-candidate2-frozen.json'));assert len(parent)==354
for p,h in frozen.items():
 data=(root/p).read_bytes();assert hashlib.sha256(data).hexdigest()==h
 assert subprocess.check_output(['git','-C',str(root),'show',source+':'+p])==data
 if parent.get(p)!=h:files['tested-delta/'+p]=data
for p in ['scripts/windows-reference-fixture.ps1','scripts/windows-replacement-fixture.ps1','docs/src/evidence/windows-replacement-reference-20261017.json','docs/src/evidence/windows-disposition-reference-20261017.json']:
 files['tested-oracles/'+p]=subprocess.check_output(['git','-C',str(root),'show',source+':'+p])
for name in ['review.json','empty-manifest-client.svg','empty-manifest-client.png','build.py']:
 files['post-gate-documentation/'+name]=(pathlib.Path('/tmp/s3drive-creation-diagram')/name).read_bytes()
files['status.json']=json.dumps({'source':source,'run':run_id,'attempt':1,'runtime_inputs_verified':357,'schema':40,'independent_typed_records':[21,14],'raw_fields_types_equal':35,'accepted_scope':'SDK empty-manifest creation/recovery, independent proof coherence; existing native regressions','new_native_chunk_writes':False,'real_provider_mutations':False,'physical_mx_windows_signin_reboot':False,'post_gate_documentation':'SVG/PNG are separately rendered and visually reviewed documentation; not part of the tested runtime catalog.'},indent=2).encode()
files['archive-builder.py']=pathlib.Path(__file__).read_bytes()
index=json.dumps({n:{'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)} for n,b in files.items()},indent=2).encode()
with tarfile.open(out,'w:gz') as t:
 for name,data in [*sorted(files.items()),('index.json',index)]:
  info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o600;t.addfile(info,io.BytesIO(data))
with tarfile.open(out) as t:
 assert len(t.getmembers())==len(files)+1
 assert t.extractfile('index.json').read()==index
 for name,data in files.items():assert t.extractfile(name).read()==data,name
proof={'archive':str(out),'source':source,'run':run_id,'sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'bytes':out.stat().st_size,'members':len(files)+1,'verified':True,'runtime_inputs':357,'schema':40}
pathlib.Path('/tmp/s3drive-empty-creator4-hosted-archive-proof.json').write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps(proof))
