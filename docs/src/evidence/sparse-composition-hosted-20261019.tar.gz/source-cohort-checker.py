"""One-use checker: a complete, reviewed pinned related-object S3 read cohort only; all GitHub calls GET."""
import datetime
import hashlib
import io
import json
from pathlib import Path
import re
import subprocess
import zipfile

SOURCE = '84da0ee633871f862f4a84a276af5ac3322cff42'
RUN = 39213440204
ATTEMPT = 1
REPO = 'marshallr12/s3drive'
ROOT = Path('/home/marshall/src/worktrees/s3drive-sparse-composition')
JOBS = {117931758993: 'book',117931759166: 'rust (ubuntu-latest)',117931759092: 'rust (windows-latest)'}
PRIMARY_ARTIFACT_IDS = {12157933431, 12157617883, 12155790591, 12155504654, 12154419081, 12154876865, 12152741226, 12153275892, 12151153703, 12151479241, 12150891787, 12151260949, 12149243457, 12149814008, 12147997314, 12147329360, 12147331157, 12147209844, 12146631312, 12146506974, 12145416969, 12145194101, 12144981486, 12144507996, 12143780290, 12143656516, 12142621547, 12142503573, 12139939008, 12141530185, 12140403755, 12139721137, 12141120690, 12139390103, 12140285720, 12139435870}
PRIMARY_ARTIFACT_IDS.update({12161588927, 12161348483})
PRIMARY_ARTIFACT_IDS.update({12162658840, 12163198932})
PRIMARY_ARTIFACT_IDS.update({12163839520, 12164703036})
PRIMARY_ARTIFACT_IDS.update({12166749052, 12167860879})
OUTPUT = Path('/tmp/s3drive-sparse-composition-hosted-artifacts')
MARKER = Path('/tmp/s3drive-sparse-composition-hosted-raw-reviewed.json')

def gh_json(endpoint):
    return json.loads(subprocess.check_output(['gh', 'api', f'repos/{REPO}/{endpoint}']))

def instant(value):
    return datetime.datetime.fromisoformat(value.replace('Z', '+00:00'))

run = gh_json(f'actions/runs/{RUN}/attempts/{ATTEMPT}')
assert run['id'] == RUN and run['run_attempt'] == ATTEMPT and run['head_sha'] == SOURCE
assert run['status'] == 'completed' and run['conclusion'] == 'success'
jobs = gh_json(f'actions/runs/{RUN}/attempts/{ATTEMPT}/jobs?per_page=100')
assert jobs['total_count'] == 3
assert {j['id']: j['name'] for j in jobs['jobs']} == JOBS
assert all(j['run_id'] == RUN and j['run_attempt'] == ATTEMPT and j['head_sha'] == SOURCE
           and j['status'] == 'completed' and j['conclusion'] == 'success' for j in jobs['jobs'])
review = json.loads(MARKER.read_text())
assert review['source'] == SOURCE and review['run_id'] == RUN and review['run_attempt'] == ATTEMPT
assert review['reviewed'] is True and set(review['jobs']) == {str(j) for j in JOBS}
for job, entry in review['jobs'].items():
    assert entry['job_id'] == int(job) and entry['run_attempt'] == ATTEMPT and entry['reviewed'] is True
    assert hashlib.sha256(Path(entry['log']).read_bytes()).hexdigest() == entry['sha256']
for job_id in (str(j) for j, name in JOBS.items() if name.startswith('rust (')):
    raw = Path(review['jobs'][job_id]['log']).read_text()
    for name in ['reader::tests::related_opens_pin_root_credentials_while_independent_opens_rotate', 'reader::tests::related_opens_require_fresh_head_and_preserve_scope_and_failures', 'reader::tests::related_open_future_fits_native_callback_stack_budget']:
        assert re.search(r'test ' + re.escape(name) + r' \.\.\. ok', raw), (job_id, name)
    assert '62 passed; 0 failed' in raw
    assert '37 passed; 0 failed' in raw
    for name in ['sparse_views::tests::faults::actual_sqlite_full_never_acknowledges_or_leaves_partial_view_admission', 'sparse_views::tests::base_binding_initial_size_and_operation_changes_never_replace_an_admitted_view', 'sparse_views::tests::initial_empty_truncate_and_sparse_growth_use_only_bounded_metadata', 'sparse_views::tests::initial_sparse_views_reopen_exact_identity_and_plan_bounded_base_and_zero_ranges', 'sparse_views::tests::integrity::actual_sqlite_full_after_head_update_keeps_old_head_receipts_and_all_patch_bytes', 'sparse_views::tests::faults::ignored_or_foreign_trigger_effects_roll_back_all_initial_admission_rows', 'sparse_views::tests::integrity::patch_table_alone_cannot_be_adopted_by_legacy_or_authority_roles', 'sparse_views::tests::migration::schema_thirty_migration_sql_failure_rolls_back_copies_and_refuses_attached_triggers', 'sparse_views::tests::integrity::every_patch_transaction_effect_is_checked_and_sql_trigger_failures_roll_back_exact_old_bytes', 'sparse_views::tests::migration::schema_thirty_preserves_populated_cyclic_views_byte_for_byte_and_removes_only_target_uniqueness', 'sparse_views::tests::migration::schema_twenty_nine_keeps_old_dirty_bytes_and_migration_collisions_roll_back', 'sparse_views::tests::integrity::corrupt_patches_self_consistent_forks_cycles_and_unread_bytes_are_refused_without_repair', 'sparse_views::tests::narrowed_file_quota_preserves_old_views_and_exact_replay', 'sparse_views::tests::migration::sparse_role_is_reciprocally_isolated_while_generic_staging_remains_available', 'sparse_views::tests::patches::literal_initial_format_and_ids_survive_patch_extension_without_reserializing_old_rows', 'sparse_views::tests::faults::corrupt_missing_oversized_and_substituted_rows_never_replay_or_repair', 'sparse_views::tests::patches::independent_admission_quotas_preserve_dirty_bytes_old_views_and_late_exact_replay', 'sparse_views::tests::patches::sparse_sixty_four_gib_shrink_regrow_and_boundary_ranges_never_resurrect_old_tail', 'sparse_views::tests::recovery::additive_schema_thirty_one_keeps_populated_thirty_literal_blobs_and_migration_collisions_roll_back', 'sparse_views::tests::recovery::patch_crash_child', 'sparse_views::tests::recovery::racing_worker_mutations_keep_one_head_and_replay_old_results_after_reopen', 'sparse_views::tests::worker::private_owner_worker_reopens_exact_views_and_closes_all_clones', 'sparse_views::tests::recovery::killed_patch_owners_roll_back_each_uncommitted_boundary_and_recover_the_exact_committed_result', 'sparse_views::tests::patches::bounded_blocks_split_partial_reads_deduplicate_and_refuse_oversized_input', 'sparse_views::tests::patches::overlapping_edits_match_independent_byte_model_keep_old_views_and_replay_original_results']:
        assert re.search(r'test ' + re.escape(name) + r' \.\.\. ok', raw), (job_id, name)
    assert re.search(r'test response_accounting_waits_for_owned_handler_after_client_body_completion \.\.\. ok', raw), job_id

    state_count = 393 if JOBS[int(job_id)] == 'rust (ubuntu-latest)' else 388
    assert f'{state_count} passed; 0 failed; 1 ignored' in raw
    for name in [
        'base_binding_initial_size_and_operation_changes_never_replace_an_admitted_view',
        'faults::actual_sqlite_full_never_acknowledges_or_leaves_partial_view_admission',
        'faults::corrupt_missing_oversized_and_substituted_rows_never_replay_or_repair',
        'faults::ignored_or_foreign_trigger_effects_roll_back_all_initial_admission_rows',
        'initial_empty_truncate_and_sparse_growth_use_only_bounded_metadata',
        'initial_sparse_views_reopen_exact_identity_and_plan_bounded_base_and_zero_ranges',
        'migration::schema_twenty_nine_keeps_old_dirty_bytes_and_migration_collisions_roll_back',
        'migration::sparse_role_is_reciprocally_isolated_while_generic_staging_remains_available',
        'narrowed_file_quota_preserves_old_views_and_exact_replay',
        'worker::private_owner_worker_reopens_exact_views_and_closes_all_clones',
    ]:
        assert re.search(r'test sparse_views::tests::' + re.escape(name) + r' \.\.\. ok', raw), (job_id, name)
    for name in [
        'cli_snapshot_round_trip_preserves_receipts_and_never_authorizes_restore',
        'authority_snapshot::native::tests::actual_schema_eight_is_copied_without_migration',
        'authority_snapshot::native::tests::invalid_pins_roles_schemas_and_limits_refuse_before_creating_output',
    ]:
        assert re.search(r'test ' + re.escape(name) + r' \.\.\. ok', raw), (job_id, name)

    for name in ['manifest::base::tests::exact_persisted_vector_preserves_original_identity_and_redaction', 'manifest::base::tests::malformed_persisted_shape_and_reserved_ids_are_refused_without_authorizing_content', 'manifest::base::tests::hex_constructor_refuses_noncanonical_fields_and_reserved_identity']:
        assert re.search(r'test ' + re.escape(name) + r' \.\.\. ok', raw), (job_id, name)

    for name in ['manifest_ranges_sparse_unicode_empty_cross_page_pins_and_maximum', 'manifest_ranges_refuse_metadata_hash_context_role_and_late_chunk_faults', 'manifest_ranges_refuse_denied_missing_oversized_truncated_or_changed_objects', 'manifest_ranges_bound_slots_snapshots_cancel_and_overall_deadline']:
        assert re.search(r'test ' + re.escape(name) + r' \.\.\. ok', raw), (job_id, name)
    assert '16 passed; 0 failed; 1 ignored' in raw
    for name in ['native::manifest_filesystem_mixed_namespace_logical_sizes_pinned_ranges_and_refusals', 'native::actual_native_manifest_reads_and_remount', 'native::filesystem_format_transitions_pin_attributes_and_refuse_stale_opens', 'manifest_chunk_proofs_bind_snapshot_without_data_reads_and_reject_forgery', 'manifest_page_proofs_bind_subtrees_and_reuse_old_root_without_data_reads', 'manifest_base_descriptors_reopen_exact_history_with_fresh_auth_and_shared_bounds', 'history::manifest_history_authenticates_original_reference_after_restart_without_rebasing', 'namespace::publication::manifest::tests::history::manifest_history_retains_exact_base_after_replacement_rename_removal_and_restart']:
        assert re.search(r'test ' + re.escape(name) + r' \.\.\. ok', raw), (job_id, name)
    for name in ['edited_views_compose_exact_history_local_patches_zeros_and_fragmented_chunks_after_restart', 'edited_views_refuse_wrong_bindings_auth_denials_late_faults_and_principal_rebinding', 'edited_views_share_reader_limits_cancel_deadline_and_release_sql_owner_before_network', 'edited_view_reopen_worker']:
        assert re.search(r'test ' + re.escape(name) + r' \.\.\. ok', raw), (job_id, name)
    own_job = next(j for j in jobs['jobs'] if str(j['id']) == job_id)
    native = [step for step in own_job['steps'] if step['name'] == 'Verify native manifest ranges and remount']
    assert len(native) == 1 and native[0]['status'] == 'completed' and native[0]['conclusion'] == 'success'


windows = next(j for j in jobs['jobs'] if j['name'] == 'rust (windows-latest)')
raw_log = Path(review['jobs'][str(windows['id'])]['log']).read_text()
log = re.sub(r'\x1b\[[0-9;]*[A-Za-z]', '', raw_log)
ids = {}
for kind in ('replacement', 'disposition'):
    name = f'windows-{kind}-reference-{SOURCE}'
    matches = re.findall(r'Artifact ' + re.escape(name) + r'\.zip successfully finalized\. Artifact ID (\d+)', log)
    assert len(matches) == 1, (kind, 'not exactly one own finalized artifact')
    ids[kind] = int(matches[0])
assert len(set(ids.values())) == 2 and not set(ids.values()) & PRIMARY_ARTIFACT_IDS
metadata = gh_json(f'actions/runs/{RUN}/artifacts?per_page=100')
assert metadata['total_count'] == len(metadata['artifacts'])
selected = [a for a in metadata['artifacts'] if a['id'] in ids.values()]
assert len(selected) == 2 and {a['id'] for a in selected} == set(ids.values())
for artifact in selected:
    kind = next(k for k, v in ids.items() if v == artifact['id'])
    assert artifact['name'] == f'windows-{kind}-reference-{SOURCE}'
    assert artifact['expired'] is False
    assert artifact['workflow_run']['id'] == RUN and artifact['workflow_run']['head_sha'] == SOURCE
    assert instant(windows['started_at']) <= instant(artifact['created_at']) <= instant(windows['completed_at'])
    assert instant(artifact['updated_at']) <= instant(windows['completed_at'])
for name in ('scripts/windows-replacement-fixture.ps1', 'scripts/windows-reference-fixture.ps1',
             'docs/src/evidence/windows-replacement-reference-20261017.json',
             'docs/src/evidence/windows-disposition-reference-20261017.json'):
    assert (ROOT / name).read_bytes() == subprocess.check_output(['git', '-C', str(ROOT), 'show', SOURCE + ':' + name])
identity = json.loads(subprocess.check_output(['gh', 'repo', 'view', REPO, '--json', 'nameWithOwner,visibility']))
assert identity['nameWithOwner'] == REPO and identity['visibility'] == 'PUBLIC'
frozen = json.loads(Path('/tmp/s3drive-sparse-composition-frozen.json').read_text())
assert len(frozen) == 286
for path, digest in frozen.items():
    assert hashlib.sha256((ROOT / path).read_bytes()).hexdigest() == digest
    assert hashlib.sha256(subprocess.check_output(['git', '-C', str(ROOT), 'show', SOURCE + ':' + path])).hexdigest() == digest
OUTPUT.mkdir(mode=0o700)
for name, value in [('run', run), ('jobs', jobs), ('artifact-metadata', selected)]:
    (OUTPUT / f'{name}.json').write_text(json.dumps(value, indent=2) + '\n')
proof = []
for artifact in selected:
    kind = next(k for k, v in ids.items() if v == artifact['id'])
    raw = subprocess.check_output(['gh', 'api', '--allow-escape-sequences', f'repos/{REPO}/actions/artifacts/{artifact["id"]}/zip'])
    digest = hashlib.sha256(raw).hexdigest()
    assert artifact['digest'] == 'sha256:' + digest
    name = f'windows-{kind}-reference.json'
    with zipfile.ZipFile(io.BytesIO(raw)) as archive:
        assert archive.namelist() == [name] and archive.getinfo(name).file_size < 1024 * 1024
        data = archive.read(name)
    (OUTPUT / f'{kind}.zip').write_bytes(raw)
    (OUTPUT / name).write_bytes(data)
    proof.append({'kind': kind, 'id': artifact['id'], 'source': SOURCE, 'run_id': RUN, 'run_attempt': ATTEMPT,
                  'windows_job': windows['id'], 'zip_sha256': digest, 'json_sha256': hashlib.sha256(data).hexdigest(),
                  'primary_artifact_reused': False})
(OUTPUT / 'download-proof.json').write_text(json.dumps(proof, indent=2) + '\n')
check = subprocess.check_output(['python3', '/tmp/s3drive-check-native-artifacts.py', '--source', SOURCE,
                                '--directory', str(OUTPUT), '--repository', str(ROOT)])
(OUTPUT / 'independent-check.json').write_bytes(check)
project = subprocess.check_output(['pwsh', '-NoProfile', '-NonInteractive', '-File',
                                   '/tmp/s3drive-sparse-composition-hosted-reference-check.ps1'])
(OUTPUT / 'project-oracles.log').write_bytes(project)
print(check.decode(), end='')
print(project.decode(), end='')
print(json.dumps(proof, indent=2))
