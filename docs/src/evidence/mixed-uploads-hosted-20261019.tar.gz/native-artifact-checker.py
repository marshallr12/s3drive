"""Independent strict type-and-field comparison of owned CI artifacts."""
import argparse,datetime,hashlib,json,pathlib,subprocess

def pairs(items):
    result={}
    for key,value in items:
        if key in result: raise ValueError('duplicate JSON field')
        result[key]=value
    return result

def strict(raw):
    return json.loads(raw,object_pairs_hook=pairs,parse_constant=lambda v:(_ for _ in ()).throw(ValueError('non-finite JSON')))

def equal(actual,expected,path='value'):
    assert type(actual) is type(expected),(path,'type mismatch')
    if isinstance(actual,dict):
        assert actual.keys()==expected.keys(),(path,'field mismatch')
        for key in actual: equal(actual[key],expected[key],path+'.'+str(key))
    elif isinstance(actual,list):
        assert len(actual)==len(expected),(path,'length mismatch')
        for i,(a,e) in enumerate(zip(actual,expected)):equal(a,e,path+f'[{i}]')
    else:assert actual==expected,(path,'value mismatch')

p=argparse.ArgumentParser();p.add_argument('--source',required=True);p.add_argument('--directory',required=True);p.add_argument('--repository',required=True);args=p.parse_args()
repo=pathlib.Path(args.repository);directory=pathlib.Path(args.directory)
assert len(args.source)==40 and all(c in '0123456789abcdef' for c in args.source)
reports=[]
for kind,expected_count in [('replacement',21),('disposition',14)]:
    name=f'windows-{kind}-reference.json';raw=(directory/name).read_bytes();observed=strict(raw)
    envelope={'source_commit','operating_system','observed_at_utc','records'}
    envelope.add('winfsp_file_version' if kind=='replacement' else 'upstream_legacy_cases')
    assert type(observed) is dict and observed.keys()==envelope,(kind,'envelope mismatch')
    refpath=f'docs/src/evidence/windows-{kind}-reference-20261017.json'
    reference=strict(subprocess.check_output(['git','-C',str(repo),'show',args.source+':'+refpath]))
    assert observed['source_commit']==args.source
    assert observed['operating_system']==reference['operating_system']=='Microsoft Windows Server 2025 Datacenter'
    assert type(observed['observed_at_utc']) is str
    assert observed['observed_at_utc'].endswith('Z')
    datetime.datetime.fromisoformat(observed['observed_at_utc'].replace('Z','+00:00'))
    if kind=='replacement':assert observed['winfsp_file_version']==reference['winfsp_file_version']=='2.1.25156.ddca7bd'
    else:
        equal(observed['upstream_legacy_cases'],['create_test','delete_pending_test','rename_test','rename_open_test'])
    def index(records):
        assert type(records) is list and len(records)==expected_count
        out={}
        for record in records:
            assert type(record) is dict and record.keys()=={'backend','case','observations'}
            assert type(record['backend']) is str and type(record['case']) is str
            key=(record['backend'],record['case']);assert key not in out
            out[key]=record
        return out
    equal(index(observed['records']),index(reference['records']),kind)
    reports.append({'kind':kind,'records':expected_count,'source':args.source,'sha256':hashlib.sha256(raw).hexdigest(),'strict_types_and_all_fields_match':True})
print(json.dumps(reports,indent=2))
